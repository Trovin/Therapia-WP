# WordPress MySQL database migration
#
# Generated: Friday 16. August 2019 15:36 UTC
# Hostname: localhost
# Database: `test6.f5-cloud.top`
# URL: //therapia.test
# Path: /var/www/test6.f5-cloud.top
# Tables: wpth_commentmeta, wpth_comments, wpth_failed_jobs, wpth_links, wpth_mailchimp_carts, wpth_options, wpth_postmeta, wpth_posts, wpth_queue, wpth_term_relationships, wpth_term_taxonomy, wpth_termmeta, wpth_terms, wpth_usermeta, wpth_users, wpth_wc_download_log, wpth_wc_webhooks, wpth_woocommerce_api_keys, wpth_woocommerce_attribute_taxonomies, wpth_woocommerce_downloadable_product_permissions, wpth_woocommerce_log, wpth_woocommerce_order_itemmeta, wpth_woocommerce_order_items, wpth_woocommerce_payment_tokenmeta, wpth_woocommerce_payment_tokens, wpth_woocommerce_sessions, wpth_woocommerce_shipping_zone_locations, wpth_woocommerce_shipping_zone_methods, wpth_woocommerce_shipping_zones, wpth_woocommerce_tax_rate_locations, wpth_woocommerce_tax_rates
# Table Prefix: wpth_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post, product, product_variation, wpcf7_contact_form
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wpth_commentmeta`
#

DROP TABLE IF EXISTS `wpth_commentmeta`;


#
# Table structure of table `wpth_commentmeta`
#

CREATE TABLE `wpth_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_commentmeta`
#
INSERT INTO `wpth_commentmeta` ( `meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(5, 3, 'rating', '4'),
(6, 3, 'verified', '0') ;

#
# End of data contents of table `wpth_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wpth_comments`
#

DROP TABLE IF EXISTS `wpth_comments`;


#
# Table structure of table `wpth_comments`
#

CREATE TABLE `wpth_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_comments`
#
INSERT INTO `wpth_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-12-26 13:33:34', '2018-12-26 13:33:34', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0),
(3, 141, 'admin1020', 'wp.test.mail.for.me@gmail.com', '', '127.0.0.1', '2019-02-18 13:28:45', '2019-02-18 13:28:45', 'Nice stuff', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 'review', 0, 1) ;

#
# End of data contents of table `wpth_comments`
# --------------------------------------------------------



#
# Delete any existing table `wpth_failed_jobs`
#

DROP TABLE IF EXISTS `wpth_failed_jobs`;


#
# Table structure of table `wpth_failed_jobs`
#

CREATE TABLE `wpth_failed_jobs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `job` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_failed_jobs`
#

#
# End of data contents of table `wpth_failed_jobs`
# --------------------------------------------------------



#
# Delete any existing table `wpth_links`
#

DROP TABLE IF EXISTS `wpth_links`;


#
# Table structure of table `wpth_links`
#

CREATE TABLE `wpth_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_links`
#

#
# End of data contents of table `wpth_links`
# --------------------------------------------------------



#
# Delete any existing table `wpth_mailchimp_carts`
#

DROP TABLE IF EXISTS `wpth_mailchimp_carts`;


#
# Table structure of table `wpth_mailchimp_carts`
#

CREATE TABLE `wpth_mailchimp_carts` (
  `id` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `cart` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_mailchimp_carts`
#

#
# End of data contents of table `wpth_mailchimp_carts`
# --------------------------------------------------------



#
# Delete any existing table `wpth_options`
#

DROP TABLE IF EXISTS `wpth_options`;


#
# Table structure of table `wpth_options`
#

CREATE TABLE `wpth_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9725 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_options`
#
INSERT INTO `wpth_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://therapia.test', 'yes'),
(2, 'home', 'http://therapia.test', 'yes'),
(3, 'blogname', 'Therapia shop', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'wp.test.mail.for.me@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:195:{s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:7:"shop/?$";s:27:"index.php?post_type=product";s:37:"shop/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:32:"shop/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:24:"shop/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"product-category/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:28:"product-tag/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:39:"product/.+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"product/.+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"product/.+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"product/.+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"product/.+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"product/.+?/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:30:"product/(.+?)/([^/]+)/embed/?$";s:64:"index.php?product_cat=$matches[1]&product=$matches[2]&embed=true";s:34:"product/(.+?)/([^/]+)/trackback/?$";s:58:"index.php?product_cat=$matches[1]&product=$matches[2]&tb=1";s:54:"product/(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:70:"index.php?product_cat=$matches[1]&product=$matches[2]&feed=$matches[3]";s:49:"product/(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:70:"index.php?product_cat=$matches[1]&product=$matches[2]&feed=$matches[3]";s:42:"product/(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:71:"index.php?product_cat=$matches[1]&product=$matches[2]&paged=$matches[3]";s:49:"product/(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:71:"index.php?product_cat=$matches[1]&product=$matches[2]&cpage=$matches[3]";s:39:"product/(.+?)/([^/]+)/wc-api(/(.*))?/?$";s:72:"index.php?product_cat=$matches[1]&product=$matches[2]&wc-api=$matches[4]";s:43:"product/.+?/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:54:"product/.+?/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:38:"product/(.+?)/([^/]+)(?:/([0-9]+))?/?$";s:70:"index.php?product_cat=$matches[1]&product=$matches[2]&page=$matches[3]";s:28:"product/.+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"product/.+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"product/.+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"product/.+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"product/.+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"product/.+?/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:40:"testimonials/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"testimonials/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"testimonials/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"testimonials/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"testimonials/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"testimonials/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"testimonials/([^/]+)/embed/?$";s:45:"index.php?testimonials=$matches[1]&embed=true";s:33:"testimonials/([^/]+)/trackback/?$";s:39:"index.php?testimonials=$matches[1]&tb=1";s:41:"testimonials/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?testimonials=$matches[1]&paged=$matches[2]";s:48:"testimonials/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?testimonials=$matches[1]&cpage=$matches[2]";s:38:"testimonials/([^/]+)/wc-api(/(.*))?/?$";s:53:"index.php?testimonials=$matches[1]&wc-api=$matches[3]";s:44:"testimonials/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:55:"testimonials/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:37:"testimonials/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?testimonials=$matches[1]&page=$matches[2]";s:29:"testimonials/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"testimonials/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"testimonials/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"testimonials/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"testimonials/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"testimonials/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:32:"logo/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"logo/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"logo/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"logo/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"logo/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"logo/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"logo/([^/]+)/embed/?$";s:37:"index.php?logo=$matches[1]&embed=true";s:25:"logo/([^/]+)/trackback/?$";s:31:"index.php?logo=$matches[1]&tb=1";s:33:"logo/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?logo=$matches[1]&paged=$matches[2]";s:40:"logo/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?logo=$matches[1]&cpage=$matches[2]";s:30:"logo/([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?logo=$matches[1]&wc-api=$matches[3]";s:36:"logo/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:47:"logo/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:29:"logo/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?logo=$matches[1]&page=$matches[2]";s:21:"logo/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"logo/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"logo/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"logo/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"logo/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"logo/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=19&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:14:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:33:"classic-editor/classic-editor.php";i:2;s:50:"contact-form-7-mailchimp-extension/cf7-mch-ext.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:5;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:6;s:41:"sassy-social-share/sassy-social-share.php";i:7;s:55:"video-tab-for-woocommerce/video-tab-for-woocommerce.php";i:8;s:69:"woo-gutenberg-products-block/woocommerce-gutenberg-products-block.php";i:9;s:55:"woocommerce-add-countries/woocommerce-add-countries.php";i:10;s:91:"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php";i:11;s:57:"woocommerce-gateway-stripe/woocommerce-gateway-stripe.php";i:12;s:45:"woocommerce-services/woocommerce-services.php";i:13;s:27:"woocommerce/woocommerce.php";i:14;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'therapia', 'yes'),
(41, 'stylesheet', 'therapia', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '43764', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:3:{s:45:"woocommerce-services/woocommerce-services.php";a:2:{i:0;s:17:"WC_Connect_Loader";i:1;s:16:"plugin_uninstall";}s:33:"classic-editor/classic-editor.php";a:2:{i:0;s:14:"Classic_Editor";i:1;s:9:"uninstall";}s:55:"woocommerce-add-countries/woocommerce-add-countries.php";a:2:{i:0;s:3:"Wac";i:1;s:9:"uninstall";}}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '19', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '43764', 'yes'),
(94, 'wpth_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:114:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop manager";s:12:"capabilities";a:93:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"edit_theme_options";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wpth_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'cron', 'a:13:{i:1565969785;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:0:{}s:8:"interval";i:60;}}}i:1565970835;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1565973333;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1565973624;a:1:{s:24:"woocommerce_cleanup_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1565987248;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1566000000;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1566005614;a:2:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1566048824;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1566049224;a:1:{s:33:"woocommerce_cleanup_personal_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1566049234;a:1:{s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1566051958;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1567382400;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:7:"monthly";s:4:"args";a:0:{}s:8:"interval";i:2635200;}}}s:7:"version";i:2;}', 'yes'),
(122, 'can_compress_scripts', '1', 'no'),
(137, 'recently_activated', 'a:1:{s:51:"mailchimp-for-woocommerce/mailchimp-woocommerce.php";i:1553517840;}', 'yes'),
(142, 'updraftplus_version', '1.16.0', 'yes'),
(143, 'updraft_updraftvault', 'a:2:{s:7:"version";i:1;s:8:"settings";a:1:{s:34:"s-87ee5e38e283796361bfd9c797b7c290";a:3:{s:5:"token";s:0:"";s:5:"email";s:0:"";s:5:"quota";i:-1;}}}', 'yes'),
(144, 'updraft_dropbox', 'a:2:{s:7:"version";i:1;s:8:"settings";a:1:{s:34:"s-fb9f4a4fa885f0c200c1e6f86658b53b";a:4:{s:6:"appkey";s:0:"";s:6:"secret";s:0:"";s:6:"folder";s:0:"";s:15:"tk_access_token";s:1:"0";}}}', 'yes'),
(145, 'updraft_s3', 'a:2:{s:7:"version";s:1:"1";s:8:"settings";a:1:{s:34:"s-bef59668b620696521e0f17ec604d192";a:3:{s:9:"accesskey";s:0:"";s:9:"secretkey";s:0:"";s:4:"path";s:0:"";}}}', 'yes'),
(146, 'updraft_cloudfiles', 'a:2:{s:7:"version";s:1:"1";s:8:"settings";a:1:{s:34:"s-e630d60513fed04be198aea690096e5f";a:5:{s:7:"authurl";s:35:"https://auth.api.rackspacecloud.com";s:6:"region";s:3:"DFW";s:4:"user";s:0:"";s:6:"apikey";s:0:"";s:4:"path";s:0:"";}}}', 'yes'),
(147, 'updraft_googledrive', 'a:2:{s:7:"version";i:1;s:8:"settings";a:1:{s:34:"s-680dd3fcbe495d0fac4c76cf073d7ca8";a:4:{s:8:"clientid";s:0:"";s:6:"secret";s:0:"";s:5:"token";s:0:"";s:6:"folder";s:11:"UpdraftPlus";}}}', 'yes'),
(148, 'updraft_onedrive', 'a:1:{s:7:"version";s:1:"1";}', 'yes'),
(149, 'updraft_ftp', 'a:2:{s:7:"version";s:1:"1";s:8:"settings";a:1:{s:34:"s-a9297a85dad144175ae89bd5aa1cadaf";a:5:{s:4:"host";s:0:"";s:4:"user";s:0:"";s:4:"pass";s:0:"";s:4:"path";s:0:"";s:7:"passive";s:1:"1";}}}', 'yes'),
(150, 'updraft_azure', 'a:1:{s:7:"version";s:1:"1";}', 'yes'),
(151, 'updraft_sftp', 'a:1:{s:7:"version";s:1:"1";}', 'yes'),
(152, 'updraft_googlecloud', 'a:1:{s:7:"version";s:1:"1";}', 'yes'),
(153, 'updraft_backblaze', 'a:1:{s:7:"version";s:1:"1";}', 'yes'),
(154, 'updraft_webdav', 'a:1:{s:7:"version";s:1:"1";}', 'yes'),
(155, 'updraft_s3generic', 'a:2:{s:7:"version";s:1:"1";s:8:"settings";a:1:{s:34:"s-936ecf67e43fceac012ff162a821bcbc";a:4:{s:9:"accesskey";s:0:"";s:9:"secretkey";s:0:"";s:4:"path";s:0:"";s:8:"endpoint";s:0:"";}}}', 'yes'),
(156, 'updraft_openstack', 'a:2:{s:7:"version";s:1:"1";s:8:"settings";a:1:{s:34:"s-0b1b96f9cd46fb7c8a2c0a1354814c65";a:6:{s:7:"authurl";s:0:"";s:6:"tenant";s:0:"";s:6:"region";s:0:"";s:4:"user";s:0:"";s:8:"password";s:0:"";s:4:"path";s:0:"";}}}', 'yes'),
(157, 'updraft_dreamobjects', 'a:2:{s:7:"version";s:1:"1";s:8:"settings";a:1:{s:34:"s-d905cfc1cdda128573548d4f345d8e97";a:4:{s:9:"accesskey";s:0:"";s:9:"secretkey";s:0:"";s:4:"path";s:0:"";s:8:"endpoint";s:26:"objects-us-east-1.dream.io";}}}', 'yes'),
(158, 'updraftplus-addons_siteid', '02e335de20977f5845c08bd506c2245c', 'no'),
(159, 'updraftplus_tour_cancelled_on', 'premium', 'yes'),
(160, 'updraft_retain_extrarules', 'a:0:{}', 'yes'),
(161, 'updraft_email', 'wp.test.mail.for.me@gmail.com', 'yes'),
(162, 'updraft_report_warningsonly', 'a:0:{}', 'yes'),
(163, 'updraft_report_wholebackup', 'a:0:{}', 'yes'),
(164, 'updraft_extradbs', 'a:0:{}', 'yes'),
(165, 'updraft_include_more_path', 'a:0:{}', 'yes'),
(166, 'updraft_interval', 'manual', 'yes'),
(167, 'updraft_retain', '2', 'yes'),
(168, 'updraft_interval_database', 'manual', 'yes'),
(169, 'updraft_retain_db', '2', 'yes'),
(170, 'updraft_include_plugins', '1', 'yes'),
(171, 'updraft_include_themes', '1', 'yes'),
(172, 'updraft_include_uploads', '1', 'yes'),
(173, 'updraft_include_uploads_exclude', 'backup*,*backups,backwpup*,wp-clone,snapshots', 'yes'),
(174, 'updraft_include_others', '1', 'yes'),
(175, 'updraft_include_others_exclude', 'upgrade,cache,updraft,backup*,*backups,mysql.sql,debug.log', 'yes'),
(176, 'updraft_split_every', '400', 'yes'),
(177, 'updraft_delete_local', '1', 'yes'),
(178, 'updraft_dir', 'updraft', 'yes'),
(179, 'updraft_service', '', 'yes'),
(180, 'updraft_debug_mode', '0', 'yes'),
(181, 'updraft_ssl_useservercerts', '0', 'yes'),
(182, 'updraft_ssl_disableverify', '0', 'yes'),
(183, 'updraft_ssl_nossl', '0', 'yes'),
(184, 'updraft_auto_updates', '0', 'yes'),
(188, 'woocommerce_store_address', 'NY', 'yes'),
(189, 'woocommerce_store_address_2', 'NY', 'yes'),
(190, 'woocommerce_store_city', 'NY', 'yes'),
(191, 'woocommerce_default_country', 'US:NY', 'yes'),
(192, 'woocommerce_store_postcode', '18000', 'yes'),
(193, 'woocommerce_allowed_countries', 'all', 'yes'),
(194, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(195, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(196, 'woocommerce_ship_to_countries', '', 'yes'),
(197, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(198, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(199, 'woocommerce_calc_taxes', 'yes', 'yes'),
(200, 'woocommerce_enable_coupons', 'no', 'yes'),
(201, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(202, 'woocommerce_currency', 'USD', 'yes'),
(203, 'woocommerce_currency_pos', 'left', 'yes'),
(204, 'woocommerce_price_thousand_sep', ',', 'yes'),
(205, 'woocommerce_price_decimal_sep', '.', 'yes'),
(206, 'woocommerce_price_num_decimals', '0', 'yes'),
(207, 'woocommerce_shop_page_id', '8', 'yes'),
(208, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(209, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(210, 'woocommerce_placeholder_image', '', 'yes'),
(211, 'woocommerce_weight_unit', 'kg', 'yes'),
(212, 'woocommerce_dimension_unit', 'cm', 'yes'),
(213, 'woocommerce_enable_reviews', 'yes', 'yes'),
(214, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(215, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(216, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(217, 'woocommerce_review_rating_required', 'yes', 'no'),
(218, 'woocommerce_manage_stock', 'yes', 'yes'),
(219, 'woocommerce_hold_stock_minutes', '60', 'no'),
(220, 'woocommerce_notify_low_stock', 'yes', 'no'),
(221, 'woocommerce_notify_no_stock', 'yes', 'no'),
(222, 'woocommerce_stock_email_recipient', 'wp.test.mail.for.me@gmail.com', 'no'),
(223, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(224, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(225, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(226, 'woocommerce_stock_format', 'low_amount', 'yes'),
(227, 'woocommerce_file_download_method', 'force', 'no'),
(228, 'woocommerce_downloads_require_login', 'no', 'no'),
(229, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(230, 'woocommerce_prices_include_tax', 'no', 'yes'),
(231, 'woocommerce_tax_based_on', 'shipping', 'yes') ;
INSERT INTO `wpth_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(232, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(233, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(234, 'woocommerce_tax_classes', 'Reduced rate\r\nZero rate', 'yes'),
(235, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(236, 'woocommerce_tax_display_cart', 'excl', 'yes'),
(237, 'woocommerce_price_display_suffix', '', 'yes'),
(238, 'woocommerce_tax_total_display', 'itemized', 'no'),
(239, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(240, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(241, 'woocommerce_ship_to_destination', 'billing', 'no'),
(242, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(243, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(244, 'woocommerce_enable_checkout_login_reminder', 'no', 'no'),
(245, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(246, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(247, 'woocommerce_registration_generate_username', 'yes', 'no'),
(248, 'woocommerce_registration_generate_password', 'yes', 'no'),
(249, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(250, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(251, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(252, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(253, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(254, 'woocommerce_trash_pending_orders', '', 'no'),
(255, 'woocommerce_trash_failed_orders', '', 'no'),
(256, 'woocommerce_trash_cancelled_orders', '', 'no'),
(257, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(258, 'woocommerce_email_from_name', 'Therapia', 'no'),
(259, 'woocommerce_email_from_address', 'wp.test.mail.for.me@gmail.com', 'no'),
(260, 'woocommerce_email_header_image', '', 'no'),
(261, 'woocommerce_email_footer_text', '{site_title}<br/>Powered by <a href="https://woocommerce.com/">WooCommerce</a>', 'no'),
(262, 'woocommerce_email_base_color', '#96588a', 'no'),
(263, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(264, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(265, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(266, 'woocommerce_cart_page_id', '9', 'yes'),
(267, 'woocommerce_checkout_page_id', '10', 'yes'),
(268, 'woocommerce_myaccount_page_id', '11', 'yes'),
(269, 'woocommerce_terms_page_id', '', 'no'),
(270, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(271, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(272, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(273, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(274, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(275, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(276, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(277, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(278, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(279, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(280, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(281, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(282, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(283, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(284, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(285, 'woocommerce_api_enabled', 'no', 'yes'),
(286, 'woocommerce_single_image_width', '600', 'yes'),
(287, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(288, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(289, 'woocommerce_demo_store', 'no', 'no'),
(290, 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:22:"/product/%product_cat%";s:13:"category_base";s:16:"product-category";s:8:"tag_base";s:11:"product-tag";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:1;}', 'yes'),
(291, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(292, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(295, 'default_product_cat', '15', 'yes'),
(298, 'woocommerce_version', '3.5.3', 'yes'),
(299, 'woocommerce_db_version', '3.5.3', 'yes'),
(300, 'woocommerce_admin_notices', 'a:0:{}', 'yes'),
(302, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(303, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(304, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(305, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(306, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(307, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(308, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(309, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(310, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(311, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(312, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(313, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(327, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(351, 'theme_mods_twentynineteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1545833710;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(352, 'current_theme', 'Therapia theme', 'yes'),
(353, 'theme_mods_starter-wp-theme', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:6:"menu-1";i:18;}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1545903995;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(354, 'theme_switched', '', 'yes'),
(355, 'woocommerce_maybe_regenerate_images_hash', '991b1ca641921cf0f5baf7a2fe85861b', 'yes'),
(369, 'woocommerce_product_type', 'physical', 'yes'),
(370, 'woocommerce_allow_tracking', 'yes', 'yes'),
(373, 'woocommerce_tracker_last_send', '1565465750', 'yes'),
(377, 'woocommerce_stripe_settings', 'a:24:{s:7:"enabled";s:3:"yes";s:14:"create_account";s:3:"yes";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:20:"apple_pay_domain_set";s:2:"no";s:5:"title";s:20:"Credit Card (Stripe)";s:11:"description";s:37:"Pay with your credit card via Stripe.";s:8:"testmode";s:3:"yes";s:14:"inline_cc_form";s:2:"no";s:7:"capture";s:3:"yes";s:20:"statement_descriptor";s:0:"";s:14:"three_d_secure";s:3:"yes";s:15:"stripe_checkout";s:2:"no";s:21:"stripe_checkout_image";s:0:"";s:27:"stripe_checkout_description";s:0:"";s:11:"saved_cards";s:2:"no";s:15:"test_secret_key";s:0:"";s:20:"test_publishable_key";s:0:"";s:15:"payment_request";s:3:"yes";s:15:"publishable_key";s:0:"";s:10:"secret_key";s:0:"";s:27:"payment_request_button_type";s:3:"buy";s:28:"payment_request_button_theme";s:4:"dark";s:29:"payment_request_button_height";s:2:"44";s:7:"logging";s:2:"no";}', 'yes'),
(379, 'woocommerce_ppec_paypal_settings', 'a:53:{s:7:"enabled";s:3:"yes";s:16:"reroute_requests";s:3:"yes";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:11:"button_size";s:5:"large";s:11:"environment";s:4:"live";s:12:"mark_enabled";s:3:"yes";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";s:15:"api_certificate";s:0:"";s:11:"api_subject";s:0:"";s:5:"debug";s:2:"no";s:14:"invoice_prefix";s:3:"WC-";s:16:"instant_payments";s:2:"no";s:15:"require_billing";s:2:"no";s:13:"paymentaction";s:4:"sale";s:26:"subtotal_mismatch_behavior";s:3:"add";s:5:"title";s:6:"PayPal";s:11:"description";s:85:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.";s:20:"sandbox_api_username";s:0:"";s:20:"sandbox_api_password";s:0:"";s:21:"sandbox_api_signature";s:0:"";s:23:"sandbox_api_certificate";s:0:"";s:19:"sandbox_api_subject";s:0:"";s:10:"brand_name";s:13:"Therapia shop";s:14:"logo_image_url";s:0:"";s:16:"header_image_url";s:0:"";s:10:"page_style";s:0:"";s:12:"landing_page";s:5:"Login";s:20:"require_phone_number";s:2:"no";s:7:"use_spb";s:2:"no";s:12:"button_color";s:4:"gold";s:12:"button_shape";s:4:"rect";s:13:"button_layout";s:8:"vertical";s:20:"hide_funding_methods";a:1:{i:0;s:4:"CARD";}s:14:"credit_enabled";s:3:"yes";s:21:"cart_checkout_enabled";s:3:"yes";s:25:"mini_cart_settings_toggle";s:2:"no";s:23:"mini_cart_button_layout";s:8:"vertical";s:21:"mini_cart_button_size";s:10:"responsive";s:30:"mini_cart_hide_funding_methods";a:1:{i:0;s:4:"CARD";}s:24:"mini_cart_credit_enabled";s:3:"yes";s:34:"checkout_on_single_product_enabled";s:3:"yes";s:30:"single_product_settings_toggle";s:3:"yes";s:28:"single_product_button_layout";s:10:"horizontal";s:26:"single_product_button_size";s:10:"responsive";s:35:"single_product_hide_funding_methods";a:1:{i:0;s:4:"CARD";}s:29:"single_product_credit_enabled";s:3:"yes";s:20:"mark_settings_toggle";s:2:"no";s:18:"mark_button_layout";s:8:"vertical";s:16:"mark_button_size";s:10:"responsive";s:25:"mark_hide_funding_methods";a:1:{i:0;s:4:"CARD";}s:19:"mark_credit_enabled";s:3:"yes";}', 'yes'),
(380, 'woocommerce_cheque_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(381, 'woocommerce_bacs_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(382, 'woocommerce_cod_settings', 'a:6:{s:7:"enabled";s:2:"no";s:5:"title";s:16:"Cash on delivery";s:11:"description";s:28:"Pay with cash upon delivery.";s:12:"instructions";s:28:"Pay with cash upon delivery.";s:18:"enable_for_methods";a:0:{}s:18:"enable_for_virtual";s:3:"yes";}', 'yes'),
(398, 'do_activate', '0', 'yes'),
(403, 'woocommerce_setup_shipping_labels', '1', 'yes'),
(404, 'wc_ppec_version', '1.6.5', 'yes'),
(406, 'woocommerce_flat_rate_1_settings', 'a:3:{s:5:"title";s:9:"Flat rate";s:10:"tax_status";s:7:"taxable";s:4:"cost";s:2:"20";}', 'yes'),
(407, 'woocommerce_flat_rate_2_settings', 'a:3:{s:5:"title";s:9:"Flat rate";s:10:"tax_status";s:7:"taxable";s:4:"cost";s:2:"50";}', 'yes'),
(410, 'wc_stripe_version', '4.1.13', 'yes'),
(412, 'woocommerce_setup_automated_taxes', '1', 'yes'),
(413, 'mailchimp_woocommerce_plugin_do_activation_redirect', '', 'yes'),
(415, 'mailchimp_woocommerce_version', '2.1.11', 'no') ;
INSERT INTO `wpth_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(416, 'mailchimp-woocommerce', 'a:0:{}', 'yes'),
(418, 'mailchimp-woocommerce-store_id', '5c238f5870ac4', 'yes'),
(421, 'mailchimp_woocommerce_db_mailchimp_carts', '1', 'no'),
(427, 'wc_connect_options', 'a:1:{s:12:"tos_accepted";b:1;}', 'yes'),
(447, 'nav_menu_options', 'a:1:{s:8:"auto_add";a:0:{}}', 'yes'),
(468, 'wpcf7', 'a:2:{s:7:"version";s:5:"5.1.1";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1545835383;s:7:"version";s:5:"5.1.1";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(513, 'acf_version', '5.7.6', 'yes'),
(531, 'options_logo_image', '33', 'no'),
(532, '_options_logo_image', 'field_5c23a72f50a29', 'no'),
(533, 'options_footer_logo_image', '132', 'no'),
(534, '_options_footer_logo_image', 'field_5c2cbd7c3f9f4', 'no'),
(535, 'options_facebook_link', 'https://twitter.com/', 'no'),
(536, '_options_facebook_link', 'field_5c23a791b9d1d', 'no'),
(537, 'options_twitter_link', 'https://twitter.com/', 'no'),
(538, '_options_twitter_link', 'field_5c23a7c6fa906', 'no'),
(539, 'options_instagramm_link', 'https://twitter.com/', 'no'),
(540, '_options_instagramm_link', 'field_5c23a7e791e73', 'no'),
(541, 'options_pinterest_link', 'https://twitter.com/', 'no'),
(542, '_options_pinterest_link', 'field_5c23a802d9b74', 'no'),
(563, 'options_instagram_link', 'https://twitter.com/', 'no'),
(564, '_options_instagram_link', 'field_5c23a7e791e73', 'no'),
(594, 'woocommerce_tracker_ua', 'a:5:{i:0;s:113:"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36";i:1;s:114:"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36";i:2;s:114:"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36";i:3;s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36";i:4;s:114:"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36";}', 'yes'),
(627, 'theme_mods_therapia', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:6:"menu-1";i:18;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(1124, 'jetpack_constants_sync_checksum', 'a:31:{s:16:"EMPTY_TRASH_DAYS";i:-1821685917;s:17:"WP_POST_REVISIONS";i:-33796979;s:26:"AUTOMATIC_UPDATER_DISABLED";i:634125391;s:7:"ABSPATH";i:-1438995558;s:14:"WP_CONTENT_DIR";i:-443641468;s:9:"FS_METHOD";i:634125391;s:18:"DISALLOW_FILE_EDIT";i:-33796979;s:18:"DISALLOW_FILE_MODS";i:634125391;s:19:"WP_AUTO_UPDATE_CORE";i:634125391;s:22:"WP_HTTP_BLOCK_EXTERNAL";i:634125391;s:19:"WP_ACCESSIBLE_HOSTS";i:634125391;s:16:"JETPACK__VERSION";i:2112716780;s:12:"IS_PRESSABLE";i:634125391;s:15:"DISABLE_WP_CRON";i:634125391;s:17:"ALTERNATE_WP_CRON";i:634125391;s:20:"WP_CRON_LOCK_TIMEOUT";i:-300109018;s:11:"PHP_VERSION";i:1765642118;s:15:"WP_MEMORY_LIMIT";i:-1229557325;s:19:"WP_MAX_MEMORY_LIMIT";i:828812020;s:14:"WC_PLUGIN_FILE";i:1709329525;s:10:"WC_ABSPATH";i:423302175;s:18:"WC_PLUGIN_BASENAME";i:1149093810;s:10:"WC_VERSION";i:-310619136;s:19:"WOOCOMMERCE_VERSION";i:-310619136;s:21:"WC_ROUNDING_PRECISION";i:498629140;s:25:"WC_DISCOUNT_ROUNDING_MODE";i:450215437;s:20:"WC_TAX_ROUNDING_MODE";i:-2082672713;s:12:"WC_DELIMITER";i:-1839055742;s:10:"WC_LOG_DIR";i:-1367094427;s:22:"WC_SESSION_CACHE_GROUP";i:-15988308;s:22:"WC_TEMPLATE_DEBUG_MODE";i:734881840;}', 'yes'),
(1127, 'jetpack_sync_https_history_main_network_site_url', 'a:1:{i:0;s:4:"http";}', 'yes'),
(1128, 'jetpack_sync_https_history_site_url', 'a:2:{i:0;s:4:"http";i:1;s:4:"http";}', 'yes'),
(1129, 'jetpack_sync_https_history_home_url', 'a:2:{i:0;s:4:"http";i:1;s:4:"http";}', 'yes'),
(1163, 'jetpack_callables_sync_checksum', 'a:31:{s:18:"wp_max_upload_size";i:869269328;s:15:"is_main_network";i:734881840;s:13:"is_multi_site";i:734881840;s:17:"main_network_site";i:843029562;s:8:"site_url";i:843029562;s:8:"home_url";i:843029562;s:16:"single_user_site";i:-33796979;s:7:"updates";i:-869524094;s:28:"has_file_system_write_access";i:-33796979;s:21:"is_version_controlled";i:-33796979;s:10:"taxonomies";i:-522593417;s:10:"post_types";i:-601339006;s:18:"post_type_features";i:-571050707;s:10:"shortcodes";i:-2070663983;s:27:"rest_api_allowed_post_types";i:-1535233178;s:32:"rest_api_allowed_public_metadata";i:223132457;s:24:"sso_is_two_step_required";i:734881840;s:26:"sso_should_hide_login_form";i:734881840;s:18:"sso_match_by_email";i:-33796979;s:21:"sso_new_user_override";i:734881840;s:29:"sso_bypass_default_login_form";i:734881840;s:10:"wp_version";i:367031918;s:11:"get_plugins";i:-802733779;s:24:"get_plugins_action_links";i:223132457;s:14:"active_modules";i:223132457;s:16:"hosting_provider";i:769900095;s:6:"locale";i:110763218;s:13:"site_icon_url";i:734881840;s:5:"roles";i:-926099218;s:8:"timezone";i:-486461887;s:24:"available_jetpack_blocks";i:223132457;}', 'no'),
(1164, 'jpsq_sync_checkout', '0:0', 'no'),
(1761, 'mce_show_notice', '0', 'no'),
(1762, 'mce_loyalty', 'a:11:{s:7:"seconds";i:49;s:7:"minutes";i:5;s:5:"hours";i:12;s:4:"mday";i:2;s:4:"wday";i:3;s:3:"mon";i:1;s:4:"year";i:2019;s:4:"yday";i:1;s:7:"weekday";s:9:"Wednesday";s:5:"month";s:7:"January";i:0;i:1546430749;}', 'no'),
(1770, 'cf7_mch_23', 'a:27:{s:3:"api";s:37:"6f0069d6be51d3c0ecb96d16779864fe-us18";s:4:"list";s:10:"058a3a2f9d";s:5:"email";s:11:"[email-423]";s:4:"name";s:10:"Subscriber";s:6:"accept";s:0:"";s:8:"confsubs";s:1:"1";s:12:"CustomValue1";s:0:"";s:10:"CustomKey1";s:0:"";s:12:"CustomValue2";s:0:"";s:10:"CustomKey2";s:0:"";s:12:"CustomValue3";s:0:"";s:10:"CustomKey3";s:0:"";s:12:"CustomValue4";s:0:"";s:10:"CustomKey4";s:0:"";s:12:"CustomValue5";s:0:"";s:10:"CustomKey5";s:0:"";s:12:"CustomValue6";s:0:"";s:10:"CustomKey6";s:0:"";s:12:"CustomValue7";s:0:"";s:10:"CustomKey7";s:0:"";s:12:"CustomValue8";s:0:"";s:10:"CustomKey8";s:0:"";s:12:"CustomValue9";s:0:"";s:10:"CustomKey9";s:0:"";s:13:"CustomValue10";s:0:"";s:11:"CustomKey10";s:0:"";s:14:"logfileEnabled";s:1:"1";}', 'yes'),
(1777, 'cf7_mch_91', 'a:25:{s:3:"api";s:0:"";s:4:"list";s:0:"";s:5:"email";s:0:"";s:4:"name";s:0:"";s:6:"accept";s:0:"";s:12:"CustomValue1";s:0:"";s:10:"CustomKey1";s:0:"";s:12:"CustomValue2";s:0:"";s:10:"CustomKey2";s:0:"";s:12:"CustomValue3";s:0:"";s:10:"CustomKey3";s:0:"";s:12:"CustomValue4";s:0:"";s:10:"CustomKey4";s:0:"";s:12:"CustomValue5";s:0:"";s:10:"CustomKey5";s:0:"";s:12:"CustomValue6";s:0:"";s:10:"CustomKey6";s:0:"";s:12:"CustomValue7";s:0:"";s:10:"CustomKey7";s:0:"";s:12:"CustomValue8";s:0:"";s:10:"CustomKey8";s:0:"";s:12:"CustomValue9";s:0:"";s:10:"CustomKey9";s:0:"";s:13:"CustomValue10";s:0:"";s:11:"CustomKey10";s:0:"";}', 'yes'),
(1791, 'options_subscribe_form_title', 'Stay connected', 'no'),
(1792, '_options_subscribe_form_title', 'field_5c2cafddbeef6', 'no'),
(1793, 'options_subscribe_form_info', 'With Thousands of H-Pillow already produced &\r\nin stock, you will receive yours in no time!', 'no'),
(1794, '_options_subscribe_form_info', 'field_5c2caff1beef7', 'no'),
(1910, 'options_footer_contact_email', 'demo@example.com', 'no'),
(1911, '_options_footer_contact_email', 'field_5c2cc83eff21a', 'no'),
(1912, 'options_footer_contact_adress', 'B1, Demo Street Hillington Trade Park, \r\nGlasgow, G11 4BQ, UK.', 'no'),
(1913, '_options_footer_contact_adress', 'field_5c2cc8986a239', 'no'),
(1915, 'options_footer_contact_tel', '001-100-9999', 'no'),
(1916, '_options_footer_contact_tel', 'field_5c2cc8646a238', 'no'),
(2103, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1565969763;}', 'no'),
(2158, 'category_children', 'a:0:{}', 'yes'),
(2184, 'options_copyright_text', 'H-Pillow', 'no'),
(2185, '_options_copyright_text', 'field_5c2e1ce832502', 'no'),
(2202, 'woocommerce_shop_page_display', '', 'yes'),
(2203, 'woocommerce_default_catalog_orderby', 'menu_order', 'yes'),
(2204, 'woocommerce_catalog_columns', '3', 'yes'),
(2205, 'woocommerce_catalog_rows', '4', 'yes'),
(2537, 'woocommerce_admin_footer_text_rated', '1', 'yes'),
(3580, 'heateor_sss', 'a:67:{s:24:"horizontal_sharing_shape";s:5:"round";s:23:"horizontal_sharing_size";s:2:"30";s:24:"horizontal_sharing_width";s:2:"70";s:25:"horizontal_sharing_height";s:2:"35";s:24:"horizontal_border_radius";s:0:"";s:29:"horizontal_font_color_default";s:4:"#000";s:32:"horizontal_sharing_replace_color";s:4:"#000";s:27:"horizontal_font_color_hover";s:4:"#000";s:38:"horizontal_sharing_replace_color_hover";s:4:"#000";s:27:"horizontal_bg_color_default";s:11:"transparent";s:25:"horizontal_bg_color_hover";s:11:"transparent";s:31:"horizontal_border_width_default";s:0:"";s:31:"horizontal_border_color_default";s:0:"";s:29:"horizontal_border_width_hover";s:0:"";s:29:"horizontal_border_color_hover";s:0:"";s:22:"vertical_sharing_shape";s:6:"square";s:21:"vertical_sharing_size";s:2:"40";s:22:"vertical_sharing_width";s:2:"80";s:23:"vertical_sharing_height";s:2:"40";s:22:"vertical_border_radius";s:0:"";s:27:"vertical_font_color_default";s:0:"";s:30:"vertical_sharing_replace_color";s:4:"#fff";s:25:"vertical_font_color_hover";s:0:"";s:36:"vertical_sharing_replace_color_hover";s:4:"#fff";s:25:"vertical_bg_color_default";s:0:"";s:23:"vertical_bg_color_hover";s:0:"";s:29:"vertical_border_width_default";s:0:"";s:29:"vertical_border_color_default";s:0:"";s:27:"vertical_border_width_hover";s:0:"";s:27:"vertical_border_color_hover";s:0:"";s:10:"hor_enable";s:1:"1";s:21:"horizontal_target_url";s:7:"default";s:28:"horizontal_target_url_custom";s:0:"";s:5:"title";s:0:"";s:18:"instagram_username";s:0:"";s:20:"comment_container_id";s:7:"respond";s:23:"horizontal_re_providers";a:3:{i:0;s:8:"facebook";i:1;s:7:"twitter";i:2;s:9:"pinterest";}s:21:"hor_sharing_alignment";s:4:"left";s:7:"product";s:1:"1";s:15:"horizontal_more";s:1:"1";s:19:"vertical_target_url";s:7:"default";s:26:"vertical_target_url_custom";s:0:"";s:27:"vertical_instagram_username";s:0:"";s:29:"vertical_comment_container_id";s:7:"respond";s:11:"vertical_bg";s:0:"";s:9:"alignment";s:4:"left";s:11:"left_offset";s:0:"";s:12:"right_offset";s:3:"-10";s:10:"top_offset";s:3:"100";s:13:"vertical_more";s:1:"1";s:19:"hide_mobile_sharing";s:1:"1";s:21:"vertical_screen_width";s:3:"783";s:21:"bottom_mobile_sharing";s:1:"1";s:23:"horizontal_screen_width";s:3:"783";s:23:"bottom_sharing_position";s:1:"0";s:24:"bottom_sharing_alignment";s:4:"left";s:29:"bottom_sharing_position_radio";s:10:"responsive";s:14:"delete_options";s:1:"1";s:31:"share_count_cache_refresh_count";s:2:"10";s:30:"share_count_cache_refresh_unit";s:7:"minutes";s:14:"bitly_username";s:0:"";s:9:"bitly_key";s:0:"";s:8:"language";s:5:"en_US";s:16:"twitter_username";s:0:"";s:15:"buffer_username";s:0:"";s:10:"amp_enable";s:1:"1";s:10:"custom_css";s:0:"";}', 'yes'),
(3581, 'heateor_sss_version', '3.2.10', 'yes'),
(3582, 'widget_heateor_sss_sharing', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(3583, 'widget_heateor_sss_floating_sharing', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(3584, 'widget_heateor_sss_follow', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(3725, 'heateor_sss_gdpr_notification_read', '1', 'yes'),
(4504, 'wc_gateway_ppce_prompt_to_connect', 'PayPal Checkout is almost ready. To get started, <a href="http://therapia.test/wp-admin/admin.php?page=wc-settings&#038;tab=checkout&#038;section=ppec_paypal">connect your PayPal account</a>.', 'yes'),
(4505, 'woocommerce_gateway_order', 'a:15:{s:4:"bacs";i:0;s:6:"cheque";i:1;s:3:"cod";i:2;s:6:"paypal";i:3;s:11:"ppec_paypal";i:4;s:6:"stripe";i:5;s:11:"stripe_sepa";i:6;s:17:"stripe_bancontact";i:7;s:13:"stripe_sofort";i:8;s:14:"stripe_giropay";i:9;s:10:"stripe_eps";i:10;s:12:"stripe_ideal";i:11;s:10:"stripe_p24";i:12;s:13:"stripe_alipay";i:13;s:17:"stripe_multibanco";i:14;}', 'yes'),
(4918, 'wac_countries_list', 'NAF, New African Country, AF\r\nNAC, New Asian Country, AS\r\nNEC, New European Country, EU', 'yes'),
(4963, 'woocommerce_paypal_settings', 'a:23:{s:7:"enabled";s:3:"yes";s:5:"title";s:6:"PayPal";s:11:"description";s:85:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:8:"advanced";s:0:"";s:8:"testmode";s:2:"no";s:5:"debug";s:2:"no";s:16:"ipn_notification";s:3:"yes";s:14:"receiver_email";s:29:"wp.test.mail.for.me@gmail.com";s:14:"identity_token";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"send_shipping";s:3:"yes";s:16:"address_override";s:2:"no";s:13:"paymentaction";s:4:"sale";s:10:"page_style";s:0:"";s:9:"image_url";s:0:"";s:11:"api_details";s:0:"";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";s:20:"sandbox_api_username";s:0:"";s:20:"sandbox_api_password";s:0:"";s:21:"sandbox_api_signature";s:0:"";}', 'yes'),
(5156, 'wc_gateway_ppce_bootstrap_warning_message', 'WooCommerce Gateway PayPal Checkout requires WooCommerce to be activated', 'yes'),
(6860, 'product_cat_children', 'a:0:{}', 'yes'),
(8276, 'wc_gateway_ppec_spb_notice_dismissed', 'yes', 'yes'),
(8277, 'wc_gateway_ppec_bootstrap_warning_message_dismissed', 'yes', 'yes'),
(8278, 'wc_gateway_ppec_prompt_to_connect_message_dismissed', 'yes', 'yes'),
(8279, 'wc_stripe_show_keys_notice', 'no', 'yes'),
(8963, 'mce_sent', '9', 'no'),
(8976, 'wc_stripe_show_ssl_notice', 'no', 'yes'),
(8996, 'auto_core_update_failed', 'a:6:{s:9:"attempted";s:5:"5.0.4";s:7:"current";s:5:"5.0.2";s:10:"error_code";s:23:"mkdir_failed_ziparchive";s:10:"error_data";N;s:9:"timestamp";i:1553682437;s:5:"retry";b:0;}', 'no'),
(8997, 'auto_core_update_notified', 'a:4:{s:4:"type";s:4:"fail";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:7:"version";s:5:"5.0.4";s:9:"timestamp";i:1553682437;}', 'no') ;

#
# End of data contents of table `wpth_options`
# --------------------------------------------------------



#
# Delete any existing table `wpth_postmeta`
#

DROP TABLE IF EXISTS `wpth_postmeta`;


#
# Table structure of table `wpth_postmeta`
#

CREATE TABLE `wpth_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3378 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_postmeta`
#
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 3, '_wp_page_template', 'default'),
(9, 12, '_wc_review_count', '0'),
(10, 12, '_wc_rating_count', 'a:0:{}'),
(11, 12, '_wc_average_rating', '0'),
(12, 12, '_edit_last', '1'),
(13, 12, '_edit_lock', '1549557670:1'),
(14, 13, '_wp_attached_file', '2018/12/product-img-1.png'),
(15, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:765;s:6:"height";i:765;s:4:"file";s:25:"2018/12/product-img-1.png";s:5:"sizes";a:10:{s:17:"custom-size-large";a:4:{s:4:"file";s:25:"product-img-1-300x220.png";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"product-img-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"product-img-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:17:"custom-size-small";a:4:{s:4:"file";s:23:"product-img-1-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:25:"product-img-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:25:"product-img-1-600x600.png";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:9:"image/png";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:25:"product-img-1-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"product-img-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:25:"product-img-1-600x600.png";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:25:"product-img-1-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(16, 13, '_wp_attachment_image_alt', 'product-img'),
(17, 12, '_sku', ''),
(20, 12, '_sale_price_dates_from', ''),
(21, 12, '_sale_price_dates_to', ''),
(22, 12, 'total_sales', '0'),
(23, 12, '_tax_status', 'taxable'),
(24, 12, '_tax_class', ''),
(25, 12, '_manage_stock', 'no'),
(26, 12, '_backorders', 'no'),
(27, 12, '_low_stock_amount', ''),
(28, 12, '_sold_individually', 'no'),
(29, 12, '_weight', ''),
(30, 12, '_length', ''),
(31, 12, '_width', ''),
(32, 12, '_height', ''),
(33, 12, '_upsell_ids', 'a:0:{}'),
(34, 12, '_crosssell_ids', 'a:0:{}'),
(35, 12, '_purchase_note', ''),
(36, 12, '_default_attributes', 'a:2:{s:8:"pa_color";s:5:"black";s:7:"pa_size";s:5:"30x30";}'),
(37, 12, '_virtual', 'no'),
(38, 12, '_downloadable', 'no'),
(39, 12, '_product_image_gallery', '77,79,75,48,13,76'),
(40, 12, '_download_limit', '-1'),
(41, 12, '_download_expiry', '-1'),
(42, 12, '_stock', NULL),
(43, 12, '_stock_status', 'instock'),
(44, 12, '_product_version', '3.5.3'),
(47, 16, '_menu_item_type', 'custom'),
(48, 16, '_menu_item_menu_item_parent', '0'),
(49, 16, '_menu_item_object_id', '16'),
(50, 16, '_menu_item_object', 'custom'),
(51, 16, '_menu_item_target', ''),
(52, 16, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(53, 16, '_menu_item_xfn', ''),
(54, 16, '_menu_item_url', 'http://therapia.test'),
(55, 17, '_menu_item_type', 'post_type'),
(56, 17, '_menu_item_menu_item_parent', '0'),
(57, 17, '_menu_item_object_id', '8'),
(58, 17, '_menu_item_object', 'page'),
(59, 17, '_menu_item_target', ''),
(60, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(61, 17, '_menu_item_xfn', ''),
(62, 17, '_menu_item_url', ''),
(68, 19, '_edit_lock', '1550504212:1'),
(69, 19, '_wp_page_template', 'tpl-home.php'),
(73, 23, '_form', '[email* email-423 class:subscribe-input placeholder "Enter your e-mail address"]\n[submit class:btn class:btn_light "Sign up"]'),
(74, 23, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:10:"Subscriber";s:6:"sender";s:44:"Therapia shop <wordpress@test6.f5-cloud.top>";s:9:"recipient";s:29:"wp.test.mail.for.me@gmail.com";s:4:"body";s:171:"From: <[email-423]>\nSubject: subscriber\n\nMessage Body:\n\'Subscriber email\' [email-423]\n\n-- \nThis e-mail was sent from a contact form on Therapia shop (http://therapia.test)";s:18:"additional_headers";s:39:"Reply-To: wp.test.mail.for.me@gmail.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(75, 23, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"Therapia shop "[your-subject]"";s:6:"sender";s:39:"Therapia shop <wordpress@therapia.test>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:114:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Therapia shop (http://therapia.test)";s:18:"additional_headers";s:39:"Reply-To: wp.test.mail.for.me@gmail.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(76, 23, '_messages', 'a:23:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:54:"Email field have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";s:12:"invalid_date";s:29:"The date format is incorrect.";s:14:"date_too_early";s:44:"The date is before the earliest one allowed.";s:13:"date_too_late";s:41:"The date is after the latest one allowed.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:20:"The file is too big.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:14:"invalid_number";s:29:"The number format is invalid.";s:16:"number_too_small";s:47:"The number is smaller than the minimum allowed.";s:16:"number_too_large";s:46:"The number is larger than the maximum allowed.";s:23:"quiz_answer_not_correct";s:36:"The answer to the quiz is incorrect.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:13:"invalid_email";s:38:"The e-mail address entered is invalid.";s:11:"invalid_url";s:19:"The URL is invalid.";s:11:"invalid_tel";s:32:"The telephone number is invalid.";}'),
(77, 23, '_additional_settings', ''),
(78, 23, '_locale', 'en_US'),
(81, 25, '_edit_last', '1'),
(82, 25, '_edit_lock', '1546607491:1'),
(83, 27, '_edit_last', '1'),
(84, 27, '_edit_lock', '1546253953:1'),
(85, 33, '_wp_attached_file', '2018/12/logo.png'),
(86, 33, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:336;s:6:"height";i:237;s:4:"file";s:16:"2018/12/logo.png";s:5:"sizes";a:8:{s:17:"custom-size-large";a:4:{s:4:"file";s:16:"logo-300x220.png";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:16:"logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"logo-300x212.png";s:5:"width";i:300;s:6:"height";i:212;s:9:"mime-type";s:9:"image/png";}s:17:"custom-size-small";a:4:{s:4:"file";s:14:"logo-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:16:"logo-300x237.png";s:5:"width";i:300;s:6:"height";i:237;s:9:"mime-type";s:9:"image/png";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:16:"logo-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:16:"logo-300x237.png";s:5:"width";i:300;s:6:"height";i:237;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:16:"logo-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(87, 33, '_wp_attachment_image_alt', 'logo-image'),
(88, 34, '_wp_attached_file', '2018/12/logo-footer.jpg'),
(89, 34, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:420;s:6:"height";i:297;s:4:"file";s:23:"2018/12/logo-footer.jpg";s:5:"sizes";a:8:{s:17:"custom-size-large";a:4:{s:4:"file";s:23:"logo-footer-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:23:"logo-footer-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"logo-footer-300x212.jpg";s:5:"width";i:300;s:6:"height";i:212;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:21:"logo-footer-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:23:"logo-footer-300x297.jpg";s:5:"width";i:300;s:6:"height";i:297;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:23:"logo-footer-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"logo-footer-300x297.jpg";s:5:"width";i:300;s:6:"height";i:297;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"logo-footer-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(90, 34, '_wp_attachment_image_alt', 'footer-logo-image'),
(111, 9, '_edit_lock', '1545987737:1'),
(112, 39, '_wc_review_count', '0'),
(113, 39, '_wc_rating_count', 'a:0:{}'),
(114, 39, '_wc_average_rating', '0'),
(115, 39, '_edit_last', '1'),
(116, 39, '_edit_lock', '1546418157:1'),
(117, 39, '_sku', ''),
(118, 39, '_regular_price', '100'),
(119, 39, '_sale_price', '90'),
(120, 39, '_sale_price_dates_from', ''),
(121, 39, '_sale_price_dates_to', ''),
(122, 39, 'total_sales', '0'),
(123, 39, '_tax_status', 'taxable'),
(124, 39, '_tax_class', ''),
(125, 39, '_manage_stock', 'no'),
(126, 39, '_backorders', 'no'),
(127, 39, '_low_stock_amount', ''),
(128, 39, '_sold_individually', 'no'),
(129, 39, '_weight', ''),
(130, 39, '_length', ''),
(131, 39, '_width', ''),
(132, 39, '_height', ''),
(133, 39, '_upsell_ids', 'a:0:{}'),
(134, 39, '_crosssell_ids', 'a:0:{}'),
(135, 39, '_purchase_note', ''),
(136, 39, '_default_attributes', 'a:0:{}'),
(137, 39, '_virtual', 'no'),
(138, 39, '_downloadable', 'no'),
(139, 39, '_product_image_gallery', ''),
(140, 39, '_download_limit', '-1'),
(141, 39, '_download_expiry', '-1') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(142, 39, '_stock', NULL),
(143, 39, '_stock_status', 'instock'),
(144, 39, '_product_version', '3.5.3'),
(145, 39, '_price', '90'),
(146, 40, '_edit_last', '1'),
(147, 40, '_edit_lock', '1548842724:1'),
(148, 48, '_wp_attached_file', '2018/12/product-img-2.png'),
(149, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1539;s:6:"height";i:1539;s:4:"file";s:25:"2018/12/product-img-2.png";s:5:"sizes";a:12:{s:17:"custom-size-large";a:4:{s:4:"file";s:25:"product-img-2-300x220.png";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"product-img-2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"product-img-2-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:25:"product-img-2-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:27:"product-img-2-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:17:"custom-size-small";a:4:{s:4:"file";s:23:"product-img-2-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:25:"product-img-2-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:25:"product-img-2-600x600.png";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:9:"image/png";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:25:"product-img-2-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"product-img-2-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:25:"product-img-2-600x600.png";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:25:"product-img-2-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(150, 48, '_wp_attachment_image_alt', 'product-img'),
(151, 19, '_edit_last', '1'),
(152, 19, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(153, 19, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(154, 19, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight 1'),
(155, 19, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(156, 19, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(157, 19, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(158, 19, 'product-info_0_intro_product_image', '121'),
(159, 19, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(160, 19, 'product-info_1_intro_product_name', 'H-Pillow 2'),
(161, 19, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(162, 19, 'product-info_1_intro_product_description', 'Light Weight Ergonomic 2'),
(163, 19, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(164, 19, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(165, 19, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(166, 19, 'product-info_1_intro_product_image', '48'),
(167, 19, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(168, 19, 'product-info_2_intro_product_name', 'H-Pillow 3'),
(169, 19, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(170, 19, 'product-info_2_intro_product_description', 'Light Weight Ergonomic 3 '),
(171, 19, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(172, 19, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(173, 19, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(174, 19, 'product-info_2_intro_product_image', '121'),
(175, 19, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(176, 19, 'product-info_3_intro_product_name', 'H-Pillow 4'),
(177, 19, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(178, 19, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight 4'),
(179, 19, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(180, 19, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(181, 19, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(182, 19, 'product-info_3_intro_product_image', '48'),
(183, 19, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(184, 19, 'product-info', '4'),
(185, 19, '_product-info', 'field_5c24fc17c2302'),
(186, 49, 'product-info_0_intro_product_name', 'H-Pillow'),
(187, 49, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(188, 49, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(189, 49, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(190, 49, 'product-info_0_intro_product_link', 'https://twitter.com/'),
(191, 49, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(192, 49, 'product-info_0_intro_product_image', '48'),
(193, 49, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(194, 49, 'product-info_1_intro_product_name', 'H-Pillow'),
(195, 49, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(196, 49, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(197, 49, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(198, 49, 'product-info_1_intro_product_link', 'https://twitter.com/'),
(199, 49, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(200, 49, 'product-info_1_intro_product_image', '48'),
(201, 49, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(202, 49, 'product-info_2_intro_product_name', 'H-Pillow'),
(203, 49, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(204, 49, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(205, 49, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(206, 49, 'product-info_2_intro_product_link', 'https://twitter.com/'),
(207, 49, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(208, 49, 'product-info_2_intro_product_image', '48'),
(209, 49, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(210, 49, 'product-info_3_intro_product_name', 'H-Pillow'),
(211, 49, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(212, 49, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(213, 49, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(214, 49, 'product-info_3_intro_product_link', 'https://twitter.com/'),
(215, 49, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(216, 49, 'product-info_3_intro_product_image', '48'),
(217, 49, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(218, 49, 'product-info', '4'),
(219, 49, '_product-info', 'field_5c24fc17c2302'),
(220, 50, '_wc_review_count', '0'),
(221, 50, '_wc_rating_count', 'a:0:{}'),
(222, 50, '_wc_average_rating', '0'),
(223, 50, '_edit_last', '1'),
(224, 50, '_edit_lock', '1546502408:1'),
(225, 50, '_sku', ''),
(226, 50, '_regular_price', '100'),
(227, 50, '_sale_price', '90'),
(228, 50, '_sale_price_dates_from', ''),
(229, 50, '_sale_price_dates_to', ''),
(230, 50, 'total_sales', '0'),
(231, 50, '_tax_status', 'taxable'),
(232, 50, '_tax_class', ''),
(233, 50, '_manage_stock', 'no'),
(234, 50, '_backorders', 'no'),
(235, 50, '_low_stock_amount', ''),
(236, 50, '_sold_individually', 'no'),
(237, 50, '_weight', ''),
(238, 50, '_length', ''),
(239, 50, '_width', ''),
(240, 50, '_height', ''),
(241, 50, '_upsell_ids', 'a:0:{}') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(242, 50, '_crosssell_ids', 'a:0:{}'),
(243, 50, '_purchase_note', ''),
(244, 50, '_default_attributes', 'a:0:{}'),
(245, 50, '_virtual', 'no'),
(246, 50, '_downloadable', 'no'),
(247, 50, '_product_image_gallery', ''),
(248, 50, '_download_limit', '-1'),
(249, 50, '_download_expiry', '-1'),
(250, 50, '_stock', NULL),
(251, 50, '_stock_status', 'instock'),
(252, 50, '_product_version', '3.5.3'),
(253, 50, '_price', '90'),
(254, 51, '_wc_review_count', '0'),
(255, 51, '_wc_rating_count', 'a:0:{}'),
(256, 51, '_wc_average_rating', '0'),
(257, 51, '_edit_last', '1'),
(258, 51, '_edit_lock', '1549557163:1'),
(259, 51, '_sku', ''),
(260, 51, '_regular_price', '100'),
(261, 51, '_sale_price', '90'),
(262, 51, '_sale_price_dates_from', ''),
(263, 51, '_sale_price_dates_to', ''),
(264, 51, 'total_sales', '0'),
(265, 51, '_tax_status', 'taxable'),
(266, 51, '_tax_class', ''),
(267, 51, '_manage_stock', 'no'),
(268, 51, '_backorders', 'no'),
(269, 51, '_low_stock_amount', ''),
(270, 51, '_sold_individually', 'no'),
(271, 51, '_weight', ''),
(272, 51, '_length', ''),
(273, 51, '_width', ''),
(274, 51, '_height', ''),
(275, 51, '_upsell_ids', 'a:0:{}'),
(276, 51, '_crosssell_ids', 'a:0:{}'),
(277, 51, '_purchase_note', ''),
(278, 51, '_default_attributes', 'a:0:{}'),
(279, 51, '_virtual', 'no'),
(280, 51, '_downloadable', 'no'),
(281, 51, '_product_image_gallery', ''),
(282, 51, '_download_limit', '-1'),
(283, 51, '_download_expiry', '-1'),
(284, 51, '_stock', NULL),
(285, 51, '_stock_status', 'instock'),
(286, 51, '_product_version', '3.5.3'),
(287, 51, '_price', '90'),
(289, 51, '_thumbnail_id', '77'),
(290, 50, '_thumbnail_id', '76'),
(291, 39, '_thumbnail_id', '75'),
(292, 12, '_thumbnail_id', '74'),
(293, 52, '_edit_last', '1'),
(294, 52, '_edit_lock', '1546419759:1'),
(295, 19, 'best_deal_product_name', 'Best deal product'),
(296, 19, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(297, 19, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(298, 19, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(299, 19, 'best_deal_product_link', 'https://twitter.com/'),
(300, 19, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(301, 57, 'product-info_0_intro_product_name', 'H-Pillow'),
(302, 57, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(303, 57, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(304, 57, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(305, 57, 'product-info_0_intro_product_link', 'https://twitter.com/'),
(306, 57, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(307, 57, 'product-info_0_intro_product_image', '48'),
(308, 57, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(309, 57, 'product-info_1_intro_product_name', 'H-Pillow'),
(310, 57, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(311, 57, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(312, 57, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(313, 57, 'product-info_1_intro_product_link', 'https://twitter.com/'),
(314, 57, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(315, 57, 'product-info_1_intro_product_image', '48'),
(316, 57, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(317, 57, 'product-info_2_intro_product_name', 'H-Pillow'),
(318, 57, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(319, 57, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(320, 57, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(321, 57, 'product-info_2_intro_product_link', 'https://twitter.com/'),
(322, 57, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(323, 57, 'product-info_2_intro_product_image', '48'),
(324, 57, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(325, 57, 'product-info_3_intro_product_name', 'H-Pillow'),
(326, 57, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(327, 57, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(328, 57, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(329, 57, 'product-info_3_intro_product_link', 'https://twitter.com/'),
(330, 57, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(331, 57, 'product-info_3_intro_product_image', '48'),
(332, 57, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(333, 57, 'product-info', '4'),
(334, 57, '_product-info', 'field_5c24fc17c2302'),
(335, 57, 'best_deal_product_name', 'Best deal product'),
(336, 57, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(337, 57, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(338, 57, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(339, 57, 'best_deal_product_link', 'https://twitter.com/'),
(340, 57, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(341, 59, '_wp_attached_file', '2018/12/best-deal_product.png'),
(342, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1620;s:6:"height";i:1059;s:4:"file";s:29:"2018/12/best-deal_product.png";s:5:"sizes";a:12:{s:17:"custom-size-large";a:4:{s:4:"file";s:29:"best-deal_product-300x220.png";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:29:"best-deal_product-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:29:"best-deal_product-300x196.png";s:5:"width";i:300;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:29:"best-deal_product-768x502.png";s:5:"width";i:768;s:6:"height";i:502;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:30:"best-deal_product-1024x669.png";s:5:"width";i:1024;s:6:"height";i:669;s:9:"mime-type";s:9:"image/png";}s:17:"custom-size-small";a:4:{s:4:"file";s:27:"best-deal_product-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:29:"best-deal_product-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:29:"best-deal_product-600x392.png";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:9:"image/png";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:29:"best-deal_product-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:29:"best-deal_product-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:29:"best-deal_product-600x392.png";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:29:"best-deal_product-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(343, 59, '_wp_attachment_image_alt', 'best-deal-product'),
(344, 19, 'best_deal_title', 'Best deal product'),
(345, 19, '_best_deal_title', 'field_5c29e394dd2bf'),
(346, 19, 'best_deal_product_image', '59'),
(347, 19, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(348, 60, 'product-info_0_intro_product_name', 'H-Pillow'),
(349, 60, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(350, 60, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(351, 60, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(352, 60, 'product-info_0_intro_product_link', 'https://twitter.com/'),
(353, 60, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(354, 60, 'product-info_0_intro_product_image', '48'),
(355, 60, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(356, 60, 'product-info_1_intro_product_name', 'H-Pillow'),
(357, 60, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(358, 60, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(359, 60, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(360, 60, 'product-info_1_intro_product_link', 'https://twitter.com/'),
(361, 60, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(362, 60, 'product-info_1_intro_product_image', '48'),
(363, 60, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(364, 60, 'product-info_2_intro_product_name', 'H-Pillow'),
(365, 60, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(366, 60, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(367, 60, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(368, 60, 'product-info_2_intro_product_link', 'https://twitter.com/'),
(369, 60, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(370, 60, 'product-info_2_intro_product_image', '48'),
(371, 60, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(372, 60, 'product-info_3_intro_product_name', 'H-Pillow'),
(373, 60, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(374, 60, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(375, 60, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(376, 60, 'product-info_3_intro_product_link', 'https://twitter.com/'),
(377, 60, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(378, 60, 'product-info_3_intro_product_image', '48'),
(379, 60, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(380, 60, 'product-info', '4'),
(381, 60, '_product-info', 'field_5c24fc17c2302'),
(382, 60, 'best_deal_product_name', 'Best deal product'),
(383, 60, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(384, 60, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(385, 60, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(386, 60, 'best_deal_product_link', 'https://twitter.com/'),
(387, 60, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(388, 60, 'best_deal_title', 'Best deal product'),
(389, 60, '_best_deal_title', 'field_5c29e394dd2bf'),
(390, 60, 'best_deal_product_image', '59'),
(391, 60, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(392, 19, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(393, 19, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(394, 19, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(395, 19, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(396, 19, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(397, 19, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(398, 19, 'best_deal_product_0_best_deal_image', '59'),
(399, 19, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(400, 19, 'best_deal_product', '1'),
(401, 19, '_best_deal_product', 'field_5c29e37d3481d'),
(402, 65, 'product-info_0_intro_product_name', 'H-Pillow'),
(403, 65, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(404, 65, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(405, 65, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(406, 65, 'product-info_0_intro_product_link', 'https://twitter.com/'),
(407, 65, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(408, 65, 'product-info_0_intro_product_image', '48'),
(409, 65, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(410, 65, 'product-info_1_intro_product_name', 'H-Pillow'),
(411, 65, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(412, 65, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(413, 65, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(414, 65, 'product-info_1_intro_product_link', 'https://twitter.com/'),
(415, 65, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(416, 65, 'product-info_1_intro_product_image', '48'),
(417, 65, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(418, 65, 'product-info_2_intro_product_name', 'H-Pillow'),
(419, 65, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(420, 65, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(421, 65, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(422, 65, 'product-info_2_intro_product_link', 'https://twitter.com/'),
(423, 65, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(424, 65, 'product-info_2_intro_product_image', '48'),
(425, 65, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(426, 65, 'product-info_3_intro_product_name', 'H-Pillow'),
(427, 65, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(428, 65, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(429, 65, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(430, 65, 'product-info_3_intro_product_link', 'https://twitter.com/'),
(431, 65, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(432, 65, 'product-info_3_intro_product_image', '48'),
(433, 65, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(434, 65, 'product-info', '4'),
(435, 65, '_product-info', 'field_5c24fc17c2302'),
(436, 65, 'best_deal_product_name', 'Best deal product'),
(437, 65, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(438, 65, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(439, 65, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(440, 65, 'best_deal_product_link', 'https://twitter.com/'),
(441, 65, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(442, 65, 'best_deal_title', 'Best deal product') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(443, 65, '_best_deal_title', 'field_5c29e394dd2bf'),
(444, 65, 'best_deal_product_image', '59'),
(445, 65, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(446, 65, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(447, 65, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(448, 65, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(449, 65, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(450, 65, 'best_deal_product_0_best_deal_product_link', 'https://twitter.com/'),
(451, 65, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(452, 65, 'best_deal_product_0_best_deal_image', '59'),
(453, 65, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(454, 65, 'best_deal_product', '1'),
(455, 65, '_best_deal_product', 'field_5c29e37d3481d'),
(456, 68, '_edit_last', '1'),
(457, 68, '_edit_lock', '1546254740:1'),
(458, 19, 'popular_products_title', 'Popular products'),
(459, 19, '_popular_products_title', 'field_5c29f81657533'),
(460, 19, 'section_title', 'Best deal product'),
(461, 19, '_section_title', 'field_5c29f6be784a2'),
(462, 70, 'product-info_0_intro_product_name', 'H-Pillow'),
(463, 70, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(464, 70, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(465, 70, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(466, 70, 'product-info_0_intro_product_link', 'https://twitter.com/'),
(467, 70, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(468, 70, 'product-info_0_intro_product_image', '48'),
(469, 70, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(470, 70, 'product-info_1_intro_product_name', 'H-Pillow'),
(471, 70, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(472, 70, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(473, 70, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(474, 70, 'product-info_1_intro_product_link', 'https://twitter.com/'),
(475, 70, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(476, 70, 'product-info_1_intro_product_image', '48'),
(477, 70, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(478, 70, 'product-info_2_intro_product_name', 'H-Pillow'),
(479, 70, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(480, 70, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(481, 70, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(482, 70, 'product-info_2_intro_product_link', 'https://twitter.com/'),
(483, 70, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(484, 70, 'product-info_2_intro_product_image', '48'),
(485, 70, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(486, 70, 'product-info_3_intro_product_name', 'H-Pillow'),
(487, 70, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(488, 70, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(489, 70, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(490, 70, 'product-info_3_intro_product_link', 'https://twitter.com/'),
(491, 70, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(492, 70, 'product-info_3_intro_product_image', '48'),
(493, 70, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(494, 70, 'product-info', '4'),
(495, 70, '_product-info', 'field_5c24fc17c2302'),
(496, 70, 'best_deal_product_name', 'Best deal product'),
(497, 70, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(498, 70, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(499, 70, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(500, 70, 'best_deal_product_link', 'https://twitter.com/'),
(501, 70, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(502, 70, 'best_deal_title', 'Best deal product'),
(503, 70, '_best_deal_title', 'field_5c29e394dd2bf'),
(504, 70, 'best_deal_product_image', '59'),
(505, 70, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(506, 70, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(507, 70, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(508, 70, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(509, 70, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(510, 70, 'best_deal_product_0_best_deal_product_link', 'https://twitter.com/'),
(511, 70, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(512, 70, 'best_deal_product_0_best_deal_image', '59'),
(513, 70, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(514, 70, 'best_deal_product', '1'),
(515, 70, '_best_deal_product', 'field_5c29e37d3481d'),
(516, 70, 'popular_products_title', 'Popular products'),
(517, 70, '_popular_products_title', 'field_5c29f81657533'),
(518, 70, 'section_title', 'Best deal product'),
(519, 70, '_section_title', 'field_5c29f6be784a2'),
(520, 71, '_edit_last', '1'),
(521, 71, '_edit_lock', '1546254754:1'),
(522, 19, 'latest_product_title', 'Latest products'),
(523, 19, '_latest_product_title', 'field_5c29f97f765f7'),
(524, 73, 'product-info_0_intro_product_name', 'H-Pillow'),
(525, 73, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(526, 73, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(527, 73, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(528, 73, 'product-info_0_intro_product_link', 'https://twitter.com/'),
(529, 73, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(530, 73, 'product-info_0_intro_product_image', '48'),
(531, 73, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(532, 73, 'product-info_1_intro_product_name', 'H-Pillow'),
(533, 73, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(534, 73, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(535, 73, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(536, 73, 'product-info_1_intro_product_link', 'https://twitter.com/'),
(537, 73, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(538, 73, 'product-info_1_intro_product_image', '48'),
(539, 73, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(540, 73, 'product-info_2_intro_product_name', 'H-Pillow'),
(541, 73, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(542, 73, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(543, 73, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(544, 73, 'product-info_2_intro_product_link', 'https://twitter.com/'),
(545, 73, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(546, 73, 'product-info_2_intro_product_image', '48'),
(547, 73, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(548, 73, 'product-info_3_intro_product_name', 'H-Pillow'),
(549, 73, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(550, 73, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(551, 73, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(552, 73, 'product-info_3_intro_product_link', 'https://twitter.com/'),
(553, 73, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(554, 73, 'product-info_3_intro_product_image', '48'),
(555, 73, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(556, 73, 'product-info', '4'),
(557, 73, '_product-info', 'field_5c24fc17c2302'),
(558, 73, 'best_deal_product_name', 'Best deal product'),
(559, 73, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(560, 73, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(561, 73, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(562, 73, 'best_deal_product_link', 'https://twitter.com/'),
(563, 73, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(564, 73, 'best_deal_title', 'Best deal product'),
(565, 73, '_best_deal_title', 'field_5c29e394dd2bf'),
(566, 73, 'best_deal_product_image', '59'),
(567, 73, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(568, 73, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(569, 73, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(570, 73, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(571, 73, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(572, 73, 'best_deal_product_0_best_deal_product_link', 'https://twitter.com/'),
(573, 73, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(574, 73, 'best_deal_product_0_best_deal_image', '59'),
(575, 73, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(576, 73, 'best_deal_product', '1'),
(577, 73, '_best_deal_product', 'field_5c29e37d3481d'),
(578, 73, 'popular_products_title', 'Popular products'),
(579, 73, '_popular_products_title', 'field_5c29f81657533'),
(580, 73, 'section_title', 'Best deal product'),
(581, 73, '_section_title', 'field_5c29f6be784a2'),
(582, 73, 'latest_product_title', 'Latest products'),
(583, 73, '_latest_product_title', 'field_5c29f97f765f7'),
(584, 74, '_wp_attached_file', '2018/12/product-image-1.jpg'),
(585, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1620;s:6:"height";i:1059;s:4:"file";s:27:"2018/12/product-image-1.jpg";s:5:"sizes";a:12:{s:17:"custom-size-large";a:4:{s:4:"file";s:27:"product-image-1-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:27:"product-image-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"product-image-1-300x196.jpg";s:5:"width";i:300;s:6:"height";i:196;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"product-image-1-768x502.jpg";s:5:"width";i:768;s:6:"height";i:502;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"product-image-1-1024x669.jpg";s:5:"width";i:1024;s:6:"height";i:669;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:25:"product-image-1-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:27:"product-image-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:27:"product-image-1-600x392.jpg";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:27:"product-image-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:27:"product-image-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:27:"product-image-1-600x392.jpg";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:27:"product-image-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(586, 74, '_wp_attachment_image_alt', 'product-image'),
(587, 75, '_wp_attached_file', '2018/12/product-image-2.jpg'),
(588, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1620;s:6:"height";i:1059;s:4:"file";s:27:"2018/12/product-image-2.jpg";s:5:"sizes";a:12:{s:17:"custom-size-large";a:4:{s:4:"file";s:27:"product-image-2-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:27:"product-image-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"product-image-2-300x196.jpg";s:5:"width";i:300;s:6:"height";i:196;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"product-image-2-768x502.jpg";s:5:"width";i:768;s:6:"height";i:502;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"product-image-2-1024x669.jpg";s:5:"width";i:1024;s:6:"height";i:669;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:25:"product-image-2-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:27:"product-image-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:27:"product-image-2-600x392.jpg";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:27:"product-image-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:27:"product-image-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:27:"product-image-2-600x392.jpg";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:27:"product-image-2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(589, 75, '_wp_attachment_image_alt', 'product-image'),
(590, 76, '_wp_attached_file', '2018/12/product-image-3.jpg'),
(591, 76, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1620;s:6:"height";i:1059;s:4:"file";s:27:"2018/12/product-image-3.jpg";s:5:"sizes";a:12:{s:17:"custom-size-large";a:4:{s:4:"file";s:27:"product-image-3-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:27:"product-image-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"product-image-3-300x196.jpg";s:5:"width";i:300;s:6:"height";i:196;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"product-image-3-768x502.jpg";s:5:"width";i:768;s:6:"height";i:502;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"product-image-3-1024x669.jpg";s:5:"width";i:1024;s:6:"height";i:669;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:25:"product-image-3-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:27:"product-image-3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:27:"product-image-3-600x392.jpg";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:27:"product-image-3-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:27:"product-image-3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:27:"product-image-3-600x392.jpg";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:27:"product-image-3-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(592, 76, '_wp_attachment_image_alt', 'product-image'),
(593, 77, '_wp_attached_file', '2018/12/product-image-4.jpg'),
(594, 77, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1620;s:6:"height";i:1059;s:4:"file";s:27:"2018/12/product-image-4.jpg";s:5:"sizes";a:12:{s:17:"custom-size-large";a:4:{s:4:"file";s:27:"product-image-4-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:27:"product-image-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"product-image-4-300x196.jpg";s:5:"width";i:300;s:6:"height";i:196;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"product-image-4-768x502.jpg";s:5:"width";i:768;s:6:"height";i:502;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"product-image-4-1024x669.jpg";s:5:"width";i:1024;s:6:"height";i:669;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:25:"product-image-4-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:27:"product-image-4-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:27:"product-image-4-600x392.jpg";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:27:"product-image-4-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:27:"product-image-4-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:27:"product-image-4-600x392.jpg";s:5:"width";i:600;s:6:"height";i:392;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:27:"product-image-4-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(595, 77, '_wp_attachment_image_alt', 'product-image'),
(596, 78, '_wc_review_count', '0'),
(597, 78, '_wc_rating_count', 'a:0:{}'),
(598, 78, '_wc_average_rating', '0'),
(599, 78, '_edit_last', '1'),
(600, 78, '_edit_lock', '1546502419:1'),
(601, 79, '_wp_attached_file', '2019/01/product-image.png'),
(602, 79, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:765;s:6:"height";i:909;s:4:"file";s:25:"2019/01/product-image.png";s:5:"sizes";a:10:{s:17:"custom-size-large";a:4:{s:4:"file";s:25:"product-image-300x220.png";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"product-image-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"product-image-252x300.png";s:5:"width";i:252;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:17:"custom-size-small";a:4:{s:4:"file";s:23:"product-image-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:25:"product-image-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:25:"product-image-600x713.png";s:5:"width";i:600;s:6:"height";i:713;s:9:"mime-type";s:9:"image/png";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:25:"product-image-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"product-image-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:25:"product-image-600x713.png";s:5:"width";i:600;s:6:"height";i:713;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:25:"product-image-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(603, 79, '_wp_attachment_image_alt', 'product-image'),
(604, 78, '_thumbnail_id', '79'),
(605, 78, '_sku', ''),
(606, 78, '_regular_price', '100'),
(607, 78, '_sale_price', '90'),
(608, 78, '_sale_price_dates_from', ''),
(609, 78, '_sale_price_dates_to', ''),
(610, 78, 'total_sales', '0'),
(611, 78, '_tax_status', 'taxable'),
(612, 78, '_tax_class', ''),
(613, 78, '_manage_stock', 'no'),
(614, 78, '_backorders', 'no'),
(615, 78, '_low_stock_amount', ''),
(616, 78, '_sold_individually', 'no'),
(617, 78, '_weight', ''),
(618, 78, '_length', ''),
(619, 78, '_width', ''),
(620, 78, '_height', ''),
(621, 78, '_upsell_ids', 'a:0:{}'),
(622, 78, '_crosssell_ids', 'a:0:{}'),
(623, 78, '_purchase_note', ''),
(624, 78, '_default_attributes', 'a:0:{}'),
(625, 78, '_virtual', 'no'),
(626, 78, '_downloadable', 'no'),
(627, 78, '_product_image_gallery', ''),
(628, 78, '_download_limit', '-1'),
(629, 78, '_download_expiry', '-1'),
(630, 78, '_stock', NULL),
(631, 78, '_stock_status', 'instock'),
(632, 78, '_product_version', '3.5.3'),
(633, 78, '_price', '90'),
(634, 80, '_wc_review_count', '0'),
(635, 80, '_wc_rating_count', 'a:0:{}'),
(636, 80, '_wc_average_rating', '0'),
(637, 80, '_edit_last', '1'),
(638, 80, '_edit_lock', '1546589620:1'),
(639, 80, '_thumbnail_id', '13'),
(640, 80, '_sku', ''),
(641, 80, '_regular_price', '100'),
(642, 80, '_sale_price', '90') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(643, 80, '_sale_price_dates_from', ''),
(644, 80, '_sale_price_dates_to', ''),
(645, 80, 'total_sales', '0'),
(646, 80, '_tax_status', 'taxable'),
(647, 80, '_tax_class', ''),
(648, 80, '_manage_stock', 'no'),
(649, 80, '_backorders', 'no'),
(650, 80, '_low_stock_amount', ''),
(651, 80, '_sold_individually', 'no'),
(652, 80, '_weight', ''),
(653, 80, '_length', ''),
(654, 80, '_width', ''),
(655, 80, '_height', ''),
(656, 80, '_upsell_ids', 'a:0:{}'),
(657, 80, '_crosssell_ids', 'a:0:{}'),
(658, 80, '_purchase_note', ''),
(659, 80, '_default_attributes', 'a:0:{}'),
(660, 80, '_virtual', 'no'),
(661, 80, '_downloadable', 'no'),
(662, 80, '_product_image_gallery', ''),
(663, 80, '_download_limit', '-1'),
(664, 80, '_download_expiry', '-1'),
(665, 80, '_stock', NULL),
(666, 80, '_stock_status', 'instock'),
(667, 80, '_product_version', '3.5.3'),
(668, 80, '_price', '90'),
(669, 81, '_wc_review_count', '0'),
(670, 81, '_wc_rating_count', 'a:0:{}'),
(671, 81, '_wc_average_rating', '0'),
(672, 81, '_edit_last', '1'),
(673, 81, '_thumbnail_id', '13'),
(674, 81, '_sku', ''),
(675, 81, '_regular_price', '100'),
(676, 81, '_sale_price', '90'),
(677, 81, '_sale_price_dates_from', ''),
(678, 81, '_sale_price_dates_to', ''),
(679, 81, 'total_sales', '0'),
(680, 81, '_tax_status', 'taxable'),
(681, 81, '_tax_class', ''),
(682, 81, '_manage_stock', 'no'),
(683, 81, '_backorders', 'no'),
(684, 81, '_low_stock_amount', ''),
(685, 81, '_sold_individually', 'no'),
(686, 81, '_weight', ''),
(687, 81, '_length', ''),
(688, 81, '_width', ''),
(689, 81, '_height', ''),
(690, 81, '_upsell_ids', 'a:0:{}'),
(691, 81, '_crosssell_ids', 'a:0:{}'),
(692, 81, '_purchase_note', ''),
(693, 81, '_default_attributes', 'a:0:{}'),
(694, 81, '_virtual', 'no'),
(695, 81, '_downloadable', 'no'),
(696, 81, '_product_image_gallery', ''),
(697, 81, '_download_limit', '-1'),
(698, 81, '_download_expiry', '-1'),
(699, 81, '_stock', NULL),
(700, 81, '_stock_status', 'instock'),
(701, 81, '_product_version', '3.5.3'),
(702, 81, '_price', '90'),
(703, 81, '_edit_lock', '1546589621:1'),
(704, 82, '_wc_review_count', '0'),
(705, 82, '_wc_rating_count', 'a:0:{}'),
(706, 82, '_wc_average_rating', '0'),
(707, 82, '_edit_last', '1'),
(708, 82, '_edit_lock', '1549466894:1'),
(709, 82, '_thumbnail_id', '48'),
(710, 82, '_sku', ''),
(711, 82, '_regular_price', '100'),
(712, 82, '_sale_price', '90'),
(713, 82, '_sale_price_dates_from', ''),
(714, 82, '_sale_price_dates_to', ''),
(715, 82, 'total_sales', '0'),
(716, 82, '_tax_status', 'taxable'),
(717, 82, '_tax_class', ''),
(718, 82, '_manage_stock', 'no'),
(719, 82, '_backorders', 'no'),
(720, 82, '_low_stock_amount', ''),
(721, 82, '_sold_individually', 'no'),
(722, 82, '_weight', ''),
(723, 82, '_length', ''),
(724, 82, '_width', ''),
(725, 82, '_height', ''),
(726, 82, '_upsell_ids', 'a:0:{}'),
(727, 82, '_crosssell_ids', 'a:0:{}'),
(728, 82, '_purchase_note', ''),
(729, 82, '_default_attributes', 'a:0:{}'),
(730, 82, '_virtual', 'no'),
(731, 82, '_downloadable', 'no'),
(732, 82, '_product_image_gallery', ''),
(733, 82, '_download_limit', '-1'),
(734, 82, '_download_expiry', '-1'),
(735, 82, '_stock', NULL),
(736, 82, '_stock_status', 'instock'),
(737, 82, '_product_version', '3.5.3'),
(738, 82, '_price', '90'),
(745, 86, 'product-info_0_intro_product_name', 'H-Pillow'),
(746, 86, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(747, 86, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(748, 86, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(749, 86, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(750, 86, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(751, 86, 'product-info_0_intro_product_image', '48'),
(752, 86, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(753, 86, 'product-info_1_intro_product_name', 'H-Pillow'),
(754, 86, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(755, 86, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(756, 86, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(757, 86, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(758, 86, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(759, 86, 'product-info_1_intro_product_image', '48'),
(760, 86, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(761, 86, 'product-info_2_intro_product_name', 'H-Pillow'),
(762, 86, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(763, 86, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(764, 86, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(765, 86, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(766, 86, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(767, 86, 'product-info_2_intro_product_image', '48'),
(768, 86, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(769, 86, 'product-info_3_intro_product_name', 'H-Pillow'),
(770, 86, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(771, 86, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(772, 86, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(773, 86, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(774, 86, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(775, 86, 'product-info_3_intro_product_image', '48'),
(776, 86, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(777, 86, 'product-info', '4'),
(778, 86, '_product-info', 'field_5c24fc17c2302'),
(779, 86, 'best_deal_product_name', 'Best deal product'),
(780, 86, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(781, 86, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(782, 86, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(783, 86, 'best_deal_product_link', 'https://twitter.com/'),
(784, 86, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(785, 86, 'best_deal_title', 'Best deal product'),
(786, 86, '_best_deal_title', 'field_5c29e394dd2bf'),
(787, 86, 'best_deal_product_image', '59'),
(788, 86, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(789, 86, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(790, 86, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(791, 86, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(792, 86, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(793, 86, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(794, 86, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(795, 86, 'best_deal_product_0_best_deal_image', '59'),
(796, 86, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(797, 86, 'best_deal_product', '1'),
(798, 86, '_best_deal_product', 'field_5c29e37d3481d'),
(799, 86, 'popular_products_title', 'Popular products'),
(800, 86, '_popular_products_title', 'field_5c29f81657533'),
(801, 86, 'section_title', 'Best deal product'),
(802, 86, '_section_title', 'field_5c29f6be784a2'),
(803, 86, 'latest_product_title', 'Latest products'),
(804, 86, '_latest_product_title', 'field_5c29f97f765f7'),
(805, 19, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(806, 19, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(807, 88, 'product-info_0_intro_product_name', 'H-Pillow'),
(808, 88, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(809, 88, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(810, 88, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(811, 88, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(812, 88, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(813, 88, 'product-info_0_intro_product_image', '48'),
(814, 88, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(815, 88, 'product-info_1_intro_product_name', 'H-Pillow'),
(816, 88, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(817, 88, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(818, 88, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(819, 88, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(820, 88, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(821, 88, 'product-info_1_intro_product_image', '48'),
(822, 88, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(823, 88, 'product-info_2_intro_product_name', 'H-Pillow'),
(824, 88, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(825, 88, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(826, 88, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(827, 88, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(828, 88, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(829, 88, 'product-info_2_intro_product_image', '48'),
(830, 88, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(831, 88, 'product-info_3_intro_product_name', 'H-Pillow'),
(832, 88, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(833, 88, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(834, 88, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(835, 88, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(836, 88, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(837, 88, 'product-info_3_intro_product_image', '48'),
(838, 88, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(839, 88, 'product-info', '4'),
(840, 88, '_product-info', 'field_5c24fc17c2302'),
(841, 88, 'best_deal_product_name', 'Best deal product'),
(842, 88, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(843, 88, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(844, 88, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(845, 88, 'best_deal_product_link', 'https://twitter.com/'),
(846, 88, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(847, 88, 'best_deal_title', 'Best deal product'),
(848, 88, '_best_deal_title', 'field_5c29e394dd2bf') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(849, 88, 'best_deal_product_image', '59'),
(850, 88, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(851, 88, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(852, 88, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(853, 88, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(854, 88, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(855, 88, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(856, 88, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(857, 88, 'best_deal_product_0_best_deal_image', '59'),
(858, 88, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(859, 88, 'best_deal_product', '1'),
(860, 88, '_best_deal_product', 'field_5c29e37d3481d'),
(861, 88, 'popular_products_title', 'Popular products'),
(862, 88, '_popular_products_title', 'field_5c29f81657533'),
(863, 88, 'section_title', 'Best deal product'),
(864, 88, '_section_title', 'field_5c29f6be784a2'),
(865, 88, 'latest_product_title', 'Latest products'),
(866, 88, '_latest_product_title', 'field_5c29f97f765f7'),
(867, 88, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(868, 88, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(869, 19, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(870, 19, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(871, 89, 'product-info_0_intro_product_name', 'H-Pillow'),
(872, 89, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(873, 89, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(874, 89, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(875, 89, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(876, 89, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(877, 89, 'product-info_0_intro_product_image', '48'),
(878, 89, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(879, 89, 'product-info_1_intro_product_name', 'H-Pillow'),
(880, 89, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(881, 89, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(882, 89, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(883, 89, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(884, 89, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(885, 89, 'product-info_1_intro_product_image', '48'),
(886, 89, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(887, 89, 'product-info_2_intro_product_name', 'H-Pillow'),
(888, 89, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(889, 89, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(890, 89, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(891, 89, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(892, 89, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(893, 89, 'product-info_2_intro_product_image', '48'),
(894, 89, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(895, 89, 'product-info_3_intro_product_name', 'H-Pillow'),
(896, 89, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(897, 89, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(898, 89, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(899, 89, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(900, 89, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(901, 89, 'product-info_3_intro_product_image', '48'),
(902, 89, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(903, 89, 'product-info', '4'),
(904, 89, '_product-info', 'field_5c24fc17c2302'),
(905, 89, 'best_deal_product_name', 'Best deal product'),
(906, 89, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(907, 89, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(908, 89, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(909, 89, 'best_deal_product_link', 'https://twitter.com/'),
(910, 89, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(911, 89, 'best_deal_title', 'Best deal product'),
(912, 89, '_best_deal_title', 'field_5c29e394dd2bf'),
(913, 89, 'best_deal_product_image', '59'),
(914, 89, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(915, 89, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(916, 89, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(917, 89, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(918, 89, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(919, 89, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(920, 89, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(921, 89, 'best_deal_product_0_best_deal_image', '59'),
(922, 89, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(923, 89, 'best_deal_product', '1'),
(924, 89, '_best_deal_product', 'field_5c29e37d3481d'),
(925, 89, 'popular_products_title', 'Popular products'),
(926, 89, '_popular_products_title', 'field_5c29f81657533'),
(927, 89, 'section_title', 'Best deal product'),
(928, 89, '_section_title', 'field_5c29f6be784a2'),
(929, 89, 'latest_product_title', 'Latest products'),
(930, 89, '_latest_product_title', 'field_5c29f97f765f7'),
(931, 89, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(932, 89, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(933, 89, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(934, 89, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(945, 92, '_edit_last', '1'),
(946, 92, '_edit_lock', '1546607892:1'),
(949, 95, '_edit_last', '1'),
(950, 95, '_edit_lock', '1548938285:1'),
(951, 98, '_edit_last', '1'),
(952, 98, '_edit_lock', '1546438779:1'),
(955, 104, 'product-info_0_intro_product_name', 'H-Pillow'),
(956, 104, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(957, 104, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight'),
(958, 104, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(959, 104, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(960, 104, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(961, 104, 'product-info_0_intro_product_image', '79'),
(962, 104, '_product-info_0_intro_product_image', 'field_5c24fc80c2305') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(963, 104, 'product-info_1_intro_product_name', 'H-Pillow'),
(964, 104, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(965, 104, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(966, 104, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(967, 104, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(968, 104, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(969, 104, 'product-info_1_intro_product_image', '48'),
(970, 104, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(971, 104, 'product-info_2_intro_product_name', 'H-Pillow'),
(972, 104, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(973, 104, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(974, 104, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(975, 104, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(976, 104, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(977, 104, 'product-info_2_intro_product_image', '48'),
(978, 104, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(979, 104, 'product-info_3_intro_product_name', 'H-Pillow'),
(980, 104, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(981, 104, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(982, 104, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(983, 104, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(984, 104, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(985, 104, 'product-info_3_intro_product_image', '48'),
(986, 104, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(987, 104, 'product-info', '4'),
(988, 104, '_product-info', 'field_5c24fc17c2302'),
(989, 104, 'best_deal_product_name', 'Best deal product'),
(990, 104, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(991, 104, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(992, 104, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(993, 104, 'best_deal_product_link', 'https://twitter.com/'),
(994, 104, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(995, 104, 'best_deal_title', 'Best deal product'),
(996, 104, '_best_deal_title', 'field_5c29e394dd2bf'),
(997, 104, 'best_deal_product_image', '59'),
(998, 104, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(999, 104, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1000, 104, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1001, 104, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1002, 104, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1003, 104, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1004, 104, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(1005, 104, 'best_deal_product_0_best_deal_image', '59'),
(1006, 104, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1007, 104, 'best_deal_product', '1'),
(1008, 104, '_best_deal_product', 'field_5c29e37d3481d'),
(1009, 104, 'popular_products_title', 'Popular products'),
(1010, 104, '_popular_products_title', 'field_5c29f81657533'),
(1011, 104, 'section_title', 'Best deal product'),
(1012, 104, '_section_title', 'field_5c29f6be784a2'),
(1013, 104, 'latest_product_title', 'Latest products'),
(1014, 104, '_latest_product_title', 'field_5c29f97f765f7'),
(1015, 104, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1016, 104, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1017, 104, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1018, 104, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1019, 105, 'product-info_0_intro_product_name', 'H-Pillow'),
(1020, 105, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(1021, 105, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight &  Light Weight'),
(1022, 105, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(1023, 105, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1024, 105, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(1025, 105, 'product-info_0_intro_product_image', '79'),
(1026, 105, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(1027, 105, 'product-info_1_intro_product_name', 'H-Pillow'),
(1028, 105, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(1029, 105, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(1030, 105, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(1031, 105, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1032, 105, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(1033, 105, 'product-info_1_intro_product_image', '48'),
(1034, 105, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(1035, 105, 'product-info_2_intro_product_name', 'H-Pillow'),
(1036, 105, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(1037, 105, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(1038, 105, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(1039, 105, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1040, 105, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(1041, 105, 'product-info_2_intro_product_image', '48'),
(1042, 105, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(1043, 105, 'product-info_3_intro_product_name', 'H-Pillow'),
(1044, 105, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(1045, 105, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(1046, 105, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(1047, 105, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1048, 105, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(1049, 105, 'product-info_3_intro_product_image', '48'),
(1050, 105, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(1051, 105, 'product-info', '4'),
(1052, 105, '_product-info', 'field_5c24fc17c2302'),
(1053, 105, 'best_deal_product_name', 'Best deal product'),
(1054, 105, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(1055, 105, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1056, 105, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(1057, 105, 'best_deal_product_link', 'https://twitter.com/'),
(1058, 105, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(1059, 105, 'best_deal_title', 'Best deal product'),
(1060, 105, '_best_deal_title', 'field_5c29e394dd2bf'),
(1061, 105, 'best_deal_product_image', '59'),
(1062, 105, '_best_deal_product_image', 'field_5c29e5f076bb9') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1063, 105, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1064, 105, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1065, 105, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1066, 105, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1067, 105, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1068, 105, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(1069, 105, 'best_deal_product_0_best_deal_image', '59'),
(1070, 105, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1071, 105, 'best_deal_product', '1'),
(1072, 105, '_best_deal_product', 'field_5c29e37d3481d'),
(1073, 105, 'popular_products_title', 'Popular products'),
(1074, 105, '_popular_products_title', 'field_5c29f81657533'),
(1075, 105, 'section_title', 'Best deal product'),
(1076, 105, '_section_title', 'field_5c29f6be784a2'),
(1077, 105, 'latest_product_title', 'Latest products'),
(1078, 105, '_latest_product_title', 'field_5c29f97f765f7'),
(1079, 105, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1080, 105, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1081, 105, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1082, 105, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1083, 106, '_wp_attached_file', '2019/01/product-image-1.png'),
(1084, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:510;s:6:"height";i:606;s:4:"file";s:27:"2019/01/product-image-1.png";s:5:"sizes";a:8:{s:17:"custom-size-large";a:4:{s:4:"file";s:27:"product-image-1-300x220.png";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:27:"product-image-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"product-image-1-252x300.png";s:5:"width";i:252;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:17:"custom-size-small";a:4:{s:4:"file";s:25:"product-image-1-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:27:"product-image-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:27:"product-image-1-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:27:"product-image-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:27:"product-image-1-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1085, 106, '_wp_attachment_image_alt', 'product-image'),
(1086, 107, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(1087, 107, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(1088, 107, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight &  Light Weight'),
(1089, 107, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(1090, 107, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1091, 107, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(1092, 107, 'product-info_0_intro_product_image', '106'),
(1093, 107, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(1094, 107, 'product-info_1_intro_product_name', 'H-Pillow H-Pillow 2'),
(1095, 107, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(1096, 107, 'product-info_1_intro_product_description', 'Ergonomic &  Light Weight'),
(1097, 107, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(1098, 107, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1099, 107, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(1100, 107, 'product-info_1_intro_product_image', '48'),
(1101, 107, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(1102, 107, 'product-info_2_intro_product_name', 'H-Pillow H-Pillow H-Pillow'),
(1103, 107, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(1104, 107, 'product-info_2_intro_product_description', 'Ergonomic &  Light Weight'),
(1105, 107, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(1106, 107, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1107, 107, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(1108, 107, 'product-info_2_intro_product_image', '13'),
(1109, 107, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(1110, 107, 'product-info_3_intro_product_name', 'H-Pillow H-Pillow H-Pillow3'),
(1111, 107, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(1112, 107, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(1113, 107, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(1114, 107, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1115, 107, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(1116, 107, 'product-info_3_intro_product_image', '48'),
(1117, 107, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(1118, 107, 'product-info', '4'),
(1119, 107, '_product-info', 'field_5c24fc17c2302'),
(1120, 107, 'best_deal_product_name', 'Best deal product'),
(1121, 107, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(1122, 107, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1123, 107, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(1124, 107, 'best_deal_product_link', 'https://twitter.com/'),
(1125, 107, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(1126, 107, 'best_deal_title', 'Best deal product'),
(1127, 107, '_best_deal_title', 'field_5c29e394dd2bf'),
(1128, 107, 'best_deal_product_image', '59'),
(1129, 107, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(1130, 107, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1131, 107, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1132, 107, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1133, 107, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1134, 107, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1135, 107, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(1136, 107, 'best_deal_product_0_best_deal_image', '59'),
(1137, 107, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1138, 107, 'best_deal_product', '1'),
(1139, 107, '_best_deal_product', 'field_5c29e37d3481d'),
(1140, 107, 'popular_products_title', 'Popular products'),
(1141, 107, '_popular_products_title', 'field_5c29f81657533'),
(1142, 107, 'section_title', 'Best deal product'),
(1143, 107, '_section_title', 'field_5c29f6be784a2'),
(1144, 107, 'latest_product_title', 'Latest products'),
(1145, 107, '_latest_product_title', 'field_5c29f97f765f7'),
(1146, 107, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1147, 107, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1148, 107, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1149, 107, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1150, 108, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(1151, 108, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(1152, 108, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight Ergonomic2 '),
(1153, 108, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(1154, 108, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1155, 108, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(1156, 108, 'product-info_0_intro_product_image', '106'),
(1157, 108, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(1158, 108, 'product-info_1_intro_product_name', 'H-Pillow 2'),
(1159, 108, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(1160, 108, 'product-info_1_intro_product_description', 'Light Weight Ergonomic2 '),
(1161, 108, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(1162, 108, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1163, 108, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(1164, 108, 'product-info_1_intro_product_image', '48'),
(1165, 108, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(1166, 108, 'product-info_2_intro_product_name', 'H-Pillow 3'),
(1167, 108, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(1168, 108, 'product-info_2_intro_product_description', 'Light Weight Ergonomic3'),
(1169, 108, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(1170, 108, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1171, 108, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(1172, 108, 'product-info_2_intro_product_image', '13'),
(1173, 108, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(1174, 108, 'product-info_3_intro_product_name', 'H-Pillow 4'),
(1175, 108, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(1176, 108, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(1177, 108, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(1178, 108, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1179, 108, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(1180, 108, 'product-info_3_intro_product_image', '48'),
(1181, 108, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(1182, 108, 'product-info', '4'),
(1183, 108, '_product-info', 'field_5c24fc17c2302'),
(1184, 108, 'best_deal_product_name', 'Best deal product'),
(1185, 108, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(1186, 108, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1187, 108, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(1188, 108, 'best_deal_product_link', 'https://twitter.com/'),
(1189, 108, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(1190, 108, 'best_deal_title', 'Best deal product'),
(1191, 108, '_best_deal_title', 'field_5c29e394dd2bf'),
(1192, 108, 'best_deal_product_image', '59'),
(1193, 108, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(1194, 108, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1195, 108, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1196, 108, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1197, 108, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1198, 108, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1199, 108, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(1200, 108, 'best_deal_product_0_best_deal_image', '59'),
(1201, 108, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1202, 108, 'best_deal_product', '1'),
(1203, 108, '_best_deal_product', 'field_5c29e37d3481d'),
(1204, 108, 'popular_products_title', 'Popular products'),
(1205, 108, '_popular_products_title', 'field_5c29f81657533'),
(1206, 108, 'section_title', 'Best deal product'),
(1207, 108, '_section_title', 'field_5c29f6be784a2'),
(1208, 108, 'latest_product_title', 'Latest products'),
(1209, 108, '_latest_product_title', 'field_5c29f97f765f7'),
(1210, 108, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1211, 108, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1212, 108, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1213, 108, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1214, 109, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(1215, 109, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(1216, 109, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight Ergonomic2 '),
(1217, 109, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(1218, 109, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1219, 109, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(1220, 109, 'product-info_0_intro_product_image', '106'),
(1221, 109, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(1222, 109, 'product-info_1_intro_product_name', 'H-Pillow 2'),
(1223, 109, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(1224, 109, 'product-info_1_intro_product_description', 'Light Weight Ergonomic2 Light Weight Ergonomic2 '),
(1225, 109, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(1226, 109, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1227, 109, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(1228, 109, 'product-info_1_intro_product_image', '48'),
(1229, 109, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(1230, 109, 'product-info_2_intro_product_name', 'H-Pillow 3'),
(1231, 109, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(1232, 109, 'product-info_2_intro_product_description', 'Light Weight Ergonomic3'),
(1233, 109, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(1234, 109, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1235, 109, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(1236, 109, 'product-info_2_intro_product_image', '13'),
(1237, 109, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(1238, 109, 'product-info_3_intro_product_name', 'H-Pillow 4'),
(1239, 109, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(1240, 109, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(1241, 109, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(1242, 109, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1243, 109, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(1244, 109, 'product-info_3_intro_product_image', '48'),
(1245, 109, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(1246, 109, 'product-info', '4'),
(1247, 109, '_product-info', 'field_5c24fc17c2302'),
(1248, 109, 'best_deal_product_name', 'Best deal product'),
(1249, 109, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(1250, 109, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1251, 109, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(1252, 109, 'best_deal_product_link', 'https://twitter.com/'),
(1253, 109, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(1254, 109, 'best_deal_title', 'Best deal product'),
(1255, 109, '_best_deal_title', 'field_5c29e394dd2bf'),
(1256, 109, 'best_deal_product_image', '59'),
(1257, 109, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(1258, 109, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1259, 109, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1260, 109, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1261, 109, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1262, 109, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1263, 109, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(1264, 109, 'best_deal_product_0_best_deal_image', '59'),
(1265, 109, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1266, 109, 'best_deal_product', '1'),
(1267, 109, '_best_deal_product', 'field_5c29e37d3481d'),
(1268, 109, 'popular_products_title', 'Popular products'),
(1269, 109, '_popular_products_title', 'field_5c29f81657533'),
(1270, 109, 'section_title', 'Best deal product'),
(1271, 109, '_section_title', 'field_5c29f6be784a2'),
(1272, 109, 'latest_product_title', 'Latest products'),
(1273, 109, '_latest_product_title', 'field_5c29f97f765f7'),
(1274, 109, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1275, 109, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1276, 109, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1277, 109, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1287, 111, '_edit_last', '1'),
(1288, 111, '_edit_lock', '1546525858:1'),
(1289, 113, '_edit_last', '1'),
(1290, 113, '_edit_lock', '1548767907:1'),
(1291, 113, '_wp_page_template', 'tpl-cat.php'),
(1292, 115, '_menu_item_type', 'post_type'),
(1293, 115, '_menu_item_menu_item_parent', '0'),
(1294, 115, '_menu_item_object_id', '113'),
(1295, 115, '_menu_item_object', 'page'),
(1296, 115, '_menu_item_target', ''),
(1297, 115, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1298, 115, '_menu_item_xfn', ''),
(1299, 115, '_menu_item_url', ''),
(1305, 118, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(1306, 118, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(1307, 118, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight Ergonomic2 '),
(1308, 118, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(1309, 118, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1310, 118, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(1311, 118, 'product-info_0_intro_product_image', '48'),
(1312, 118, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(1313, 118, 'product-info_1_intro_product_name', 'H-Pillow 2'),
(1314, 118, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(1315, 118, 'product-info_1_intro_product_description', 'Light Weight Ergonomic2 Light Weight Ergonomic2 '),
(1316, 118, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(1317, 118, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1318, 118, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(1319, 118, 'product-info_1_intro_product_image', '48'),
(1320, 118, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(1321, 118, 'product-info_2_intro_product_name', 'H-Pillow 3'),
(1322, 118, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(1323, 118, 'product-info_2_intro_product_description', 'Light Weight Ergonomic3'),
(1324, 118, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(1325, 118, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1326, 118, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(1327, 118, 'product-info_2_intro_product_image', '48'),
(1328, 118, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(1329, 118, 'product-info_3_intro_product_name', 'H-Pillow 4'),
(1330, 118, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(1331, 118, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(1332, 118, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(1333, 118, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1334, 118, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(1335, 118, 'product-info_3_intro_product_image', '48'),
(1336, 118, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(1337, 118, 'product-info', '4'),
(1338, 118, '_product-info', 'field_5c24fc17c2302'),
(1339, 118, 'best_deal_product_name', 'Best deal product'),
(1340, 118, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(1341, 118, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1342, 118, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(1343, 118, 'best_deal_product_link', 'https://twitter.com/'),
(1344, 118, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(1345, 118, 'best_deal_title', 'Best deal product'),
(1346, 118, '_best_deal_title', 'field_5c29e394dd2bf'),
(1347, 118, 'best_deal_product_image', '59'),
(1348, 118, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(1349, 118, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1350, 118, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1351, 118, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1352, 118, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1353, 118, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1354, 118, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(1355, 118, 'best_deal_product_0_best_deal_image', '59'),
(1356, 118, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1357, 118, 'best_deal_product', '1'),
(1358, 118, '_best_deal_product', 'field_5c29e37d3481d'),
(1359, 118, 'popular_products_title', 'Popular products'),
(1360, 118, '_popular_products_title', 'field_5c29f81657533'),
(1361, 118, 'section_title', 'Best deal product'),
(1362, 118, '_section_title', 'field_5c29f6be784a2'),
(1363, 118, 'latest_product_title', 'Latest products'),
(1364, 118, '_latest_product_title', 'field_5c29f97f765f7'),
(1365, 118, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1366, 118, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1367, 118, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1368, 118, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1378, 120, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(1379, 120, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(1380, 120, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight Ergonomic2 '),
(1381, 120, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(1382, 120, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1383, 120, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(1384, 120, 'product-info_0_intro_product_image', '13'),
(1385, 120, '_product-info_0_intro_product_image', 'field_5c24fc80c2305') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1386, 120, 'product-info_1_intro_product_name', 'H-Pillow 2'),
(1387, 120, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(1388, 120, 'product-info_1_intro_product_description', 'Light Weight Ergonomic2 Light Weight Ergonomic2 '),
(1389, 120, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(1390, 120, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1391, 120, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(1392, 120, 'product-info_1_intro_product_image', '48'),
(1393, 120, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(1394, 120, 'product-info_2_intro_product_name', 'H-Pillow 3'),
(1395, 120, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(1396, 120, 'product-info_2_intro_product_description', 'Light Weight Ergonomic3'),
(1397, 120, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(1398, 120, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1399, 120, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(1400, 120, 'product-info_2_intro_product_image', '13'),
(1401, 120, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(1402, 120, 'product-info_3_intro_product_name', 'H-Pillow 4'),
(1403, 120, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(1404, 120, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(1405, 120, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(1406, 120, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1407, 120, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(1408, 120, 'product-info_3_intro_product_image', '48'),
(1409, 120, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(1410, 120, 'product-info', '4'),
(1411, 120, '_product-info', 'field_5c24fc17c2302'),
(1412, 120, 'best_deal_product_name', 'Best deal product'),
(1413, 120, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(1414, 120, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1415, 120, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(1416, 120, 'best_deal_product_link', 'https://twitter.com/'),
(1417, 120, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(1418, 120, 'best_deal_title', 'Best deal product'),
(1419, 120, '_best_deal_title', 'field_5c29e394dd2bf'),
(1420, 120, 'best_deal_product_image', '59'),
(1421, 120, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(1422, 120, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1423, 120, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1424, 120, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1425, 120, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1426, 120, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1427, 120, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(1428, 120, 'best_deal_product_0_best_deal_image', '59'),
(1429, 120, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1430, 120, 'best_deal_product', '1'),
(1431, 120, '_best_deal_product', 'field_5c29e37d3481d'),
(1432, 120, 'popular_products_title', 'Popular products'),
(1433, 120, '_popular_products_title', 'field_5c29f81657533'),
(1434, 120, 'section_title', 'Best deal product'),
(1435, 120, '_section_title', 'field_5c29f6be784a2'),
(1436, 120, 'latest_product_title', 'Latest products'),
(1437, 120, '_latest_product_title', 'field_5c29f97f765f7'),
(1438, 120, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1439, 120, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1440, 120, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1441, 120, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1442, 121, '_wp_attached_file', '2019/01/product-img-1.png'),
(1443, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:765;s:6:"height";i:765;s:4:"file";s:25:"2019/01/product-img-1.png";s:5:"sizes";a:10:{s:17:"custom-size-large";a:4:{s:4:"file";s:25:"product-img-1-300x220.png";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"product-img-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"product-img-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:17:"custom-size-small";a:4:{s:4:"file";s:23:"product-img-1-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:25:"product-img-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:25:"product-img-1-600x600.png";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:9:"image/png";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:25:"product-img-1-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:25:"product-img-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:25:"product-img-1-600x600.png";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:25:"product-img-1-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1446, 123, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(1447, 123, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(1448, 123, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight Ergonomic2 '),
(1449, 123, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(1450, 123, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1451, 123, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(1452, 123, 'product-info_0_intro_product_image', '121'),
(1453, 123, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(1454, 123, 'product-info_1_intro_product_name', 'H-Pillow 2'),
(1455, 123, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(1456, 123, 'product-info_1_intro_product_description', 'Light Weight Ergonomic2 Light Weight Ergonomic2 '),
(1457, 123, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(1458, 123, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1459, 123, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(1460, 123, 'product-info_1_intro_product_image', '48'),
(1461, 123, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(1462, 123, 'product-info_2_intro_product_name', 'H-Pillow 3'),
(1463, 123, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(1464, 123, 'product-info_2_intro_product_description', 'Light Weight Ergonomic3'),
(1465, 123, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(1466, 123, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1467, 123, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(1468, 123, 'product-info_2_intro_product_image', '121'),
(1469, 123, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(1470, 123, 'product-info_3_intro_product_name', 'H-Pillow 4'),
(1471, 123, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(1472, 123, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight'),
(1473, 123, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(1474, 123, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1475, 123, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(1476, 123, 'product-info_3_intro_product_image', '48'),
(1477, 123, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(1478, 123, 'product-info', '4'),
(1479, 123, '_product-info', 'field_5c24fc17c2302'),
(1480, 123, 'best_deal_product_name', 'Best deal product'),
(1481, 123, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(1482, 123, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1483, 123, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(1484, 123, 'best_deal_product_link', 'https://twitter.com/'),
(1485, 123, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(1486, 123, 'best_deal_title', 'Best deal product'),
(1487, 123, '_best_deal_title', 'field_5c29e394dd2bf') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1488, 123, 'best_deal_product_image', '59'),
(1489, 123, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(1490, 123, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1491, 123, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1492, 123, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1493, 123, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1494, 123, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1495, 123, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(1496, 123, 'best_deal_product_0_best_deal_image', '59'),
(1497, 123, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1498, 123, 'best_deal_product', '1'),
(1499, 123, '_best_deal_product', 'field_5c29e37d3481d'),
(1500, 123, 'popular_products_title', 'Popular products'),
(1501, 123, '_popular_products_title', 'field_5c29f81657533'),
(1502, 123, 'section_title', 'Best deal product'),
(1503, 123, '_section_title', 'field_5c29f6be784a2'),
(1504, 123, 'latest_product_title', 'Latest products'),
(1505, 123, '_latest_product_title', 'field_5c29f97f765f7'),
(1506, 123, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1507, 123, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1508, 123, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1509, 123, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1510, 12, '_product_attributes', 'a:2:{s:8:"pa_color";a:6:{s:4:"name";s:8:"pa_color";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:0;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:0;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1511, 124, '_variation_description', ''),
(1512, 124, '_sku', ''),
(1513, 124, '_regular_price', '140'),
(1514, 124, '_sale_price', ''),
(1515, 124, '_sale_price_dates_from', ''),
(1516, 124, '_sale_price_dates_to', ''),
(1517, 124, 'total_sales', '0'),
(1518, 124, '_tax_status', 'taxable'),
(1519, 124, '_tax_class', 'parent'),
(1520, 124, '_manage_stock', 'no'),
(1521, 124, '_backorders', 'no'),
(1522, 124, '_low_stock_amount', ''),
(1523, 124, '_sold_individually', 'no'),
(1524, 124, '_weight', ''),
(1525, 124, '_length', ''),
(1526, 124, '_width', ''),
(1527, 124, '_height', ''),
(1528, 124, '_upsell_ids', 'a:0:{}'),
(1529, 124, '_crosssell_ids', 'a:0:{}'),
(1530, 124, '_purchase_note', ''),
(1531, 124, '_default_attributes', 'a:0:{}'),
(1532, 124, '_virtual', 'no'),
(1533, 124, '_downloadable', 'no'),
(1534, 124, '_product_image_gallery', ''),
(1535, 124, '_download_limit', '-1'),
(1536, 124, '_download_expiry', '-1'),
(1537, 124, '_stock', '25'),
(1538, 124, '_stock_status', 'instock'),
(1539, 124, '_wc_average_rating', '0'),
(1540, 124, '_wc_rating_count', 'a:0:{}'),
(1541, 124, '_wc_review_count', '0'),
(1542, 124, '_downloadable_files', 'a:0:{}'),
(1543, 124, '_price', '140'),
(1544, 124, '_product_version', '3.5.3'),
(1555, 124, 'attribute_pa_color', 'white'),
(1556, 124, 'attribute_pa_size', '40x40'),
(1585, 125, '_variation_description', ''),
(1586, 125, '_sku', ''),
(1587, 125, '_regular_price', '110'),
(1588, 125, '_sale_price', ''),
(1589, 125, '_sale_price_dates_from', ''),
(1590, 125, '_sale_price_dates_to', ''),
(1591, 125, 'total_sales', '0'),
(1592, 125, '_tax_status', 'taxable'),
(1593, 125, '_tax_class', 'parent'),
(1594, 125, '_manage_stock', 'no'),
(1595, 125, '_backorders', 'no'),
(1596, 125, '_low_stock_amount', ''),
(1597, 125, '_sold_individually', 'no'),
(1598, 125, '_weight', ''),
(1599, 125, '_length', ''),
(1600, 125, '_width', ''),
(1601, 125, '_height', ''),
(1602, 125, '_upsell_ids', 'a:0:{}'),
(1603, 125, '_crosssell_ids', 'a:0:{}'),
(1604, 125, '_purchase_note', ''),
(1605, 125, '_default_attributes', 'a:0:{}'),
(1606, 125, '_virtual', 'no'),
(1607, 125, '_downloadable', 'no'),
(1608, 125, '_product_image_gallery', ''),
(1609, 125, '_download_limit', '-1'),
(1610, 125, '_download_expiry', '-1'),
(1611, 125, '_stock', '0'),
(1612, 125, '_stock_status', 'instock'),
(1613, 125, '_wc_average_rating', '0'),
(1614, 125, '_wc_rating_count', 'a:0:{}'),
(1615, 125, '_wc_review_count', '0'),
(1616, 125, '_downloadable_files', 'a:0:{}'),
(1617, 125, 'attribute_pa_color', 'white'),
(1618, 125, 'attribute_pa_size', '30x30'),
(1619, 125, '_price', '110'),
(1620, 125, '_product_version', '3.5.3'),
(1672, 127, '_variation_description', ''),
(1673, 127, '_sku', ''),
(1674, 127, '_regular_price', '90'),
(1675, 127, '_sale_price', ''),
(1676, 127, '_sale_price_dates_from', '') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1677, 127, '_sale_price_dates_to', ''),
(1678, 127, 'total_sales', '0'),
(1679, 127, '_tax_status', 'taxable'),
(1680, 127, '_tax_class', 'parent'),
(1681, 127, '_manage_stock', 'no'),
(1682, 127, '_backorders', 'no'),
(1683, 127, '_low_stock_amount', ''),
(1684, 127, '_sold_individually', 'no'),
(1685, 127, '_weight', ''),
(1686, 127, '_length', ''),
(1687, 127, '_width', ''),
(1688, 127, '_height', ''),
(1689, 127, '_upsell_ids', 'a:0:{}'),
(1690, 127, '_crosssell_ids', 'a:0:{}'),
(1691, 127, '_purchase_note', ''),
(1692, 127, '_default_attributes', 'a:0:{}'),
(1693, 127, '_virtual', 'no'),
(1694, 127, '_downloadable', 'no'),
(1695, 127, '_product_image_gallery', ''),
(1696, 127, '_download_limit', '-1'),
(1697, 127, '_download_expiry', '-1'),
(1698, 127, '_stock', '0'),
(1699, 127, '_stock_status', 'instock'),
(1700, 127, '_wc_average_rating', '0'),
(1701, 127, '_wc_rating_count', 'a:0:{}'),
(1702, 127, '_wc_review_count', '0'),
(1703, 127, '_downloadable_files', 'a:0:{}'),
(1704, 127, 'attribute_pa_size', '30x30'),
(1705, 127, 'attribute_pa_color', 'black'),
(1706, 127, '_price', '90'),
(1707, 127, '_product_version', '3.5.3'),
(1708, 128, '_variation_description', ''),
(1709, 128, '_sku', ''),
(1710, 128, '_regular_price', '100'),
(1711, 128, '_sale_price', ''),
(1712, 128, '_sale_price_dates_from', ''),
(1713, 128, '_sale_price_dates_to', ''),
(1714, 128, 'total_sales', '0'),
(1715, 128, '_tax_status', 'taxable'),
(1716, 128, '_tax_class', 'parent'),
(1717, 128, '_manage_stock', 'no'),
(1718, 128, '_backorders', 'no'),
(1719, 128, '_low_stock_amount', ''),
(1720, 128, '_sold_individually', 'no'),
(1721, 128, '_weight', ''),
(1722, 128, '_length', ''),
(1723, 128, '_width', ''),
(1724, 128, '_height', ''),
(1725, 128, '_upsell_ids', 'a:0:{}'),
(1726, 128, '_crosssell_ids', 'a:0:{}'),
(1727, 128, '_purchase_note', ''),
(1728, 128, '_default_attributes', 'a:0:{}'),
(1729, 128, '_virtual', 'no'),
(1730, 128, '_downloadable', 'no'),
(1731, 128, '_product_image_gallery', ''),
(1732, 128, '_download_limit', '-1'),
(1733, 128, '_download_expiry', '-1'),
(1734, 128, '_stock', '0'),
(1735, 128, '_stock_status', 'instock'),
(1736, 128, '_wc_average_rating', '0'),
(1737, 128, '_wc_rating_count', 'a:0:{}'),
(1738, 128, '_wc_review_count', '0'),
(1739, 128, '_downloadable_files', 'a:0:{}'),
(1740, 128, 'attribute_pa_size', '40x40'),
(1741, 128, 'attribute_pa_color', 'black'),
(1742, 128, '_price', '100'),
(1743, 128, '_product_version', '3.5.3'),
(1759, 12, '_vtwf_enable_tab', 'yes'),
(1760, 12, '_vtwf_tab_title', 'Video'),
(1761, 12, '_vtwf_hide_title', 'yes'),
(1762, 12, '_vtwf_video_content', '<iframe width="560" height="315" src="https://www.youtube.com/embed/wbTc81JmQTs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'),
(1763, 12, '_heateor_sss_meta', 'a:2:{s:7:"sharing";i:0;s:16:"vertical_sharing";i:0;}'),
(1774, 12, '_price', '90'),
(1775, 12, '_price', '100'),
(1776, 12, '_price', '110'),
(1777, 12, '_price', '140'),
(1778, 12, '_regular_price', ''),
(1779, 12, '_sale_price', ''),
(1780, 51, '_vtwf_enable_tab', 'yes'),
(1781, 51, '_vtwf_tab_title', 'Video'),
(1782, 51, '_vtwf_hide_title', 'yes'),
(1783, 51, '_vtwf_video_content', '<iframe width="560" height="315" src="https://www.youtube.com/embed/wbTc81JmQTs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'),
(1784, 51, '_heateor_sss_meta', 'a:2:{s:7:"sharing";i:0;s:16:"vertical_sharing";i:0;}'),
(1785, 19, '_heateor_sss_meta', 'a:2:{s:7:"sharing";i:0;s:16:"vertical_sharing";i:0;}'),
(1786, 131, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(1787, 131, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(1788, 131, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight Ergonomic'),
(1789, 131, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(1790, 131, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1791, 131, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(1792, 131, 'product-info_0_intro_product_image', '121'),
(1793, 131, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(1794, 131, 'product-info_1_intro_product_name', 'H-Pillow 2'),
(1795, 131, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(1796, 131, 'product-info_1_intro_product_description', 'Light Weight Ergonomic 2'),
(1797, 131, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(1798, 131, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1799, 131, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(1800, 131, 'product-info_1_intro_product_image', '48'),
(1801, 131, '_product-info_1_intro_product_image', 'field_5c24fc80c2305') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1802, 131, 'product-info_2_intro_product_name', 'H-Pillow 3'),
(1803, 131, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(1804, 131, 'product-info_2_intro_product_description', 'Light Weight Ergonomic3 '),
(1805, 131, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(1806, 131, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1807, 131, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(1808, 131, 'product-info_2_intro_product_image', '121'),
(1809, 131, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(1810, 131, 'product-info_3_intro_product_name', 'H-Pillow 4'),
(1811, 131, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(1812, 131, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight 4'),
(1813, 131, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(1814, 131, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1815, 131, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(1816, 131, 'product-info_3_intro_product_image', '48'),
(1817, 131, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(1818, 131, 'product-info', '4'),
(1819, 131, '_product-info', 'field_5c24fc17c2302'),
(1820, 131, 'best_deal_product_name', 'Best deal product'),
(1821, 131, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(1822, 131, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1823, 131, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(1824, 131, 'best_deal_product_link', 'https://twitter.com/'),
(1825, 131, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(1826, 131, 'best_deal_title', 'Best deal product'),
(1827, 131, '_best_deal_title', 'field_5c29e394dd2bf'),
(1828, 131, 'best_deal_product_image', '59'),
(1829, 131, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(1830, 131, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1831, 131, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1832, 131, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1833, 131, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1834, 131, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1835, 131, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(1836, 131, 'best_deal_product_0_best_deal_image', '59'),
(1837, 131, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1838, 131, 'best_deal_product', '1'),
(1839, 131, '_best_deal_product', 'field_5c29e37d3481d'),
(1840, 131, 'popular_products_title', 'Popular products'),
(1841, 131, '_popular_products_title', 'field_5c29f81657533'),
(1842, 131, 'section_title', 'Best deal product'),
(1843, 131, '_section_title', 'field_5c29f6be784a2'),
(1844, 131, 'latest_product_title', 'Latest products'),
(1845, 131, '_latest_product_title', 'field_5c29f97f765f7'),
(1846, 131, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1847, 131, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1848, 131, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1849, 131, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1850, 132, '_wp_attached_file', '2019/01/footer-logo.svg'),
(1851, 132, '_wp_attachment_image_alt', 'secondary-logo'),
(1852, 133, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(1853, 133, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(1854, 133, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight 1'),
(1855, 133, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(1856, 133, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1857, 133, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(1858, 133, 'product-info_0_intro_product_image', '121'),
(1859, 133, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(1860, 133, 'product-info_1_intro_product_name', 'H-Pillow 2'),
(1861, 133, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(1862, 133, 'product-info_1_intro_product_description', 'Light Weight Ergonomic 2'),
(1863, 133, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(1864, 133, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1865, 133, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(1866, 133, 'product-info_1_intro_product_image', '48'),
(1867, 133, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(1868, 133, 'product-info_2_intro_product_name', 'H-Pillow 3'),
(1869, 133, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(1870, 133, 'product-info_2_intro_product_description', 'Light Weight Ergonomic3 '),
(1871, 133, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(1872, 133, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1873, 133, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(1874, 133, 'product-info_2_intro_product_image', '121'),
(1875, 133, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(1876, 133, 'product-info_3_intro_product_name', 'H-Pillow 4'),
(1877, 133, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(1878, 133, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight 4'),
(1879, 133, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(1880, 133, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1881, 133, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(1882, 133, 'product-info_3_intro_product_image', '48'),
(1883, 133, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(1884, 133, 'product-info', '4'),
(1885, 133, '_product-info', 'field_5c24fc17c2302'),
(1886, 133, 'best_deal_product_name', 'Best deal product'),
(1887, 133, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(1888, 133, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1889, 133, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(1890, 133, 'best_deal_product_link', 'https://twitter.com/'),
(1891, 133, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(1892, 133, 'best_deal_title', 'Best deal product'),
(1893, 133, '_best_deal_title', 'field_5c29e394dd2bf'),
(1894, 133, 'best_deal_product_image', '59'),
(1895, 133, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(1896, 133, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(1897, 133, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(1898, 133, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(1899, 133, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(1900, 133, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1901, 133, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1902, 133, 'best_deal_product_0_best_deal_image', '59'),
(1903, 133, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(1904, 133, 'best_deal_product', '1'),
(1905, 133, '_best_deal_product', 'field_5c29e37d3481d'),
(1906, 133, 'popular_products_title', 'Popular products'),
(1907, 133, '_popular_products_title', 'field_5c29f81657533'),
(1908, 133, 'section_title', 'Best deal product'),
(1909, 133, '_section_title', 'field_5c29f6be784a2'),
(1910, 133, 'latest_product_title', 'Latest products'),
(1911, 133, '_latest_product_title', 'field_5c29f97f765f7'),
(1912, 133, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1913, 133, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(1914, 133, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(1915, 133, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(1916, 135, '_wc_review_count', '0'),
(1917, 135, '_wc_rating_count', 'a:0:{}'),
(1918, 135, '_wc_average_rating', '0'),
(1919, 135, '_edit_last', '1'),
(1920, 135, '_edit_lock', '1550502612:1'),
(1921, 135, '_vtwf_enable_tab', 'no'),
(1922, 135, '_vtwf_tab_title', ''),
(1923, 135, '_vtwf_hide_title', 'no'),
(1924, 135, '_vtwf_video_content', ''),
(1925, 135, '_sku', ''),
(1926, 135, '_regular_price', '100'),
(1927, 135, '_sale_price', ''),
(1928, 135, '_sale_price_dates_from', ''),
(1929, 135, '_sale_price_dates_to', ''),
(1930, 135, 'total_sales', '0'),
(1931, 135, '_tax_status', 'taxable'),
(1932, 135, '_tax_class', ''),
(1933, 135, '_manage_stock', 'no'),
(1934, 135, '_backorders', 'no'),
(1935, 135, '_low_stock_amount', ''),
(1936, 135, '_sold_individually', 'no'),
(1937, 135, '_weight', ''),
(1938, 135, '_length', ''),
(1939, 135, '_width', ''),
(1940, 135, '_height', ''),
(1941, 135, '_upsell_ids', 'a:0:{}'),
(1942, 135, '_crosssell_ids', 'a:0:{}'),
(1943, 135, '_purchase_note', ''),
(1944, 135, '_default_attributes', 'a:0:{}'),
(1945, 135, '_virtual', 'no'),
(1946, 135, '_downloadable', 'no'),
(1947, 135, '_product_image_gallery', ''),
(1948, 135, '_download_limit', '-1'),
(1949, 135, '_download_expiry', '-1'),
(1950, 135, '_stock', NULL),
(1951, 135, '_stock_status', 'instock'),
(1952, 135, '_product_version', '3.5.3'),
(1953, 135, '_price', '100'),
(1954, 135, '_heateor_sss_meta', 'a:2:{s:7:"sharing";i:0;s:16:"vertical_sharing";i:0;}'),
(1955, 136, '_wp_attached_file', '2019/02/91Tw-ntzrAL._SX522_.jpg'),
(1956, 136, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:522;s:6:"height";i:522;s:4:"file";s:31:"2019/02/91Tw-ntzrAL._SX522_.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"91Tw-ntzrAL._SX522_-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"91Tw-ntzrAL._SX522_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:29:"91Tw-ntzrAL._SX522_-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-large";a:4:{s:4:"file";s:31:"91Tw-ntzrAL._SX522_-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:31:"91Tw-ntzrAL._SX522_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:31:"91Tw-ntzrAL._SX522_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:31:"91Tw-ntzrAL._SX522_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:31:"91Tw-ntzrAL._SX522_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1957, 136, '_wp_attachment_image_alt', 'product-image'),
(1958, 135, '_thumbnail_id', '136'),
(1959, 137, '_wc_review_count', '0'),
(1960, 137, '_wc_rating_count', 'a:0:{}'),
(1961, 137, '_wc_average_rating', '0'),
(1962, 137, '_edit_last', '1'),
(1963, 137, '_edit_lock', '1549552605:1'),
(1964, 137, '_sku', ''),
(1967, 137, '_sale_price_dates_from', ''),
(1968, 137, '_sale_price_dates_to', ''),
(1969, 137, 'total_sales', '0'),
(1970, 137, '_tax_status', 'taxable'),
(1971, 137, '_tax_class', ''),
(1972, 137, '_manage_stock', 'no'),
(1973, 137, '_backorders', 'no'),
(1974, 137, '_low_stock_amount', ''),
(1975, 137, '_sold_individually', 'no'),
(1976, 137, '_weight', ''),
(1977, 137, '_length', ''),
(1978, 137, '_width', ''),
(1979, 137, '_height', ''),
(1980, 137, '_upsell_ids', 'a:0:{}'),
(1981, 137, '_crosssell_ids', 'a:0:{}'),
(1982, 137, '_purchase_note', ''),
(1983, 137, '_default_attributes', 'a:0:{}'),
(1984, 137, '_virtual', 'no'),
(1985, 137, '_downloadable', 'no'),
(1986, 137, '_product_image_gallery', ''),
(1987, 137, '_download_limit', '-1'),
(1988, 137, '_download_expiry', '-1'),
(1989, 137, '_stock', NULL),
(1990, 137, '_stock_status', 'instock'),
(1991, 137, '_product_attributes', 'a:1:{s:8:"pa_color";a:6:{s:4:"name";s:8:"pa_color";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:0;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(1992, 137, '_product_version', '3.5.3'),
(1994, 137, '_vtwf_enable_tab', 'yes'),
(1995, 137, '_vtwf_tab_title', 'Video'),
(1996, 137, '_vtwf_hide_title', 'yes'),
(1997, 137, '_vtwf_video_content', '<iframe width="560" height="315" src="https://www.youtube.com/embed/wbTc81JmQTs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'),
(1998, 137, '_heateor_sss_meta', 'a:2:{s:7:"sharing";i:0;s:16:"vertical_sharing";i:0;}'),
(2003, 139, '_variation_description', ''),
(2004, 139, '_sku', ''),
(2005, 139, '_regular_price', '100'),
(2006, 139, '_sale_price', ''),
(2007, 139, '_sale_price_dates_from', ''),
(2008, 139, '_sale_price_dates_to', '') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2009, 139, 'total_sales', '0'),
(2010, 139, '_tax_status', 'taxable'),
(2011, 139, '_tax_class', 'parent'),
(2012, 139, '_manage_stock', 'no'),
(2013, 139, '_backorders', 'no'),
(2014, 139, '_low_stock_amount', ''),
(2015, 139, '_sold_individually', 'no'),
(2016, 139, '_weight', ''),
(2017, 139, '_length', ''),
(2018, 139, '_width', ''),
(2019, 139, '_height', ''),
(2020, 139, '_upsell_ids', 'a:0:{}'),
(2021, 139, '_crosssell_ids', 'a:0:{}'),
(2022, 139, '_purchase_note', ''),
(2023, 139, '_default_attributes', 'a:0:{}'),
(2024, 139, '_virtual', 'no'),
(2025, 139, '_downloadable', 'no'),
(2026, 139, '_product_image_gallery', ''),
(2027, 139, '_download_limit', '-1'),
(2028, 139, '_download_expiry', '-1'),
(2029, 139, '_stock', NULL),
(2030, 139, '_stock_status', 'instock'),
(2031, 139, '_wc_average_rating', '0'),
(2032, 139, '_wc_rating_count', 'a:0:{}'),
(2033, 139, '_wc_review_count', '0'),
(2034, 139, '_downloadable_files', 'a:0:{}'),
(2035, 139, 'attribute_pa_color', 'black'),
(2036, 139, '_price', '100'),
(2037, 139, '_product_version', '3.5.3'),
(2038, 140, '_variation_description', ''),
(2039, 140, '_sku', ''),
(2040, 140, '_regular_price', '130'),
(2041, 140, '_sale_price', ''),
(2042, 140, '_sale_price_dates_from', ''),
(2043, 140, '_sale_price_dates_to', ''),
(2044, 140, 'total_sales', '0'),
(2045, 140, '_tax_status', 'taxable'),
(2046, 140, '_tax_class', 'parent'),
(2047, 140, '_manage_stock', 'no'),
(2048, 140, '_backorders', 'no'),
(2049, 140, '_low_stock_amount', ''),
(2050, 140, '_sold_individually', 'no'),
(2051, 140, '_weight', ''),
(2052, 140, '_length', ''),
(2053, 140, '_width', ''),
(2054, 140, '_height', ''),
(2055, 140, '_upsell_ids', 'a:0:{}'),
(2056, 140, '_crosssell_ids', 'a:0:{}'),
(2057, 140, '_purchase_note', ''),
(2058, 140, '_default_attributes', 'a:0:{}'),
(2059, 140, '_virtual', 'no'),
(2060, 140, '_downloadable', 'no'),
(2061, 140, '_product_image_gallery', ''),
(2062, 140, '_download_limit', '-1'),
(2063, 140, '_download_expiry', '-1'),
(2064, 140, '_stock', NULL),
(2065, 140, '_stock_status', 'instock'),
(2066, 140, '_wc_average_rating', '0'),
(2067, 140, '_wc_rating_count', 'a:0:{}'),
(2068, 140, '_wc_review_count', '0'),
(2069, 140, '_downloadable_files', 'a:0:{}'),
(2070, 140, 'attribute_pa_color', 'white'),
(2071, 140, '_price', '130'),
(2072, 140, '_product_version', '3.5.3'),
(2078, 137, '_price', '100'),
(2079, 137, '_price', '130'),
(2080, 137, '_regular_price', ''),
(2081, 137, '_sale_price', ''),
(2082, 141, '_wc_review_count', '1'),
(2083, 141, '_wc_rating_count', 'a:1:{i:4;i:1;}'),
(2084, 141, '_wc_average_rating', '4.00'),
(2085, 141, '_edit_last', '1'),
(2086, 141, '_edit_lock', '1550496430:1'),
(2087, 141, '_vtwf_enable_tab', 'no'),
(2088, 141, '_vtwf_tab_title', ''),
(2089, 141, '_vtwf_hide_title', 'no'),
(2090, 141, '_vtwf_video_content', ''),
(2091, 141, '_sku', ''),
(2092, 141, '_regular_price', '19'),
(2093, 141, '_sale_price', ''),
(2094, 141, '_sale_price_dates_from', ''),
(2095, 141, '_sale_price_dates_to', ''),
(2096, 141, 'total_sales', '0'),
(2097, 141, '_tax_status', 'taxable'),
(2098, 141, '_tax_class', ''),
(2099, 141, '_manage_stock', 'no'),
(2100, 141, '_backorders', 'no'),
(2101, 141, '_low_stock_amount', ''),
(2102, 141, '_sold_individually', 'no'),
(2103, 141, '_weight', ''),
(2104, 141, '_length', ''),
(2105, 141, '_width', ''),
(2106, 141, '_height', ''),
(2107, 141, '_upsell_ids', 'a:0:{}'),
(2108, 141, '_crosssell_ids', 'a:0:{}'),
(2109, 141, '_purchase_note', ''),
(2110, 141, '_default_attributes', 'a:0:{}'),
(2111, 141, '_virtual', 'no'),
(2112, 141, '_downloadable', 'no'),
(2113, 141, '_product_image_gallery', '') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2114, 141, '_download_limit', '-1'),
(2115, 141, '_download_expiry', '-1'),
(2116, 141, '_stock', NULL),
(2117, 141, '_stock_status', 'instock'),
(2118, 141, '_product_version', '3.5.3'),
(2119, 141, '_price', '19'),
(2120, 141, '_heateor_sss_meta', 'a:2:{s:7:"sharing";i:0;s:16:"vertical_sharing";i:0;}'),
(2121, 143, '_wp_attached_file', '2019/02/91MzEa6e-eL._SX679_.jpg'),
(2122, 143, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:679;s:6:"height";i:610;s:4:"file";s:31:"2019/02/91MzEa6e-eL._SX679_.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"91MzEa6e-eL._SX679_-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"91MzEa6e-eL._SX679_-300x270.jpg";s:5:"width";i:300;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:29:"91MzEa6e-eL._SX679_-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-large";a:4:{s:4:"file";s:31:"91MzEa6e-eL._SX679_-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:31:"91MzEa6e-eL._SX679_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:31:"91MzEa6e-eL._SX679_-600x539.jpg";s:5:"width";i:600;s:6:"height";i:539;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:31:"91MzEa6e-eL._SX679_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:31:"91MzEa6e-eL._SX679_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:31:"91MzEa6e-eL._SX679_-600x539.jpg";s:5:"width";i:600;s:6:"height";i:539;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:31:"91MzEa6e-eL._SX679_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(2123, 143, '_wp_attachment_image_alt', 'product-image'),
(2124, 141, '_thumbnail_id', '143'),
(2125, 144, '_wc_review_count', '0'),
(2126, 144, '_wc_rating_count', 'a:0:{}'),
(2127, 144, '_wc_average_rating', '0'),
(2128, 145, '_wp_attached_file', '2019/02/51Q3EafrqL.jpg'),
(2129, 145, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:500;s:4:"file";s:22:"2019/02/51Q3EafrqL.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"51Q3EafrqL-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"51Q3EafrqL-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:20:"51Q3EafrqL-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-large";a:4:{s:4:"file";s:22:"51Q3EafrqL-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:22:"51Q3EafrqL-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:22:"51Q3EafrqL-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:22:"51Q3EafrqL-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:22:"51Q3EafrqL-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(2130, 145, '_wp_attachment_image_alt', 'product-image'),
(2131, 144, '_edit_last', '1'),
(2132, 144, '_thumbnail_id', '145'),
(2133, 144, '_vtwf_enable_tab', 'no'),
(2134, 144, '_vtwf_tab_title', ''),
(2135, 144, '_vtwf_hide_title', 'no'),
(2136, 144, '_vtwf_video_content', ''),
(2137, 144, '_sku', ''),
(2138, 144, '_regular_price', '65'),
(2139, 144, '_sale_price', ''),
(2140, 144, '_sale_price_dates_from', ''),
(2141, 144, '_sale_price_dates_to', ''),
(2142, 144, 'total_sales', '0'),
(2143, 144, '_tax_status', 'taxable'),
(2144, 144, '_tax_class', ''),
(2145, 144, '_manage_stock', 'no'),
(2146, 144, '_backorders', 'no'),
(2147, 144, '_low_stock_amount', ''),
(2148, 144, '_sold_individually', 'no'),
(2149, 144, '_weight', ''),
(2150, 144, '_length', ''),
(2151, 144, '_width', ''),
(2152, 144, '_height', ''),
(2153, 144, '_upsell_ids', 'a:0:{}'),
(2154, 144, '_crosssell_ids', 'a:0:{}'),
(2155, 144, '_purchase_note', ''),
(2156, 144, '_default_attributes', 'a:0:{}'),
(2157, 144, '_virtual', 'no'),
(2158, 144, '_downloadable', 'no'),
(2159, 144, '_product_image_gallery', ''),
(2160, 144, '_download_limit', '-1'),
(2161, 144, '_download_expiry', '-1'),
(2162, 144, '_stock', NULL),
(2163, 144, '_stock_status', 'instock'),
(2164, 144, '_product_version', '3.5.3'),
(2165, 144, '_price', '65'),
(2166, 144, '_heateor_sss_meta', 'a:2:{s:7:"sharing";i:0;s:16:"vertical_sharing";i:0;}'),
(2167, 144, '_edit_lock', '1549552552:1'),
(2173, 147, '_wc_review_count', '0'),
(2174, 147, '_wc_rating_count', 'a:0:{}'),
(2175, 147, '_wc_average_rating', '0'),
(2176, 147, '_edit_last', '1'),
(2177, 147, '_edit_lock', '1550657270:1'),
(2178, 148, '_wp_attached_file', '2019/02/61ZYyllInqL._SX425_.jpg'),
(2179, 148, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:425;s:6:"height";i:291;s:4:"file";s:31:"2019/02/61ZYyllInqL._SX425_.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"61ZYyllInqL._SX425_-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"61ZYyllInqL._SX425_-300x205.jpg";s:5:"width";i:300;s:6:"height";i:205;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:29:"61ZYyllInqL._SX425_-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-large";a:4:{s:4:"file";s:31:"61ZYyllInqL._SX425_-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:31:"61ZYyllInqL._SX425_-300x291.jpg";s:5:"width";i:300;s:6:"height";i:291;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:31:"61ZYyllInqL._SX425_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:31:"61ZYyllInqL._SX425_-300x291.jpg";s:5:"width";i:300;s:6:"height";i:291;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:31:"61ZYyllInqL._SX425_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(2180, 148, '_wp_attachment_image_alt', 'product-image'),
(2181, 147, '_thumbnail_id', '148'),
(2182, 147, '_vtwf_enable_tab', 'yes'),
(2183, 147, '_vtwf_tab_title', 'Video'),
(2184, 147, '_vtwf_hide_title', 'yes'),
(2185, 147, '_vtwf_video_content', '<iframe width="560" height="315" src="https://www.youtube.com/embed/wbTc81JmQTs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'),
(2186, 147, '_sku', ''),
(2189, 147, '_sale_price_dates_from', ''),
(2190, 147, '_sale_price_dates_to', ''),
(2191, 147, 'total_sales', '0'),
(2192, 147, '_tax_status', 'taxable'),
(2193, 147, '_tax_class', ''),
(2194, 147, '_manage_stock', 'no'),
(2195, 147, '_backorders', 'no'),
(2196, 147, '_low_stock_amount', ''),
(2197, 147, '_sold_individually', 'no'),
(2198, 147, '_weight', ''),
(2199, 147, '_length', ''),
(2200, 147, '_width', ''),
(2201, 147, '_height', ''),
(2202, 147, '_upsell_ids', 'a:0:{}'),
(2203, 147, '_crosssell_ids', 'a:0:{}'),
(2204, 147, '_purchase_note', ''),
(2205, 147, '_default_attributes', 'a:0:{}'),
(2206, 147, '_virtual', 'no'),
(2207, 147, '_downloadable', 'no'),
(2208, 147, '_product_image_gallery', ''),
(2209, 147, '_download_limit', '-1'),
(2210, 147, '_download_expiry', '-1'),
(2211, 147, '_stock', NULL),
(2212, 147, '_stock_status', 'instock'),
(2213, 147, '_product_version', '3.5.3'),
(2215, 147, '_heateor_sss_meta', 'a:2:{s:7:"sharing";i:0;s:16:"vertical_sharing";i:0;}'),
(2216, 149, '_wp_attached_file', '2019/02/71DezV4FUL._SX679_.jpg'),
(2217, 149, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:679;s:6:"height";i:679;s:4:"file";s:30:"2019/02/71DezV4FUL._SX679_.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"71DezV4FUL._SX679_-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"71DezV4FUL._SX679_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:28:"71DezV4FUL._SX679_-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-large";a:4:{s:4:"file";s:30:"71DezV4FUL._SX679_-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:30:"71DezV4FUL._SX679_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:18:"woocommerce_single";a:4:{s:4:"file";s:30:"71DezV4FUL._SX679_-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:30:"71DezV4FUL._SX679_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:30:"71DezV4FUL._SX679_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:30:"71DezV4FUL._SX679_-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:30:"71DezV4FUL._SX679_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(2218, 149, '_wp_attachment_image_alt', 'product-image'),
(2219, 137, '_thumbnail_id', '149'),
(2220, 147, '_product_attributes', 'a:1:{s:8:"pa_color";a:6:{s:4:"name";s:8:"pa_color";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:0;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(2221, 150, '_variation_description', '') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2222, 150, '_sku', ''),
(2223, 150, '_regular_price', '120'),
(2224, 150, '_sale_price', ''),
(2225, 150, '_sale_price_dates_from', ''),
(2226, 150, '_sale_price_dates_to', ''),
(2227, 150, 'total_sales', '0'),
(2228, 150, '_tax_status', 'taxable'),
(2229, 150, '_tax_class', 'parent'),
(2230, 150, '_manage_stock', 'no'),
(2231, 150, '_backorders', 'no'),
(2232, 150, '_low_stock_amount', ''),
(2233, 150, '_sold_individually', 'no'),
(2234, 150, '_weight', ''),
(2235, 150, '_length', ''),
(2236, 150, '_width', ''),
(2237, 150, '_height', ''),
(2238, 150, '_upsell_ids', 'a:0:{}'),
(2239, 150, '_crosssell_ids', 'a:0:{}'),
(2240, 150, '_purchase_note', ''),
(2241, 150, '_default_attributes', 'a:0:{}'),
(2242, 150, '_virtual', 'no'),
(2243, 150, '_downloadable', 'no'),
(2244, 150, '_product_image_gallery', ''),
(2245, 150, '_download_limit', '-1'),
(2246, 150, '_download_expiry', '-1'),
(2247, 150, '_stock', NULL),
(2248, 150, '_stock_status', 'instock'),
(2249, 150, '_wc_average_rating', '0'),
(2250, 150, '_wc_rating_count', 'a:0:{}'),
(2251, 150, '_wc_review_count', '0'),
(2252, 150, '_downloadable_files', 'a:0:{}'),
(2253, 150, '_price', '120'),
(2254, 150, '_product_version', '3.5.3'),
(2257, 150, 'attribute_pa_color', 'grey'),
(2264, 151, '_variation_description', ''),
(2265, 151, '_sku', ''),
(2266, 151, '_regular_price', '115'),
(2267, 151, '_sale_price', ''),
(2268, 151, '_sale_price_dates_from', ''),
(2269, 151, '_sale_price_dates_to', ''),
(2270, 151, 'total_sales', '0'),
(2271, 151, '_tax_status', 'taxable'),
(2272, 151, '_tax_class', 'parent'),
(2273, 151, '_manage_stock', 'no'),
(2274, 151, '_backorders', 'no'),
(2275, 151, '_low_stock_amount', ''),
(2276, 151, '_sold_individually', 'no'),
(2277, 151, '_weight', ''),
(2278, 151, '_length', ''),
(2279, 151, '_width', ''),
(2280, 151, '_height', ''),
(2281, 151, '_upsell_ids', 'a:0:{}'),
(2282, 151, '_crosssell_ids', 'a:0:{}'),
(2283, 151, '_purchase_note', ''),
(2284, 151, '_default_attributes', 'a:0:{}'),
(2285, 151, '_virtual', 'no'),
(2286, 151, '_downloadable', 'no'),
(2287, 151, '_product_image_gallery', ''),
(2288, 151, '_download_limit', '-1'),
(2289, 151, '_download_expiry', '-1'),
(2290, 151, '_stock', NULL),
(2291, 151, '_stock_status', 'instock'),
(2292, 151, '_wc_average_rating', '0'),
(2293, 151, '_wc_rating_count', 'a:0:{}'),
(2294, 151, '_wc_review_count', '0'),
(2295, 151, '_downloadable_files', 'a:0:{}'),
(2296, 151, 'attribute_pa_color', 'black'),
(2297, 151, '_price', '115'),
(2298, 151, '_product_version', '3.5.3'),
(2305, 152, '_variation_description', ''),
(2306, 152, '_sku', ''),
(2307, 152, '_regular_price', '180'),
(2308, 152, '_sale_price', ''),
(2309, 152, '_sale_price_dates_from', ''),
(2310, 152, '_sale_price_dates_to', ''),
(2311, 152, 'total_sales', '0'),
(2312, 152, '_tax_status', 'taxable'),
(2313, 152, '_tax_class', 'parent'),
(2314, 152, '_manage_stock', 'no'),
(2315, 152, '_backorders', 'no'),
(2316, 152, '_low_stock_amount', ''),
(2317, 152, '_sold_individually', 'no'),
(2318, 152, '_weight', ''),
(2319, 152, '_length', ''),
(2320, 152, '_width', ''),
(2321, 152, '_height', ''),
(2322, 152, '_upsell_ids', 'a:0:{}'),
(2323, 152, '_crosssell_ids', 'a:0:{}'),
(2324, 152, '_purchase_note', ''),
(2325, 152, '_default_attributes', 'a:0:{}'),
(2326, 152, '_virtual', 'no'),
(2327, 152, '_downloadable', 'no'),
(2328, 152, '_product_image_gallery', ''),
(2329, 152, '_download_limit', '-1'),
(2330, 152, '_download_expiry', '-1'),
(2331, 152, '_stock', NULL),
(2332, 152, '_stock_status', 'instock'),
(2333, 152, '_wc_average_rating', '0'),
(2334, 152, '_wc_rating_count', 'a:0:{}'),
(2335, 152, '_wc_review_count', '0') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2336, 152, '_downloadable_files', 'a:0:{}'),
(2337, 152, 'attribute_pa_color', 'white'),
(2338, 152, '_price', '180'),
(2339, 152, '_product_version', '3.5.3'),
(2347, 147, '_price', '115'),
(2348, 147, '_price', '120'),
(2349, 147, '_price', '180'),
(2350, 147, '_regular_price', ''),
(2351, 147, '_sale_price', ''),
(2352, 153, '_wc_review_count', '0'),
(2353, 153, '_wc_rating_count', 'a:0:{}'),
(2354, 153, '_wc_average_rating', '0'),
(2355, 154, '_wp_attached_file', '2019/02/91bPGDtk5BL._UY741_.jpg'),
(2356, 154, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:522;s:6:"height";i:741;s:4:"file";s:31:"2019/02/91bPGDtk5BL._UY741_.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"91bPGDtk5BL._UY741_-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"91bPGDtk5BL._UY741_-211x300.jpg";s:5:"width";i:211;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:29:"91bPGDtk5BL._UY741_-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-large";a:4:{s:4:"file";s:31:"91bPGDtk5BL._UY741_-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:31:"91bPGDtk5BL._UY741_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:31:"91bPGDtk5BL._UY741_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:31:"91bPGDtk5BL._UY741_-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:31:"91bPGDtk5BL._UY741_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(2357, 154, '_wp_attachment_image_alt', 'product-image'),
(2358, 153, '_edit_last', '1'),
(2359, 153, '_edit_lock', '1550657268:1'),
(2360, 153, '_sku', ''),
(2363, 153, '_sale_price_dates_from', ''),
(2364, 153, '_sale_price_dates_to', ''),
(2365, 153, 'total_sales', '0'),
(2366, 153, '_tax_status', 'taxable'),
(2367, 153, '_tax_class', ''),
(2368, 153, '_manage_stock', 'no'),
(2369, 153, '_backorders', 'no'),
(2370, 153, '_low_stock_amount', ''),
(2371, 153, '_sold_individually', 'no'),
(2372, 153, '_weight', ''),
(2373, 153, '_length', ''),
(2374, 153, '_width', ''),
(2375, 153, '_height', ''),
(2376, 153, '_upsell_ids', 'a:0:{}'),
(2377, 153, '_crosssell_ids', 'a:0:{}'),
(2378, 153, '_purchase_note', ''),
(2379, 153, '_default_attributes', 'a:2:{s:8:"pa_color";s:4:"grey";s:7:"pa_size";s:5:"30x30";}'),
(2380, 153, '_virtual', 'no'),
(2381, 153, '_downloadable', 'no'),
(2382, 153, '_product_image_gallery', ''),
(2383, 153, '_download_limit', '-1'),
(2384, 153, '_download_expiry', '-1'),
(2385, 153, '_stock', NULL),
(2386, 153, '_stock_status', 'instock'),
(2387, 153, '_product_attributes', 'a:2:{s:8:"pa_color";a:6:{s:4:"name";s:8:"pa_color";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:0;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}s:7:"pa_size";a:6:{s:4:"name";s:7:"pa_size";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:0;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(2388, 153, '_product_version', '3.5.3'),
(2615, 153, '_thumbnail_id', '154'),
(2616, 153, '_vtwf_enable_tab', 'yes'),
(2617, 153, '_vtwf_tab_title', 'Video'),
(2618, 153, '_vtwf_hide_title', 'yes'),
(2619, 153, '_vtwf_video_content', '<iframe width="560" height="315" src="https://www.youtube.com/embed/wbTc81JmQTs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'),
(2620, 153, '_heateor_sss_meta', 'a:2:{s:7:"sharing";i:0;s:16:"vertical_sharing";i:0;}'),
(2624, 161, '_menu_item_type', 'taxonomy'),
(2625, 161, '_menu_item_menu_item_parent', '115'),
(2626, 161, '_menu_item_object_id', '26'),
(2627, 161, '_menu_item_object', 'product_cat'),
(2628, 161, '_menu_item_target', ''),
(2629, 161, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(2630, 161, '_menu_item_xfn', ''),
(2631, 161, '_menu_item_url', ''),
(2633, 162, '_menu_item_type', 'taxonomy'),
(2634, 162, '_menu_item_menu_item_parent', '115'),
(2635, 162, '_menu_item_object_id', '28'),
(2636, 162, '_menu_item_object', 'product_cat'),
(2637, 162, '_menu_item_target', ''),
(2638, 162, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(2639, 162, '_menu_item_xfn', ''),
(2640, 162, '_menu_item_url', ''),
(2642, 163, '_menu_item_type', 'taxonomy'),
(2643, 163, '_menu_item_menu_item_parent', '115'),
(2644, 163, '_menu_item_object_id', '29'),
(2645, 163, '_menu_item_object', 'product_cat'),
(2646, 163, '_menu_item_target', ''),
(2647, 163, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(2648, 163, '_menu_item_xfn', ''),
(2649, 163, '_menu_item_url', ''),
(2651, 164, '_menu_item_type', 'taxonomy'),
(2652, 164, '_menu_item_menu_item_parent', '115'),
(2653, 164, '_menu_item_object_id', '31'),
(2654, 164, '_menu_item_object', 'product_cat'),
(2655, 164, '_menu_item_target', ''),
(2656, 164, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(2657, 164, '_menu_item_xfn', ''),
(2658, 164, '_menu_item_url', ''),
(2660, 165, '_menu_item_type', 'taxonomy'),
(2661, 165, '_menu_item_menu_item_parent', '115'),
(2662, 165, '_menu_item_object_id', '33'),
(2663, 165, '_menu_item_object', 'product_cat'),
(2664, 165, '_menu_item_target', ''),
(2665, 165, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(2666, 165, '_menu_item_xfn', ''),
(2667, 165, '_menu_item_url', ''),
(2693, 153, '_children', 'a:0:{}'),
(2886, 172, '_variation_description', ''),
(2887, 172, '_sku', ''),
(2888, 172, '_regular_price', '130'),
(2889, 172, '_sale_price', ''),
(2890, 172, '_sale_price_dates_from', ''),
(2891, 172, '_sale_price_dates_to', ''),
(2892, 172, 'total_sales', '0'),
(2893, 172, '_tax_status', 'taxable'),
(2894, 172, '_tax_class', 'parent') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2895, 172, '_manage_stock', 'no'),
(2896, 172, '_backorders', 'no'),
(2897, 172, '_low_stock_amount', ''),
(2898, 172, '_sold_individually', 'no'),
(2899, 172, '_weight', ''),
(2900, 172, '_length', ''),
(2901, 172, '_width', ''),
(2902, 172, '_height', ''),
(2903, 172, '_upsell_ids', 'a:0:{}'),
(2904, 172, '_crosssell_ids', 'a:0:{}'),
(2905, 172, '_purchase_note', ''),
(2906, 172, '_default_attributes', 'a:0:{}'),
(2907, 172, '_virtual', 'no'),
(2908, 172, '_downloadable', 'no'),
(2909, 172, '_product_image_gallery', ''),
(2910, 172, '_download_limit', '-1'),
(2911, 172, '_download_expiry', '-1'),
(2912, 172, '_stock', NULL),
(2913, 172, '_stock_status', 'instock'),
(2914, 172, '_wc_average_rating', '0'),
(2915, 172, '_wc_rating_count', 'a:0:{}'),
(2916, 172, '_wc_review_count', '0'),
(2917, 172, '_downloadable_files', 'a:0:{}'),
(2918, 172, 'attribute_pa_size', '30x30'),
(2919, 172, 'attribute_pa_color', 'grey'),
(2920, 172, '_price', '130'),
(2921, 172, '_product_version', '3.5.3'),
(2922, 173, '_variation_description', ''),
(2923, 173, '_sku', ''),
(2924, 173, '_regular_price', '140'),
(2925, 173, '_sale_price', ''),
(2926, 173, '_sale_price_dates_from', ''),
(2927, 173, '_sale_price_dates_to', ''),
(2928, 173, 'total_sales', '0'),
(2929, 173, '_tax_status', 'taxable'),
(2930, 173, '_tax_class', 'parent'),
(2931, 173, '_manage_stock', 'no'),
(2932, 173, '_backorders', 'no'),
(2933, 173, '_low_stock_amount', ''),
(2934, 173, '_sold_individually', 'no'),
(2935, 173, '_weight', ''),
(2936, 173, '_length', ''),
(2937, 173, '_width', ''),
(2938, 173, '_height', ''),
(2939, 173, '_upsell_ids', 'a:0:{}'),
(2940, 173, '_crosssell_ids', 'a:0:{}'),
(2941, 173, '_purchase_note', ''),
(2942, 173, '_default_attributes', 'a:0:{}'),
(2943, 173, '_virtual', 'no'),
(2944, 173, '_downloadable', 'no'),
(2945, 173, '_product_image_gallery', ''),
(2946, 173, '_download_limit', '-1'),
(2947, 173, '_download_expiry', '-1'),
(2948, 173, '_stock', NULL),
(2949, 173, '_stock_status', 'instock'),
(2950, 173, '_wc_average_rating', '0'),
(2951, 173, '_wc_rating_count', 'a:0:{}'),
(2952, 173, '_wc_review_count', '0'),
(2953, 173, '_downloadable_files', 'a:0:{}'),
(2954, 173, 'attribute_pa_size', '40x40'),
(2955, 173, 'attribute_pa_color', 'grey'),
(2956, 173, '_price', '140'),
(2957, 173, '_product_version', '3.5.3'),
(3030, 176, '_variation_description', ''),
(3031, 176, '_sku', ''),
(3032, 176, '_regular_price', '155'),
(3033, 176, '_sale_price', ''),
(3034, 176, '_sale_price_dates_from', ''),
(3035, 176, '_sale_price_dates_to', ''),
(3036, 176, 'total_sales', '0'),
(3037, 176, '_tax_status', 'taxable'),
(3038, 176, '_tax_class', 'parent'),
(3039, 176, '_manage_stock', 'no'),
(3040, 176, '_backorders', 'no'),
(3041, 176, '_low_stock_amount', ''),
(3042, 176, '_sold_individually', 'no'),
(3043, 176, '_weight', ''),
(3044, 176, '_length', ''),
(3045, 176, '_width', ''),
(3046, 176, '_height', ''),
(3047, 176, '_upsell_ids', 'a:0:{}'),
(3048, 176, '_crosssell_ids', 'a:0:{}'),
(3049, 176, '_purchase_note', ''),
(3050, 176, '_default_attributes', 'a:0:{}'),
(3051, 176, '_virtual', 'no'),
(3052, 176, '_downloadable', 'no'),
(3053, 176, '_product_image_gallery', ''),
(3054, 176, '_download_limit', '-1'),
(3055, 176, '_download_expiry', '-1'),
(3056, 176, '_stock', NULL),
(3057, 176, '_stock_status', 'instock'),
(3058, 176, '_wc_average_rating', '0'),
(3059, 176, '_wc_rating_count', 'a:0:{}'),
(3060, 176, '_wc_review_count', '0'),
(3061, 176, '_downloadable_files', 'a:0:{}'),
(3062, 176, 'attribute_pa_size', '30x30'),
(3063, 176, 'attribute_pa_color', 'white'),
(3064, 176, '_price', '155'),
(3065, 176, '_product_version', '3.5.3'),
(3066, 177, '_variation_description', '') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(3067, 177, '_sku', ''),
(3068, 177, '_regular_price', '130'),
(3069, 177, '_sale_price', ''),
(3070, 177, '_sale_price_dates_from', ''),
(3071, 177, '_sale_price_dates_to', ''),
(3072, 177, 'total_sales', '0'),
(3073, 177, '_tax_status', 'taxable'),
(3074, 177, '_tax_class', 'parent'),
(3075, 177, '_manage_stock', 'no'),
(3076, 177, '_backorders', 'no'),
(3077, 177, '_low_stock_amount', ''),
(3078, 177, '_sold_individually', 'no'),
(3079, 177, '_weight', ''),
(3080, 177, '_length', ''),
(3081, 177, '_width', ''),
(3082, 177, '_height', ''),
(3083, 177, '_upsell_ids', 'a:0:{}'),
(3084, 177, '_crosssell_ids', 'a:0:{}'),
(3085, 177, '_purchase_note', ''),
(3086, 177, '_default_attributes', 'a:0:{}'),
(3087, 177, '_virtual', 'no'),
(3088, 177, '_downloadable', 'no'),
(3089, 177, '_product_image_gallery', ''),
(3090, 177, '_download_limit', '-1'),
(3091, 177, '_download_expiry', '-1'),
(3092, 177, '_stock', NULL),
(3093, 177, '_stock_status', 'instock'),
(3094, 177, '_wc_average_rating', '0'),
(3095, 177, '_wc_rating_count', 'a:0:{}'),
(3096, 177, '_wc_review_count', '0'),
(3097, 177, '_downloadable_files', 'a:0:{}'),
(3098, 177, 'attribute_pa_size', '40x40'),
(3099, 177, 'attribute_pa_color', 'white'),
(3100, 177, '_price', '130'),
(3101, 177, '_product_version', '3.5.3'),
(3212, 153, '_price', '130'),
(3213, 153, '_price', '140'),
(3214, 153, '_price', '155'),
(3215, 153, '_regular_price', ''),
(3216, 153, '_sale_price', ''),
(3217, 8, '_edit_lock', '1550495130:1'),
(3224, 185, 'product-info_0_intro_product_name', 'H-Pillow 1'),
(3225, 185, '_product-info_0_intro_product_name', 'field_5c24fd071a8da'),
(3226, 185, 'product-info_0_intro_product_description', 'Ergonomic &  Light Weight 1'),
(3227, 185, '_product-info_0_intro_product_description', 'field_5c24fc5bc2303'),
(3228, 185, 'product-info_0_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(3229, 185, '_product-info_0_intro_product_link', 'field_5c24fc77c2304'),
(3230, 185, 'product-info_0_intro_product_image', '121'),
(3231, 185, '_product-info_0_intro_product_image', 'field_5c24fc80c2305'),
(3232, 185, 'product-info_1_intro_product_name', 'H-Pillow 2'),
(3233, 185, '_product-info_1_intro_product_name', 'field_5c24fd071a8da'),
(3234, 185, 'product-info_1_intro_product_description', 'Light Weight Ergonomic 2'),
(3235, 185, '_product-info_1_intro_product_description', 'field_5c24fc5bc2303'),
(3236, 185, 'product-info_1_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(3237, 185, '_product-info_1_intro_product_link', 'field_5c24fc77c2304'),
(3238, 185, 'product-info_1_intro_product_image', '48'),
(3239, 185, '_product-info_1_intro_product_image', 'field_5c24fc80c2305'),
(3240, 185, 'product-info_2_intro_product_name', 'H-Pillow 3'),
(3241, 185, '_product-info_2_intro_product_name', 'field_5c24fd071a8da'),
(3242, 185, 'product-info_2_intro_product_description', 'Light Weight Ergonomic 3 '),
(3243, 185, '_product-info_2_intro_product_description', 'field_5c24fc5bc2303'),
(3244, 185, 'product-info_2_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(3245, 185, '_product-info_2_intro_product_link', 'field_5c24fc77c2304'),
(3246, 185, 'product-info_2_intro_product_image', '121'),
(3247, 185, '_product-info_2_intro_product_image', 'field_5c24fc80c2305'),
(3248, 185, 'product-info_3_intro_product_name', 'H-Pillow 4'),
(3249, 185, '_product-info_3_intro_product_name', 'field_5c24fd071a8da'),
(3250, 185, 'product-info_3_intro_product_description', 'Ergonomic &  Light Weight 4'),
(3251, 185, '_product-info_3_intro_product_description', 'field_5c24fc5bc2303'),
(3252, 185, 'product-info_3_intro_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(3253, 185, '_product-info_3_intro_product_link', 'field_5c24fc77c2304'),
(3254, 185, 'product-info_3_intro_product_image', '48'),
(3255, 185, '_product-info_3_intro_product_image', 'field_5c24fc80c2305'),
(3256, 185, 'product-info', '4'),
(3257, 185, '_product-info', 'field_5c24fc17c2302'),
(3258, 185, 'best_deal_product_name', 'Best deal product'),
(3259, 185, '_best_deal_product_name', 'field_5c29e394dd2bf'),
(3260, 185, 'best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(3261, 185, '_best_deal_product_description', 'field_5c29e3cddd2c0'),
(3262, 185, 'best_deal_product_link', 'https://twitter.com/'),
(3263, 185, '_best_deal_product_link', 'field_5c29e3eddd2c1'),
(3264, 185, 'best_deal_title', 'Best deal product'),
(3265, 185, '_best_deal_title', 'field_5c29e394dd2bf'),
(3266, 185, 'best_deal_product_image', '59'),
(3267, 185, '_best_deal_product_image', 'field_5c29e5f076bb9'),
(3268, 185, 'best_deal_product_0_best_deal_title', 'Best deal product'),
(3269, 185, '_best_deal_product_0_best_deal_title', 'field_5c29e7ba26bc1'),
(3270, 185, 'best_deal_product_0_best_deal_product_description', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem \r\naccusantium doloremque laudantium, totam rem aperiam.'),
(3271, 185, '_best_deal_product_0_best_deal_product_description', 'field_5c29e7d026bc2'),
(3272, 185, 'best_deal_product_0_best_deal_product_link', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(3273, 185, '_best_deal_product_0_best_deal_product_link', 'field_5c29e7ea26bc3'),
(3274, 185, 'best_deal_product_0_best_deal_image', '59'),
(3275, 185, '_best_deal_product_0_best_deal_image', 'field_5c29e7f926bc4'),
(3276, 185, 'best_deal_product', '1'),
(3277, 185, '_best_deal_product', 'field_5c29e37d3481d'),
(3278, 185, 'popular_products_title', 'Popular products'),
(3279, 185, '_popular_products_title', 'field_5c29f81657533'),
(3280, 185, 'section_title', 'Best deal product'),
(3281, 185, '_section_title', 'field_5c29f6be784a2'),
(3282, 185, 'latest_product_title', 'Latest products') ;
INSERT INTO `wpth_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(3283, 185, '_latest_product_title', 'field_5c29f97f765f7'),
(3284, 185, 'best_deal_product_0_best_deal_product_', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(3285, 185, '_best_deal_product_0_best_deal_product_', 'field_5c2c7c03078c2'),
(3286, 185, 'best_deal_product_0_best_deal_product_overview', 'http://therapia.test/shop/vaxholm/vaxholm-white-8/'),
(3287, 185, '_best_deal_product_0_best_deal_product_overview', 'field_5c2c7c03078c2'),
(3375, 189, '_wp_attached_file', '2019/02/placeholder.jpg'),
(3376, 189, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:350;s:6:"height";i:350;s:4:"file";s:23:"2019/02/placeholder.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"placeholder-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"placeholder-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-small";a:4:{s:4:"file";s:21:"placeholder-60x60.jpg";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:10:"image/jpeg";}s:17:"custom-size-large";a:4:{s:4:"file";s:23:"placeholder-300x220.jpg";s:5:"width";i:300;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:21:"woocommerce_thumbnail";a:5:{s:4:"file";s:23:"placeholder-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:9:"uncropped";b:1;}s:29:"woocommerce_gallery_thumbnail";a:4:{s:4:"file";s:23:"placeholder-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"placeholder-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:23:"placeholder-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(3377, 189, '_wp_attachment_image_alt', 'empty-image') ;

#
# End of data contents of table `wpth_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wpth_posts`
#

DROP TABLE IF EXISTS `wpth_posts`;


#
# Table structure of table `wpth_posts`
#

CREATE TABLE `wpth_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_posts`
#
INSERT INTO `wpth_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-12-26 13:33:34', '2018-12-26 13:33:34', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2018-12-26 13:33:34', '2018-12-26 13:33:34', '', 0, 'http://therapia.test/?p=1', 0, 'post', '', 1),
(3, 1, '2018-12-26 13:33:34', '2018-12-26 13:33:34', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://therapia.test.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2018-12-26 13:33:34', '2018-12-26 13:33:34', '', 0, 'http://therapia.test/?page_id=3', 0, 'page', '', 0),
(8, 1, '2018-12-26 14:23:52', '2018-12-26 14:23:52', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2018-12-26 14:23:52', '2018-12-26 14:23:52', '', 0, 'http://therapia.test/shop/', 0, 'page', '', 0),
(9, 1, '2018-12-26 14:23:52', '2018-12-26 14:23:52', '[woocommerce_cart]', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2018-12-26 14:23:52', '2018-12-26 14:23:52', '', 0, 'http://therapia.test/cart/', 0, 'page', '', 0),
(10, 1, '2018-12-26 14:23:52', '2018-12-26 14:23:52', '[woocommerce_checkout]', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2018-12-26 14:23:52', '2018-12-26 14:23:52', '', 0, 'http://therapia.test/checkout/', 0, 'page', '', 0),
(11, 1, '2018-12-26 14:23:52', '2018-12-26 14:23:52', '[woocommerce_my_account]', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2018-12-26 14:23:52', '2018-12-26 14:23:52', '', 0, 'http://therapia.test/my-account/', 0, 'page', '', 0),
(12, 1, '2018-12-26 14:30:20', '2018-12-26 14:30:20', '<span style="vertical-align: inherit;">Vaxholm White full descr</span>', 'Vaxholm White (test)', '<span style="vertical-align: inherit;"><span style="vertical-align: inherit;"><span style="vertical-align: inherit;"><span style="vertical-align: inherit;">Vaxholm White descr</span></span></span></span>', 'publish', 'open', 'closed', '', 'vaxholm-white', '', '', '2019-02-07 16:36:26', '2019-02-07 16:36:26', '', 0, 'http://therapia.test/?post_type=product&#038;p=12', 0, 'product', '', 0),
(13, 1, '2018-12-26 14:30:11', '2018-12-26 14:30:11', '', 'product-img', '', 'inherit', 'open', 'closed', '', 'product-img-1', '', '', '2018-12-26 14:30:17', '2018-12-26 14:30:17', '', 12, 'http://therapia.test/wp-content/uploads/2018/12/product-img-1.png', 0, 'attachment', 'image/png', 0),
(16, 1, '2018-12-26 14:32:32', '2018-12-26 14:32:32', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-02-20 10:09:19', '2019-02-20 10:09:19', '', 0, 'http://therapia.test/home/', 1, 'nav_menu_item', '', 0),
(17, 1, '2018-12-26 14:32:33', '2018-12-26 14:32:33', ' ', '', '', 'publish', 'closed', 'closed', '', '17', '', '', '2019-02-20 10:09:19', '2019-02-20 10:09:19', '', 0, 'http://therapia.test/17/', 9, 'nav_menu_item', '', 0),
(19, 1, '2018-12-26 14:36:58', '2018-12-26 14:36:58', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-02-18 15:36:57', '2019-02-18 15:36:57', '', 0, 'http://therapia.test/?page_id=19', 0, 'page', '', 0),
(20, 1, '2018-12-26 14:36:58', '2018-12-26 14:36:58', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-12-26 14:36:58', '2018-12-26 14:36:58', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2018-12-26 14:43:03', '2018-12-26 14:43:03', '[email* email-423 class:subscribe-input placeholder "Enter your e-mail address"]\r\n[submit class:btn class:btn_light "Sign up"]\n1\nSubscriber\nTherapia shop <wordpress@test6.f5-cloud.top>\nwp.test.mail.for.me@gmail.com\nFrom: <[email-423]>\r\nSubject: subscriber\r\n\r\nMessage Body:\r\n\'Subscriber email\' [email-423]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Therapia shop (http://therapia.test)\nReply-To: wp.test.mail.for.me@gmail.com\n\n\n\n\nTherapia shop "[your-subject]"\nTherapia shop <wordpress@therapia.test>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Therapia shop (http://therapia.test)\nReply-To: wp.test.mail.for.me@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nEmail field have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Footer subscribe form', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2019-03-25 12:43:10', '2019-03-25 12:43:10', '', 0, 'http://therapia.test/?post_type=wpcf7_contact_form&#038;p=23', 0, 'wpcf7_contact_form', '', 0),
(25, 1, '2018-12-26 16:08:19', '2018-12-26 16:08:19', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:11:"acf-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Logo main', 'logo-main', 'publish', 'closed', 'closed', '', 'group_5c23a718d91c9', '', '', '2019-01-04 13:13:52', '2019-01-04 13:13:52', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=25', 0, 'acf-field-group', '', 0),
(26, 1, '2018-12-26 16:08:20', '2018-12-26 16:08:20', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:29:"Min width: 80\r\nMih height: 30";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";i:80;s:10:"min_height";i:30;s:8:"min_size";s:0:"";s:9:"max_width";i:400;s:10:"max_height";i:400;s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Main logo', 'logo_image', 'publish', 'closed', 'closed', '', 'field_5c23a72f50a29', '', '', '2019-01-04 13:12:19', '2019-01-04 13:12:19', '', 25, 'http://therapia.test/?post_type=acf-field&#038;p=26', 0, 'acf-field', '', 0),
(27, 1, '2018-12-26 16:09:39', '2018-12-26 16:09:39', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:11:"acf-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Social links', 'social-links', 'publish', 'closed', 'closed', '', 'group_5c23a77c971f1', '', '', '2018-12-26 16:45:00', '2018-12-26 16:45:00', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=27', 0, 'acf-field-group', '', 0),
(28, 1, '2018-12-26 16:09:39', '2018-12-26 16:09:39', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Facebook link', 'facebook_link', 'publish', 'closed', 'closed', '', 'field_5c23a791b9d1d', '', '', '2018-12-26 16:09:39', '2018-12-26 16:09:39', '', 27, 'http://therapia.test/?post_type=acf-field&p=28', 0, 'acf-field', '', 0),
(29, 1, '2018-12-26 16:10:12', '2018-12-26 16:10:12', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Twitter link', 'twitter_link', 'publish', 'closed', 'closed', '', 'field_5c23a7c6fa906', '', '', '2018-12-26 16:10:12', '2018-12-26 16:10:12', '', 27, 'http://therapia.test/?post_type=acf-field&p=29', 1, 'acf-field', '', 0),
(30, 1, '2018-12-26 16:10:39', '2018-12-26 16:10:39', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Instagram link', 'instagram_link', 'publish', 'closed', 'closed', '', 'field_5c23a7e791e73', '', '', '2018-12-26 16:45:00', '2018-12-26 16:45:00', '', 27, 'http://therapia.test/?post_type=acf-field&#038;p=30', 2, 'acf-field', '', 0),
(31, 1, '2018-12-26 16:11:06', '2018-12-26 16:11:06', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Pinterest link', 'pinterest_link', 'publish', 'closed', 'closed', '', 'field_5c23a802d9b74', '', '', '2018-12-26 16:11:06', '2018-12-26 16:11:06', '', 27, 'http://therapia.test/?post_type=acf-field&p=31', 3, 'acf-field', '', 0),
(33, 1, '2018-12-26 16:17:18', '2018-12-26 16:17:18', '', 'logo-image', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2018-12-26 16:17:26', '2018-12-26 16:17:26', '', 0, 'http://therapia.test/wp-content/uploads/2018/12/logo.png', 0, 'attachment', 'image/png', 0),
(34, 1, '2018-12-26 16:18:10', '2018-12-26 16:18:10', '', 'footer-logo-image', '', 'inherit', 'open', 'closed', '', 'logo-footer', '', '', '2018-12-26 16:18:27', '2018-12-26 16:18:27', '', 0, 'http://therapia.test/wp-content/uploads/2018/12/logo-footer.jpg', 0, 'attachment', 'image/jpeg', 0),
(39, 1, '2018-12-27 16:10:26', '2018-12-27 16:10:26', 'Vaxholm White description', 'Vaxholm White', 'Vaxholm White descr', 'publish', 'open', 'closed', '', 'vaxholm-white-2', '', '', '2019-01-02 08:38:18', '2019-01-02 08:38:18', '', 0, 'http://therapia.test/?post_type=product&#038;p=39', 0, 'product', '', 0),
(40, 1, '2018-12-27 16:24:59', '2018-12-27 16:24:59', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:12:"tpl-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Section intro products', 'section-intro-products', 'publish', 'closed', 'closed', '', 'group_5c24fb9c5a068', '', '', '2019-01-30 09:55:31', '2019-01-30 09:55:31', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=40', 0, 'acf-field-group', '', 0),
(41, 1, '2018-12-27 16:24:59', '2018-12-27 16:24:59', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:10:"Min row: 2";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";i:2;s:3:"max";i:6;s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'intro product info', 'product-info', 'publish', 'closed', 'closed', '', 'field_5c24fc17c2302', '', '', '2018-12-31 11:01:27', '2018-12-31 11:01:27', '', 40, 'http://therapia.test/?post_type=acf-field&#038;p=41', 0, 'acf-field', '', 0),
(42, 1, '2018-12-27 16:24:59', '2018-12-27 16:24:59', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";i:45;}', 'intro product description', 'intro_product_description', 'publish', 'closed', 'closed', '', 'field_5c24fc5bc2303', '', '', '2019-01-30 09:55:30', '2019-01-30 09:55:30', '', 41, 'http://therapia.test/?post_type=acf-field&#038;p=42', 1, 'acf-field', '', 0),
(43, 1, '2018-12-27 16:24:59', '2018-12-27 16:24:59', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:1;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:2:{s:5:"field";s:19:"field_5c24fc17c2302";s:8:"operator";s:7:"!=empty";}}}}', 'intro product link', 'intro_product_link', 'publish', 'closed', 'closed', '', 'field_5c24fc77c2304', '', '', '2018-12-27 16:26:12', '2018-12-27 16:26:12', '', 41, 'http://therapia.test/?post_type=acf-field&#038;p=43', 2, 'acf-field', '', 0),
(44, 1, '2018-12-27 16:24:59', '2018-12-27 16:24:59', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:93:"You must upload images proportional only (example 515x515)\r\n\r\nMin width: 200\r\nMin height: 200";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";i:200;s:10:"min_height";i:200;s:8:"min_size";s:0:"";s:9:"max_width";i:1600;s:10:"max_height";i:1600;s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'intro product image', 'intro_product_image', 'publish', 'closed', 'closed', '', 'field_5c24fc80c2305', '', '', '2018-12-27 16:49:15', '2018-12-27 16:49:15', '', 41, 'http://therapia.test/?post_type=acf-field&#038;p=44', 3, 'acf-field', '', 0),
(47, 1, '2018-12-27 16:26:12', '2018-12-27 16:26:12', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'intro product name', 'intro_product_name', 'publish', 'closed', 'closed', '', 'field_5c24fd071a8da', '', '', '2018-12-27 16:26:12', '2018-12-27 16:26:12', '', 41, 'http://therapia.test/?post_type=acf-field&p=47', 0, 'acf-field', '', 0),
(48, 1, '2018-12-27 16:44:45', '2018-12-27 16:44:45', '', 'product-img', '', 'inherit', 'open', 'closed', '', 'product-img-2', '', '', '2018-12-27 16:44:52', '2018-12-27 16:44:52', '', 19, 'http://therapia.test/wp-content/uploads/2018/12/product-img-2.png', 0, 'attachment', 'image/png', 0),
(49, 1, '2018-12-27 16:45:18', '2018-12-27 16:45:18', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-12-27 16:45:18', '2018-12-27 16:45:18', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2018-12-28 09:58:41', '2018-12-28 09:58:41', 'Vaxholm White description', 'Vaxholm White', 'Vaxholm White descr', 'publish', 'open', 'closed', '', 'vaxholm-white-3', '', '', '2019-01-03 08:02:25', '2019-01-03 08:02:25', '', 0, 'http://therapia.test/?post_type=product&#038;p=50', 0, 'product', '', 0),
(51, 1, '2018-12-28 09:59:18', '2018-12-28 09:59:18', 'Vaxholm White description', 'Vaxholm White (test 2)', 'Vaxholm White descr', 'publish', 'open', 'closed', '', 'vaxholm-white-4', '', '', '2019-01-22 16:01:32', '2019-01-22 16:01:32', '', 0, 'http://therapia.test/?post_type=product&#038;p=51', 0, 'product', '', 0),
(52, 1, '2018-12-31 09:38:26', '2018-12-31 09:38:26', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:12:"tpl-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Section best-deal', 'section-best-deal', 'publish', 'closed', 'closed', '', 'group_5c29e375c9d32', '', '', '2019-01-02 09:05:00', '2019-01-02 09:05:00', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=52', 0, 'acf-field-group', '', 0),
(53, 1, '2018-12-31 09:38:26', '2018-12-31 09:38:26', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'best-deal product info', 'best_deal_product', 'publish', 'closed', 'closed', '', 'field_5c29e37d3481d', '', '', '2018-12-31 11:05:34', '2018-12-31 11:05:34', '', 52, 'http://therapia.test/?post_type=acf-field&#038;p=53', 0, 'acf-field', '', 0),
(57, 1, '2018-12-31 09:47:57', '2018-12-31 09:47:57', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-12-31 09:47:57', '2018-12-31 09:47:57', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2018-12-31 09:51:18', '2018-12-31 09:51:18', '', 'best-deal-product', '', 'inherit', 'open', 'closed', '', 'best-deal_product', '', '', '2018-12-31 09:51:28', '2018-12-31 09:51:28', '', 19, 'http://therapia.test/wp-content/uploads/2018/12/best-deal_product.png', 0, 'attachment', 'image/png', 0),
(60, 1, '2018-12-31 09:51:30', '2018-12-31 09:51:30', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-12-31 09:51:30', '2018-12-31 09:51:30', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(61, 1, '2018-12-31 09:58:15', '2018-12-31 09:58:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'best deal title', 'best_deal_title', 'publish', 'closed', 'closed', '', 'field_5c29e7ba26bc1', '', '', '2019-01-02 09:05:00', '2019-01-02 09:05:00', '', 53, 'http://therapia.test/?post_type=acf-field&#038;p=61', 0, 'acf-field', '', 0),
(62, 1, '2018-12-31 09:58:15', '2018-12-31 09:58:15', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'best deal product description', 'best_deal_product_description', 'publish', 'closed', 'closed', '', 'field_5c29e7d026bc2', '', '', '2019-01-02 09:05:00', '2019-01-02 09:05:00', '', 53, 'http://therapia.test/?post_type=acf-field&#038;p=62', 1, 'acf-field', '', 0),
(63, 1, '2018-12-31 09:58:15', '2018-12-31 09:58:15', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'best deal product link', 'best_deal_product_link', 'publish', 'closed', 'closed', '', 'field_5c29e7ea26bc3', '', '', '2019-01-02 09:05:00', '2019-01-02 09:05:00', '', 53, 'http://therapia.test/?post_type=acf-field&#038;p=63', 2, 'acf-field', '', 0),
(64, 1, '2018-12-31 09:58:15', '2018-12-31 09:58:15', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:35:"Min width: 200px\r\nMin height: 200px";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";i:200;s:10:"min_height";i:200;s:8:"min_size";s:0:"";s:9:"max_width";i:2000;s:10:"max_height";i:2000;s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'best deal image', 'best_deal_image', 'publish', 'closed', 'closed', '', 'field_5c29e7f926bc4', '', '', '2019-01-02 09:05:00', '2019-01-02 09:05:00', '', 53, 'http://therapia.test/?post_type=acf-field&#038;p=64', 3, 'acf-field', '', 0),
(65, 1, '2018-12-31 09:59:58', '2018-12-31 09:59:58', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-12-31 09:59:58', '2018-12-31 09:59:58', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2018-12-31 11:06:31', '2018-12-31 11:06:31', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:12:"tpl-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Section popular products', 'section-popular-products', 'publish', 'closed', 'closed', '', 'group_5c29f80547b5f', '', '', '2018-12-31 11:06:31', '2018-12-31 11:06:31', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=68', 0, 'acf-field-group', '', 0),
(69, 1, '2018-12-31 11:06:31', '2018-12-31 11:06:31', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'popular products title', 'popular_products_title', 'publish', 'closed', 'closed', '', 'field_5c29f81657533', '', '', '2018-12-31 11:06:31', '2018-12-31 11:06:31', '', 68, 'http://therapia.test/?post_type=acf-field&p=69', 0, 'acf-field', '', 0),
(70, 1, '2018-12-31 11:08:00', '2018-12-31 11:08:00', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-12-31 11:08:00', '2018-12-31 11:08:00', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2018-12-31 11:12:21', '2018-12-31 11:12:21', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:12:"tpl-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Section latest product', 'section-latest-product', 'publish', 'closed', 'closed', '', 'group_5c29f955abde1', '', '', '2018-12-31 11:14:55', '2018-12-31 11:14:55', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=71', 0, 'acf-field-group', '', 0),
(72, 1, '2018-12-31 11:12:21', '2018-12-31 11:12:21', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'latest product title', 'latest_product_title', 'publish', 'closed', 'closed', '', 'field_5c29f97f765f7', '', '', '2018-12-31 11:12:21', '2018-12-31 11:12:21', '', 71, 'http://therapia.test/?post_type=acf-field&p=72', 0, 'acf-field', '', 0),
(73, 1, '2018-12-31 11:13:11', '2018-12-31 11:13:11', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-12-31 11:13:11', '2018-12-31 11:13:11', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2019-01-02 08:37:11', '2019-01-02 08:37:11', '', 'product-image', '', 'inherit', 'open', 'closed', '', 'product-image-1', '', '', '2019-01-02 08:37:19', '2019-01-02 08:37:19', '', 12, 'http://therapia.test/wp-content/uploads/2018/12/product-image-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2019-01-02 08:38:10', '2019-01-02 08:38:10', '', 'product-image', '', 'inherit', 'open', 'closed', '', 'product-image-2', '', '', '2019-01-02 08:38:15', '2019-01-02 08:38:15', '', 39, 'http://therapia.test/wp-content/uploads/2018/12/product-image-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2019-01-02 08:38:39', '2019-01-02 08:38:39', '', 'product-image', '', 'inherit', 'open', 'closed', '', 'product-image-3', '', '', '2019-01-02 08:38:44', '2019-01-02 08:38:44', '', 50, 'http://therapia.test/wp-content/uploads/2018/12/product-image-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2019-01-02 08:39:07', '2019-01-02 08:39:07', '', 'product-image', '', 'inherit', 'open', 'closed', '', 'product-image-4', '', '', '2019-01-02 08:39:12', '2019-01-02 08:39:12', '', 51, 'http://therapia.test/wp-content/uploads/2018/12/product-image-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(78, 1, '2019-01-02 08:42:09', '2019-01-02 08:42:09', 'Vaxholm White description', 'Vaxholm White', 'Vaxholm White descr', 'publish', 'open', 'closed', '', 'vaxholm-white-5', '', '', '2019-01-03 08:02:38', '2019-01-03 08:02:38', '', 0, 'http://therapia.test/?post_type=product&#038;p=78', 0, 'product', '', 0),
(79, 1, '2019-01-02 08:42:03', '2019-01-02 08:42:03', '', 'product-image', '', 'inherit', 'open', 'closed', '', 'product-image', '', '', '2019-01-02 08:42:06', '2019-01-02 08:42:06', '', 78, 'http://therapia.test/wp-content/uploads/2019/01/product-image.png', 0, 'attachment', 'image/png', 0),
(80, 1, '2019-01-02 08:42:42', '2019-01-02 08:42:42', 'Vaxholm White description', 'Vaxholm White', 'Vaxholm White descr', 'publish', 'open', 'closed', '', 'vaxholm-white-6', '', '', '2019-01-03 08:02:43', '2019-01-03 08:02:43', '', 0, 'http://therapia.test/?post_type=product&#038;p=80', 0, 'product', '', 0),
(81, 1, '2019-01-02 08:43:11', '2019-01-02 08:43:11', 'Vaxholm White description', 'Vaxholm White', 'Vaxholm White descr', 'publish', 'open', 'closed', '', 'vaxholm-white-7', '', '', '2019-01-03 08:02:49', '2019-01-03 08:02:49', '', 0, 'http://therapia.test/?post_type=product&#038;p=81', 0, 'product', '', 0),
(82, 1, '2019-01-02 08:43:44', '2019-01-02 08:43:44', 'Vaxholm White description', 'Vaxholm White', 'Vaxholm White descr', 'publish', 'open', 'closed', '', 'vaxholm-white-8', '', '', '2019-01-03 14:28:06', '2019-01-03 14:28:06', '', 0, 'http://therapia.test/?post_type=product&#038;p=82', 0, 'product', '', 0),
(85, 1, '2019-01-02 08:50:01', '2019-01-02 08:50:01', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-autosave-v1', '', '', '2019-01-02 08:50:01', '2019-01-02 08:50:01', '', 19, 'http://therapia.test/19-autosave-v1/', 0, 'revision', '', 0),
(86, 1, '2019-01-02 08:50:18', '2019-01-02 08:50:18', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-02 08:50:18', '2019-01-02 08:50:18', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(88, 1, '2019-01-02 08:55:11', '2019-01-02 08:55:11', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-02 08:55:11', '2019-01-02 08:55:11', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2019-01-02 08:58:13', '2019-01-02 08:58:13', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-02 08:58:13', '2019-01-02 08:58:13', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2019-01-02 12:35:28', '2019-01-02 12:35:28', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:11:"acf-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Footer subscribe form', 'footer-subscribe-form', 'publish', 'closed', 'closed', '', 'group_5c2cafd08a002', '', '', '2019-01-02 12:35:38', '2019-01-02 12:35:38', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=92', 0, 'acf-field-group', '', 0),
(93, 1, '2019-01-02 12:35:28', '2019-01-02 12:35:28', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'subscribe form title', 'subscribe_form_title', 'publish', 'closed', 'closed', '', 'field_5c2cafddbeef6', '', '', '2019-01-02 12:35:28', '2019-01-02 12:35:28', '', 92, 'http://therapia.test/?post_type=acf-field&p=93', 0, 'acf-field', '', 0),
(94, 1, '2019-01-02 12:35:28', '2019-01-02 12:35:28', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'subscribe form info', 'subscribe_form_info', 'publish', 'closed', 'closed', '', 'field_5c2caff1beef7', '', '', '2019-01-02 12:35:28', '2019-01-02 12:35:28', '', 92, 'http://therapia.test/?post_type=acf-field&p=94', 1, 'acf-field', '', 0),
(95, 1, '2019-01-02 13:33:41', '2019-01-02 13:33:41', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:11:"acf-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Logo secondary', 'logo-secondary', 'publish', 'closed', 'closed', '', 'group_5c2cbd6d00ddc', '', '', '2019-01-31 12:30:11', '2019-01-31 12:30:11', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=95', 0, 'acf-field-group', '', 0),
(96, 1, '2019-01-02 13:33:41', '2019-01-02 13:33:41', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:29:"Min width: 60\r\nMin height: 60";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";i:60;s:10:"min_height";i:60;s:8:"min_size";s:0:"";s:9:"max_width";i:1200;s:10:"max_height";i:1200;s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Secondary logo', 'footer_logo_image', 'publish', 'closed', 'closed', '', 'field_5c2cbd7c3f9f4', '', '', '2019-01-31 12:30:11', '2019-01-31 12:30:11', '', 95, 'http://therapia.test/?post_type=acf-field&#038;p=96', 0, 'acf-field', '', 0),
(98, 1, '2019-01-02 14:18:50', '2019-01-02 14:18:50', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:11:"acf-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Footer contacts', 'footer-contacts', 'publish', 'closed', 'closed', '', 'group_5c2cc82b0ca82', '', '', '2019-01-02 14:22:01', '2019-01-02 14:22:01', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=98', 0, 'acf-field-group', '', 0),
(99, 1, '2019-01-02 14:18:50', '2019-01-02 14:18:50', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'footer contact email', 'footer_contact_email', 'publish', 'closed', 'closed', '', 'field_5c2cc83eff21a', '', '', '2019-01-02 14:20:21', '2019-01-02 14:20:21', '', 98, 'http://therapia.test/?post_type=acf-field&#038;p=99', 0, 'acf-field', '', 0),
(100, 1, '2019-01-02 14:20:21', '2019-01-02 14:20:21', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'footer contact tel', 'footer_contact_tel', 'publish', 'closed', 'closed', '', 'field_5c2cc8646a238', '', '', '2019-01-02 14:22:01', '2019-01-02 14:22:01', '', 98, 'http://therapia.test/?post_type=acf-field&#038;p=100', 1, 'acf-field', '', 0),
(101, 1, '2019-01-02 14:20:22', '2019-01-02 14:20:22', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'footer contact adress', 'footer_contact_adress', 'publish', 'closed', 'closed', '', 'field_5c2cc8986a239', '', '', '2019-01-02 14:20:22', '2019-01-02 14:20:22', '', 98, 'http://therapia.test/?post_type=acf-field&p=101', 2, 'acf-field', '', 0),
(104, 1, '2019-01-03 13:08:46', '2019-01-03 13:08:46', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-03 13:08:46', '2019-01-03 13:08:46', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2019-01-03 13:10:08', '2019-01-03 13:10:08', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-03 13:10:08', '2019-01-03 13:10:08', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2019-01-03 13:10:58', '2019-01-03 13:10:58', '', 'product-image', '', 'inherit', 'open', 'closed', '', 'product-image-5', '', '', '2019-01-03 13:11:01', '2019-01-03 13:11:01', '', 19, 'http://therapia.test/wp-content/uploads/2019/01/product-image-1.png', 0, 'attachment', 'image/png', 0),
(107, 1, '2019-01-03 13:11:58', '2019-01-03 13:11:58', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-03 13:11:58', '2019-01-03 13:11:58', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2019-01-03 13:18:28', '2019-01-03 13:18:28', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-03 13:18:28', '2019-01-03 13:18:28', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(109, 1, '2019-01-03 13:21:17', '2019-01-03 13:21:17', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-03 13:21:17', '2019-01-03 13:21:17', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(111, 1, '2019-01-03 14:32:18', '2019-01-03 14:32:18', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:11:"acf-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Copyright', 'copyright', 'publish', 'closed', 'closed', '', 'group_5c2e1cd48316f', '', '', '2019-01-03 14:32:18', '2019-01-03 14:32:18', '', 0, 'http://therapia.test/?post_type=acf-field-group&#038;p=111', 0, 'acf-field-group', '', 0),
(112, 1, '2019-01-03 14:32:18', '2019-01-03 14:32:18', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Copyright text', 'copyright_text', 'publish', 'closed', 'closed', '', 'field_5c2e1ce832502', '', '', '2019-01-03 14:32:18', '2019-01-03 14:32:18', '', 111, 'http://therapia.test/?post_type=acf-field&p=112', 0, 'acf-field', '', 0),
(113, 1, '2019-01-03 14:40:51', '2019-01-03 14:40:51', '', 'Categories', '', 'publish', 'closed', 'closed', '', 'categories', '', '', '2019-01-03 14:49:26', '2019-01-03 14:49:26', '', 0, 'http://therapia.test/?page_id=113', 0, 'page', '', 0),
(114, 1, '2019-01-03 14:40:51', '2019-01-03 14:40:51', '', 'Categories', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2019-01-03 14:40:51', '2019-01-03 14:40:51', '', 113, 'http://therapia.test/113-revision-v1/', 0, 'revision', '', 0),
(115, 1, '2019-01-03 14:42:20', '2019-01-03 14:42:20', ' ', '', '', 'publish', 'closed', 'closed', '', '115', '', '', '2019-02-20 10:09:19', '2019-02-20 10:09:19', '', 0, 'http://therapia.test/?p=115', 2, 'nav_menu_item', '', 0),
(118, 1, '2019-01-03 15:08:17', '2019-01-03 15:08:17', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-03 15:08:17', '2019-01-03 15:08:17', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(120, 1, '2019-01-04 08:12:55', '2019-01-04 08:12:55', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-04 08:12:55', '2019-01-04 08:12:55', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(121, 1, '2019-01-04 08:14:56', '2019-01-04 08:14:56', '', 'product-img-1', '', 'inherit', 'open', 'closed', '', 'product-img-1-2', '', '', '2019-01-04 08:14:56', '2019-01-04 08:14:56', '', 19, 'http://therapia.test/wp-content/uploads/2019/01/product-img-1.png', 0, 'attachment', 'image/png', 0),
(123, 1, '2019-01-04 08:15:30', '2019-01-04 08:15:30', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-04 08:15:30', '2019-01-04 08:15:30', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2019-01-04 14:48:00', '2019-01-04 14:48:00', '', 'Vaxholm White (test)', '', 'publish', 'closed', 'closed', '', 'vaxholm-white-test', '', '', '2019-01-22 09:14:29', '2019-01-22 09:14:29', '', 12, 'http://therapia.test/product/vaxholm/vaxholm-white/', 4, 'product_variation', '', 0),
(125, 1, '2019-01-04 15:06:21', '2019-01-04 15:06:21', '', 'Vaxholm White (test)', '', 'publish', 'closed', 'closed', '', 'vaxholm-white-test-2', '', '', '2019-01-22 09:14:29', '2019-01-22 09:14:29', '', 12, 'http://therapia.test/product/vaxholm/vaxholm-white/', 3, 'product_variation', '', 0),
(127, 1, '2019-01-04 15:08:02', '2019-01-04 15:08:02', '', 'Vaxholm White (test)', '', 'publish', 'closed', 'closed', '', 'vaxholm-white-test-30x30-black', '', '', '2019-01-22 09:14:38', '2019-01-22 09:14:38', '', 12, 'http://therapia.test/product/vaxholm/vaxholm-white/', 1, 'product_variation', '', 0),
(128, 1, '2019-01-04 15:08:02', '2019-01-04 15:08:02', '', 'Vaxholm White (test)', '', 'publish', 'closed', 'closed', '', 'vaxholm-white-test-40x40-black', '', '', '2019-01-04 15:08:40', '2019-01-04 15:08:40', '', 12, 'http://therapia.test/product/vaxholm/vaxholm-white/', 2, 'product_variation', '', 0),
(131, 1, '2019-01-30 10:22:56', '2019-01-30 10:22:56', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-30 10:22:56', '2019-01-30 10:22:56', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2019-01-31 12:43:06', '2019-01-31 12:43:06', '', 'secondary-logo', '', 'inherit', 'open', 'closed', '', 'footer-logo', '', '', '2019-01-31 12:43:17', '2019-01-31 12:43:17', '', 0, 'http://therapia.test/wp-content/uploads/2019/01/footer-logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(133, 1, '2019-01-31 13:15:38', '2019-01-31 13:15:38', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-01-31 13:15:38', '2019-01-31 13:15:38', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(135, 1, '2019-02-06 14:42:17', '2019-02-06 14:42:17', '<ul>\r\n 	<li>About the product THE ADJUSTABLE PILLOW YOUR BABY DESERVES: Most baby pillows become absolute once your baby grows up a bit,Not WinnAir ones - our pillows can "grow" along with your baby! By adjusting its size and adding 2 additional air mesh filling, you can continue using the pillow for your baby until they are 3 years old! DESIGNED FOR COMFORT, SUPPORT &amp;SAFETY: Your baby deserves nothing but the best, and this premium pillow is exactly that: It\'s designed to support your baby\'s head and neck during rest and sleep position.</li>\r\n 	<li>It distributes the pressure equally, reduce the risk to develop flat head syndrome issues, promotes blood circulation, and creates a comfortable and protective environment. Moreover, there are no zippers that can harm your baby. FOR QUIET NIGHTS: By utilizing a unique honeycomb-hole air mesh fabric design, these pillows not only support your baby\'s head and neck, but also allows the best possible air flow for babies: the air can go directly through them, which makes them very breathable. Our pillows are washable, easy to clean and dry fast.</li>\r\n 	<li>They are also antimicrobial, anti-static, anti-dust mite, eco-friendly, and 100% recyclable. PREMIUM QUALITY MATERIALS: When it comes to our baby pillow, we make a point of using nothing but the best and finest materials that have a Textile safety certification, as well as state-of-the-art production processes and strict quality control. The pillows cover is made of Tencel, an eco-friendly,gentle and soft fabric that is very friendly to the baby\'s sensitive skin and has a moisture wicking effect, minimizing sweating and maximizing comfort.</li>\r\n</ul>\r\n', 'Premium Breathable Baby Pillow for Our Little Ones', '<span class="a-list-item">THE ADJUSTABLE PILLOW YOUR BABY DESERVES!</span>', 'publish', 'open', 'closed', '', 'premium-breathable-baby-pillow-for-our-little-ones-designed-for-safety-comfort-adjustable-for-newborns-babies-toddlers-0-3-or-children-3-8-beautiful-light-green-cute-elephant-design-3-8', '', '', '2019-02-18 15:01:08', '2019-02-18 15:01:08', '', 0, 'http://therapia.test/?post_type=product&#038;p=135', 0, 'product', '', 0),
(136, 1, '2019-02-06 14:43:25', '2019-02-06 14:43:25', '', 'product-image', '', 'inherit', 'open', 'closed', '', '91tw-ntzral-_sx522_', '', '', '2019-02-06 14:43:34', '2019-02-06 14:43:34', '', 135, 'http://therapia.test/wp-content/uploads/2019/02/91Tw-ntzrAL._SX522_.jpg', 0, 'attachment', 'image/jpeg', 0),
(137, 1, '2019-02-06 14:50:17', '2019-02-06 14:50:17', 'LARGE LUNCH COOLER BACKPACK: Deep main storage compartment is large enough to provide roomy capacity for your meals, beers, snacks or other food, can hold up to 28 cans INSULATED COOLER: High-Density insulation material, THICK liner inside of the insulated backpacks work to make sure to keep food hot/cold for hours DURABLE and WATER RESISTANT: Made of leak resistant (Not leakproof. Not suitable for containing bulk ice cubes inside, unless kept in a special container), durable fabric, lightweight backpack with cooler for lunches, picnics, road/ beach trips, hiking, camping, fishing, perfect gift for boys girls men and women MULTIPLE POCKETS: 1 main roomy storage compartment, 2 side mesh pockets, 1 large front zipper pocket with mesh divider; Dimension: 17.9" x 13.2" x 7.7" (L x W x H), Weight: 1.25 pounds / 650g, about 30L, own enough space for all you belongings', 'Perfect Insulated Cooler Backpack', '<span class="a-list-item">LARGE LUNCH COOLER BACKPACK</span>', 'publish', 'open', 'closed', '', 'perfect-insulated-cooler-backpack-soft-cooler-lightweight-backpack-cooler-lunches', '', '', '2019-02-07 15:18:58', '2019-02-07 15:18:58', '', 0, 'http://therapia.test/?post_type=product&#038;p=137', 0, 'product', '', 0),
(139, 1, '2019-02-06 15:10:56', '2019-02-06 15:10:56', '', 'Perfect Insulated Cooler Backpack', '', 'publish', 'closed', 'closed', '', 'perfect-insulated-cooler-backpack', '', '', '2019-02-06 15:11:17', '2019-02-06 15:11:17', '', 137, 'http://therapia.test/product/uncategorized/perfect-insulated-cooler-backpack-soft-cooler-lightweight-backpack-cooler-lunches/', 1, 'product_variation', '', 0),
(140, 1, '2019-02-06 15:10:56', '2019-02-06 15:10:56', '', 'Perfect Insulated Cooler Backpack', '', 'publish', 'closed', 'closed', '', 'perfect-insulated-cooler-backpack-2', '', '', '2019-02-06 15:11:35', '2019-02-06 15:11:35', '', 137, 'http://therapia.test/product/uncategorized/perfect-insulated-cooler-backpack-soft-cooler-lightweight-backpack-cooler-lunches/', 2, 'product_variation', '', 0) ;
INSERT INTO `wpth_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(141, 1, '2019-02-06 15:18:11', '2019-02-06 15:18:11', 'QUALITY CABINET LATCHES: Made of top quality ABS with 3M adhesive, the KIDS SAFETY PLUS MAGNETIC CUPBOARD LOCK SET comes complete with 12 Locks and Latches and 2 Keys; using attached 3M tape, the locks secure drawers, cabinets, cupboards, and appliances to protect infants and toddlers; they work on flat surfaces of cabinets made of wood, stainless steel, plastic, porcelain, and acrylic EASY TO INSTALL: The KIDS SAFETY PLUS WHITE CABINET LOCKS can be installed quickly as there are no tools required; line up the lock and latch with a cabinet door with or without an inserted frame that is up to 1.65 inches thick, peel off the 3M tape backings, and place the lock and latch into position; by using the magnetic key on the outside of the cupboard, it instantly unlocks or locks the door; the lock can also be used manually EASY TO USE: Using the MAGNETIC LOCKS BY KIDS SAFETY PLUS, your child cannot open a drawer, cabinet, or appliance with ease; the latch opens easily when the key is set on the outside of the positioned lock; they can be removed without the 3M tape damaging surfaces of furniture, cabinets, or appliances; these safety locks take less than a few minutes to install and uninstall, leaving no damage to furniture or appliances HIDDEN FROM VIEW: The KIDS SAFETY PLUS LOCKS are perfect for parents, grandparents, and daycares to keep infants and toddlers out of unsafe areas where chemicals, medicines, or other dangerous or caustic products are kept; with the mechanism being virtually unable to see, it does not infringe on your décor; each lock measures 1.5 by 1.4 by 1.5 inches while the latch is 1.75 by 1 inch and the key is 1.5 inches in diameter SATISFACTION GUARANTEE: We are a reliable company and know you will be impressed with our product; if you are not completely satisfied, please contact us immediately; BUY WITH CONFIDENCE the KIDS SAFETY PLUS MAGNETIC CABINET LOCK SET that comes with 12 Locks and Latches with 3M tape plus 2 Magnetic Keys, and easy-to-follow instructions; have peace of mind when you need to keep your young ones safe and out of your cupboards, cabinets, and drawers', 'Magnetic Baby Safety Locks', '', 'publish', 'open', 'closed', '', 'magnetic-baby-safety-locks', '', '', '2019-02-18 13:27:09', '2019-02-18 13:27:09', '', 0, 'http://therapia.test/?post_type=product&#038;p=141', 0, 'product', '', 1),
(142, 1, '2019-02-06 15:17:36', '2019-02-06 15:17:36', '<ul class="a-unordered-list a-vertical a-spacing-none">\n 	<li><span class="a-list-item">LARGE LUNCH COOLER BACKPACK: Deep main storage compartment is large enough to provide roomy capacity for your meals, beers, snacks or other food, can hold up to 28 cans</span></li>\n 	<li><span class="a-list-item">INSULATED COOLER: High-Density insulation material, THICK liner inside of the insulated backpacks work to make sure to keep food hot/cold for hours</span></li>\n 	<li><span class="a-list-item">DURABLE and WATER RESISTANT: Made of leak resistant (Not leakproof. Not suitable for containing bulk ice cubes inside, unless kept in a special container), durable fabric, lightweight backpack with cooler for lunches, picnics, road/ beach trips, hiking, camping, fishing, perfect gift for boys girls men and women</span></li>\n 	<li><span class="a-list-item">MULTIPLE POCKETS: 1 main roomy storage compartment, 2 side mesh pockets, 1 large front zipper pocket with mesh divider; Dimension: 17.9" x 13.2" x 7.7" (L x W x H), Weight: 1.25 pounds / 650g, about 30L, own enough space for all you belongings</span></li>\n</ul>', 'Magnetic Baby Safety Locks', '<span class="a-list-item">LARGE LUNCH COOLER BACKPACK</span>', 'inherit', 'closed', 'closed', '', '137-autosave-v1', '', '', '2019-02-06 15:17:36', '2019-02-06 15:17:36', '', 137, 'http://therapia.test/137-autosave-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wpth_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(143, 1, '2019-02-06 15:19:00', '2019-02-06 15:19:00', '', 'product-image', '', 'inherit', 'open', 'closed', '', '91mzea6e-el-_sx679_', '', '', '2019-02-06 15:19:06', '2019-02-06 15:19:06', '', 141, 'http://therapia.test/wp-content/uploads/2019/02/91MzEa6e-eL._SX679_.jpg', 0, 'attachment', 'image/jpeg', 0),
(144, 1, '2019-02-06 15:20:37', '2019-02-06 15:20:37', 'Variety of Cutting With Switchable Blades – The best spiralizer vegetable slicer is here for all your needs. Make flat cut or choose from various blades between 2mm and 5.5mm for your various cutting, slicing and spiralizing needs. Strong Suction Pad With Hand Cranking – Say goodbye to inconvenience with this premium quality kitchen accessory that lets you do your work with ease. No need to look for a power outlet, simply place our spiral vegetable cutter on any flat surface, lock the suction pad and let the work begin. Small And Compact Size – Measuring only 10.2 x 5 x 7.7 inches and with built-in space for storing all of the blades, this spiralizer is small and handy yet strong and sturdy at the same time. It is easy to wash, clean and store without any issue. NON-TOXIC Food Grade Material – Stop worrying about your health as this vegetable spiralizer is made completely from non-toxic food grade material including food-grade plastic and stainless-steel blades. INCLUDES FREE KNIFE AND PEELER – We have included a free ceramic knife and ceramic peeler so that you can easily cut or peel or prepare your vegetable and fruits in any way you like before using the veggie spiral', '5 Blade Spiralizer', 'Variety of Cutting With Switchable Blades – The best spiralizer vegetable slicer is here for all your needs.', 'publish', 'open', 'closed', '', '5-blade-spiralizer', '', '', '2019-02-07 15:17:40', '2019-02-07 15:17:40', '', 0, 'http://therapia.test/?post_type=product&#038;p=144', 0, 'product', '', 0),
(145, 1, '2019-02-06 15:20:31', '2019-02-06 15:20:31', '', 'product-image', '', 'inherit', 'open', 'closed', '', '51q3eafrql', '', '', '2019-02-06 15:20:35', '2019-02-06 15:20:35', '', 144, 'http://therapia.test/wp-content/uploads/2019/02/51Q3EafrqL.jpg', 0, 'attachment', 'image/jpeg', 0),
(147, 1, '2019-02-06 15:27:01', '2019-02-06 15:27:01', 'HAPPY FAMILY LEASURE Magnetic blocks building set for kids provides hours of creative playing with your kids. Reduce your kids’ addiction from mobile gadgets Intelligence Development More Than Fun For Kids：With power megnetic tiles and vibrant crystalic rainbow colors, our magnetic buliding blocks can easy connect to DIY building models as children like. Enjoy endless fun, bust imagination and build dreams with our Magnetic tiles for boys and girls Fits 3 years old and older kids, a best way for them to explore the world of geometry and architecture Various Models Its powerful magnetic components are very easy to assemble.\r\n\r\nIt can combine various models, Total 68 Pieces: with 2 Cars wheels, 24 squares, 28 triangles, 8 long triangle, 4 diamonds, 2 trapezoid . An idea booklet included for your easy reference to build various kinds of models Safe and Durable 3D build toys\' blocks are made of high quality ABS plastic and meet the American toy safety standards. Make it safe to DIY for child with smooth hand-feeling. Integrates Compatible with other similar-size magnetic tiles. Would be great add for those you already have.', '3D Building Block Preschool', '<ul>\r\n 	<li><span class="a-list-item">HAPPY FAMILY LEASURE Magnetic blocks building set for kids provides hours of creative playing with your kids. Reduce your kids’ addiction from mobile gadgets</span></li>\r\n</ul>', 'publish', 'open', 'closed', '', '3d-building-block-preschool', '', '', '2019-02-07 15:16:55', '2019-02-07 15:16:55', '', 0, 'http://therapia.test/?post_type=product&#038;p=147', 0, 'product', '', 0),
(148, 1, '2019-02-06 15:26:08', '2019-02-06 15:26:08', '', 'product-image', '', 'inherit', 'open', 'closed', '', '61zyyllinql-_sx425_', '', '', '2019-02-06 15:26:12', '2019-02-06 15:26:12', '', 147, 'http://therapia.test/wp-content/uploads/2019/02/61ZYyllInqL._SX425_.jpg', 0, 'attachment', 'image/jpeg', 0),
(149, 1, '2019-02-06 15:32:01', '2019-02-06 15:32:01', '', 'product-image', '', 'inherit', 'open', 'closed', '', '71dezv4ful-_sx679_', '', '', '2019-02-06 15:32:06', '2019-02-06 15:32:06', '', 137, 'http://therapia.test/wp-content/uploads/2019/02/71DezV4FUL._SX679_.jpg', 0, 'attachment', 'image/jpeg', 0),
(150, 1, '2019-02-06 15:33:53', '2019-02-06 15:33:53', '', '3D Building Block Preschool', '', 'publish', 'closed', 'closed', '', '3d-building-block-preschool', '', '', '2019-02-06 15:35:23', '2019-02-06 15:35:23', '', 147, 'http://therapia.test/product/toys-games/3d-building-block-preschool/', 2, 'product_variation', '', 0),
(151, 1, '2019-02-06 15:35:13', '2019-02-06 15:35:13', '', '3D Building Block Preschool', '', 'publish', 'closed', 'closed', '', '3d-building-block-preschool-2', '', '', '2019-02-06 15:36:04', '2019-02-06 15:36:04', '', 147, 'http://therapia.test/product/toys-games/3d-building-block-preschool/', 2, 'product_variation', '', 0),
(152, 1, '2019-02-06 15:35:27', '2019-02-06 15:35:27', '', '3D Building Block Preschool', '', 'publish', 'closed', 'closed', '', '3d-building-block-preschool-3', '', '', '2019-02-06 15:35:39', '2019-02-06 15:35:39', '', 147, 'http://therapia.test/product/toys-games/3d-building-block-preschool/', 1, 'product_variation', '', 0),
(153, 1, '2019-02-06 15:40:22', '2019-02-06 15:40:22', 'AlpenBock Unique Design - Enjoy our special design jacket\'s for girls Special Mateiral - AlpenBock jackets are designed from special down alternative, just the right choice for your child Choose The Best For Your Child - from all our special designs, and various of colors and sizes', 'AlpenBock Girl\'s Puffed Jacket', 'AlpenBock Unique Design - Enjoy our special design jacket\'s for girls Special Mateiral', 'publish', 'open', 'closed', '', 'alpenbock-girls-puffed-jacket', '', '', '2019-02-07 16:47:09', '2019-02-07 16:47:09', '', 0, 'http://therapia.test/?post_type=product&#038;p=153', 0, 'product', '', 0),
(154, 1, '2019-02-06 15:36:59', '2019-02-06 15:36:59', '', 'product-image', '', 'inherit', 'open', 'closed', '', '91bpgdtk5bl-_uy741_', '', '', '2019-02-06 15:37:05', '2019-02-06 15:37:05', '', 153, 'http://therapia.test/wp-content/uploads/2019/02/91bPGDtk5BL._UY741_.jpg', 0, 'attachment', 'image/jpeg', 0),
(161, 1, '2019-02-06 16:15:44', '2019-02-06 16:15:44', ' ', '', '', 'publish', 'closed', 'closed', '', '161', '', '', '2019-02-20 10:09:19', '2019-02-20 10:09:19', '', 0, 'http://therapia.test/?p=161', 4, 'nav_menu_item', '', 0),
(162, 1, '2019-02-06 16:15:44', '2019-02-06 16:15:44', '', 'Sports & Outdoors', '', 'publish', 'closed', 'closed', '', 'sports-outdoors', '', '', '2019-02-20 10:09:19', '2019-02-20 10:09:19', '', 0, 'http://therapia.test/?p=162', 5, 'nav_menu_item', '', 0),
(163, 1, '2019-02-06 16:15:44', '2019-02-06 16:15:44', '', 'Home & Kitchen', '', 'publish', 'closed', 'closed', '', 'home-kitchen', '', '', '2019-02-20 10:09:19', '2019-02-20 10:09:19', '', 0, 'http://therapia.test/?p=163', 6, 'nav_menu_item', '', 0),
(164, 1, '2019-02-06 16:15:44', '2019-02-06 16:15:44', '', 'Toys & Games', '', 'publish', 'closed', 'closed', '', 'toys-games', '', '', '2019-02-20 10:09:19', '2019-02-20 10:09:19', '', 0, 'http://therapia.test/?p=164', 7, 'nav_menu_item', '', 0),
(165, 1, '2019-02-06 16:15:44', '2019-02-06 16:15:44', '', 'Shoes & Jewelry', '', 'publish', 'closed', 'closed', '', 'shoes-jewelry', '', '', '2019-02-20 10:09:19', '2019-02-20 10:09:19', '', 0, 'http://therapia.test/?p=165', 8, 'nav_menu_item', '', 0),
(167, 1, '2019-02-07 15:12:37', '2019-02-07 15:12:37', 'AlpenBock Unique Design - Enjoy our special design jacket\'s for girls Special Mateiral - AlpenBock jackets are designed from special down alternative, just the right choice for your child Choose The Best For Your Child - from all our special designs, and various of colors and sizes', 'AlpenBock Girl\'s Puffed Jacket', 'AlpenBock Unique Design - Enjoy our special design jacket\'s for girls Special Mateiral', 'inherit', 'closed', 'closed', '', '153-autosave-v1', '', '', '2019-02-07 15:12:37', '2019-02-07 15:12:37', '', 153, 'http://therapia.test/153-autosave-v1/', 0, 'revision', '', 0),
(172, 1, '2019-02-07 15:13:17', '2019-02-07 15:13:17', '', 'AlpenBock Girl\'s Puffed Jacket', '', 'publish', 'closed', 'closed', '', 'alpenbock-girls-puffed-jacket-5', '', '', '2019-02-07 16:42:06', '2019-02-07 16:42:06', '', 153, 'http://therapia.test/product/shoes-jewelry/alpenbock-girls-puffed-jacket/', 1, 'product_variation', '', 0),
(173, 1, '2019-02-07 15:13:17', '2019-02-07 15:13:17', '', 'AlpenBock Girl\'s Puffed Jacket', '', 'publish', 'closed', 'closed', '', 'alpenbock-girls-puffed-jacket-6', '', '', '2019-02-07 15:14:45', '2019-02-07 15:14:45', '', 153, 'http://therapia.test/product/shoes-jewelry/alpenbock-girls-puffed-jacket/', 2, 'product_variation', '', 0),
(176, 1, '2019-02-07 15:13:17', '2019-02-07 15:13:17', '', 'AlpenBock Girl\'s Puffed Jacket', '', 'publish', 'closed', 'closed', '', 'alpenbock-girls-puffed-jacket-9', '', '', '2019-02-07 15:14:45', '2019-02-07 15:14:45', '', 153, 'http://therapia.test/product/shoes-jewelry/alpenbock-girls-puffed-jacket/', 3, 'product_variation', '', 0),
(177, 1, '2019-02-07 15:13:17', '2019-02-07 15:13:17', '', 'AlpenBock Girl\'s Puffed Jacket', '', 'publish', 'closed', 'closed', '', 'alpenbock-girls-puffed-jacket-10', '', '', '2019-02-07 16:40:52', '2019-02-07 16:40:52', '', 153, 'http://therapia.test/product/shoes-jewelry/alpenbock-girls-puffed-jacket/', 4, 'product_variation', '', 0),
(180, 1, '2019-02-07 15:16:50', '2019-02-07 15:16:50', 'HAPPY FAMILY LEASURE Magnetic blocks building set for kids provides hours of creative playing with your kids. Reduce your kids’ addiction from mobile gadgets Intelligence Development More Than Fun For Kids：With power megnetic tiles and vibrant crystalic rainbow colors, our magnetic buliding blocks can easy connect to DIY building models as children like. Enjoy endless fun, bust imagination and build dreams with our Magnetic tiles for boys and girls Fits 3 years old and older kids, a best way for them to explore the world of geometry and architecture Various Models Its powerful magnetic components are very easy to assemble.\n\nIt can combine various models, Total 68 Pieces: with 2 Cars wheels, 24 squares, 28 triangles, 8 long triangle, 4 diamonds, 2 trapezoid . An idea booklet included for your easy reference to build various kinds of models Safe and Durable 3D build toys\' blocks are made of high quality ABS plastic and meet the American toy safety standards. Make it safe to DIY for child with smooth hand-feeling. Integrates Compatible with other similar-size magnetic tiles. Would be great add for those you already have.', '3D Building Block Preschool', '<ul>\n 	<li><span class="a-list-item">HAPPY FAMILY LEASURE Magnetic blocks building set for kids provides hours of creative playing with your kids. Reduce your kids’ addiction from mobile gadgets</span></li>\n</ul>', 'inherit', 'closed', 'closed', '', '147-autosave-v1', '', '', '2019-02-07 15:16:50', '2019-02-07 15:16:50', '', 147, 'http://therapia.test/147-autosave-v1/', 0, 'revision', '', 0),
(185, 1, '2019-02-18 15:36:57', '2019-02-18 15:36:57', '', 'Home', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-02-18 15:36:57', '2019-02-18 15:36:57', '', 19, 'http://therapia.test/19-revision-v1/', 0, 'revision', '', 0),
(189, 1, '2019-02-20 10:20:03', '2019-02-20 10:20:03', '', 'empty-image', '', 'inherit', 'open', 'closed', '', 'placeholder', '', '', '2019-02-20 10:20:29', '2019-02-20 10:20:29', '', 0, 'http://therapia.test/wp-content/uploads/2019/02/placeholder.jpg', 0, 'attachment', 'image/jpeg', 0),
(190, 1, '2019-08-16 15:35:34', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-08-16 15:35:34', '0000-00-00 00:00:00', '', 0, 'http://therapia.test/?p=190', 0, 'post', '', 0) ;

#
# End of data contents of table `wpth_posts`
# --------------------------------------------------------



#
# Delete any existing table `wpth_queue`
#

DROP TABLE IF EXISTS `wpth_queue`;


#
# Table structure of table `wpth_queue`
#

CREATE TABLE `wpth_queue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `job` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attempts` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `locked_at` datetime DEFAULT NULL,
  `available_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_queue`
#

#
# End of data contents of table `wpth_queue`
# --------------------------------------------------------



#
# Delete any existing table `wpth_term_relationships`
#

DROP TABLE IF EXISTS `wpth_term_relationships`;


#
# Table structure of table `wpth_term_relationships`
#

CREATE TABLE `wpth_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_term_relationships`
#
INSERT INTO `wpth_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(12, 4, 0),
(12, 8, 0),
(12, 16, 0),
(12, 17, 0),
(12, 19, 0),
(12, 20, 0),
(12, 23, 0),
(12, 25, 0),
(16, 18, 0),
(17, 18, 0),
(39, 2, 0),
(39, 8, 0),
(39, 16, 0),
(50, 2, 0),
(50, 8, 0),
(50, 16, 0),
(51, 2, 0),
(51, 8, 0),
(51, 16, 0),
(78, 2, 0),
(78, 16, 0),
(80, 2, 0),
(80, 16, 0),
(81, 2, 0),
(81, 16, 0),
(82, 2, 0),
(82, 16, 0),
(115, 18, 0),
(135, 2, 0),
(135, 26, 0),
(135, 27, 0),
(137, 4, 0),
(137, 19, 0),
(137, 20, 0),
(137, 28, 0),
(141, 2, 0),
(141, 13, 0),
(141, 26, 0),
(144, 2, 0),
(144, 29, 0),
(147, 4, 0),
(147, 19, 0),
(147, 20, 0),
(147, 30, 0),
(147, 31, 0),
(153, 4, 0),
(153, 19, 0),
(153, 23, 0),
(153, 25, 0),
(153, 30, 0),
(153, 33, 0),
(153, 34, 0),
(153, 35, 0),
(161, 18, 0),
(162, 18, 0),
(163, 18, 0),
(164, 18, 0),
(165, 18, 0) ;

#
# End of data contents of table `wpth_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wpth_term_taxonomy`
#

DROP TABLE IF EXISTS `wpth_term_taxonomy`;


#
# Table structure of table `wpth_term_taxonomy`
#

CREATE TABLE `wpth_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_term_taxonomy`
#
INSERT INTO `wpth_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 10),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 4),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 4),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 1),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 0),
(16, 16, 'product_cat', '', 0, 8),
(17, 17, 'product_tag', '', 0, 1),
(18, 18, 'nav_menu', '', 0, 8),
(19, 19, 'pa_color', '', 0, 4),
(20, 20, 'pa_color', '', 0, 3),
(23, 23, 'pa_size', '', 0, 2),
(25, 25, 'pa_size', '', 0, 2),
(26, 26, 'product_cat', '', 0, 2),
(27, 27, 'product_tag', '', 0, 1),
(28, 28, 'product_cat', '', 0, 1),
(29, 29, 'product_cat', '', 0, 1),
(30, 30, 'pa_color', '', 0, 2),
(31, 31, 'product_cat', '', 0, 1),
(32, 32, 'product_cat', '', 0, 0),
(33, 33, 'product_cat', '', 0, 1),
(34, 34, 'pa_size', '', 0, 1),
(35, 35, 'pa_size', '', 0, 1) ;

#
# End of data contents of table `wpth_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wpth_termmeta`
#

DROP TABLE IF EXISTS `wpth_termmeta`;


#
# Table structure of table `wpth_termmeta`
#

CREATE TABLE `wpth_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_termmeta`
#
INSERT INTO `wpth_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 16, 'order', '0'),
(2, 16, 'product_count_product_cat', '8'),
(3, 17, 'product_count_product_tag', '1'),
(4, 15, 'product_count_product_cat', '0'),
(5, 19, 'order_pa_color', '0'),
(6, 20, 'order_pa_color', '0'),
(9, 23, 'order_pa_size', '0'),
(11, 25, 'order_pa_size', '0'),
(12, 16, 'display_type', ''),
(13, 16, 'thumbnail_id', '77'),
(14, 26, 'order', '0'),
(15, 26, 'product_count_product_cat', '2'),
(16, 27, 'product_count_product_tag', '1'),
(17, 28, 'order', '0'),
(18, 28, 'product_count_product_cat', '1'),
(19, 29, 'order', '0'),
(20, 29, 'product_count_product_cat', '1'),
(21, 30, 'order_pa_color', '0'),
(22, 31, 'order', '0'),
(23, 31, 'product_count_product_cat', '1'),
(24, 32, 'order', '0'),
(25, 33, 'order', '0'),
(26, 34, 'order_pa_size', '0'),
(27, 35, 'order_pa_size', '0'),
(28, 33, 'product_count_product_cat', '1') ;

#
# End of data contents of table `wpth_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wpth_terms`
#

DROP TABLE IF EXISTS `wpth_terms`;


#
# Table structure of table `wpth_terms`
#

CREATE TABLE `wpth_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_terms`
#
INSERT INTO `wpth_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Uncategorized', 'uncategorized', 0),
(16, 'Vaxholm', 'vaxholm', 0),
(17, 'Vaxholm', 'vaxholm', 0),
(18, 'Main-menu', 'main-menu', 0),
(19, 'White', 'white', 0),
(20, 'Black', 'black', 0),
(23, '30x30', '30x30', 0),
(25, '40x40', '40x40', 0),
(26, 'Baby Products', 'baby-products', 0),
(27, 'Baby Products', 'baby-products', 0),
(28, 'Sports &amp; Outdoors', 'sports-outdoors', 0),
(29, 'Home &amp; Kitchen', 'home-kitchen', 0),
(30, 'Grey', 'grey', 0),
(31, 'Toys &amp; Games', 'toys-games', 0),
(32, 'Clothing', 'clothing', 0),
(33, 'Shoes &amp; Jewelry', 'shoes-jewelry', 0),
(34, 'M', 'm', 0),
(35, 'XL', 'xl', 0) ;

#
# End of data contents of table `wpth_terms`
# --------------------------------------------------------



#
# Delete any existing table `wpth_usermeta`
#

DROP TABLE IF EXISTS `wpth_usermeta`;


#
# Table structure of table `wpth_usermeta`
#

CREATE TABLE `wpth_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_usermeta`
#
INSERT INTO `wpth_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin1020'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wpth_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wpth_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wpth_dashboard_quick_press_last_post_id', '190'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:12:"178.216.16.0";}'),
(19, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:"cart";a:6:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";a:11:{s:3:"key";s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";s:10:"product_id";i:50;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:67;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:6030;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:6030;s:8:"line_tax";i:0;}s:32:"2838023a778dfaecdc212708f721b788";a:11:{s:3:"key";s:32:"2838023a778dfaecdc212708f721b788";s:10:"product_id";i:51;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:11;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:990;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:990;s:8:"line_tax";i:0;}s:32:"a99d1a2acdc4a76d1614f55522d24cab";a:11:{s:3:"key";s:32:"a99d1a2acdc4a76d1614f55522d24cab";s:10:"product_id";i:153;s:12:"variation_id";i:172;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:4:"grey";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:21;s:9:"data_hash";s:32:"66e2d6018deccd2a7d21095d00b8490d";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:2730;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:2730;s:8:"line_tax";i:0;}s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";a:11:{s:3:"key";s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";s:10:"product_id";i:137;s:12:"variation_id";i:139;s:9:"variation";a:1:{s:18:"attribute_pa_color";s:5:"black";}s:8:"quantity";i:3;s:9:"data_hash";s:32:"8ebe40e554c18ebfc44954a0df960f82";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:300;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:300;s:8:"line_tax";i:0;}s:32:"0f28b5d49b3020afeecd95b4009adf4c";a:11:{s:3:"key";s:32:"0f28b5d49b3020afeecd95b4009adf4c";s:10:"product_id";i:141;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:2;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:38;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:38;s:8:"line_tax";i:0;}}}'),
(20, 1, 'wc_last_active', '1565913600'),
(21, 1, 'jetpack_tracks_anon_id', 'jetpack:klkT9Db2yVtb+hZQDPMeu7jp'),
(22, 1, 'wpth_user-settings', 'libraryContent=browse&editor=tinymce'),
(23, 1, 'wpth_user-settings-time', '1553510708'),
(25, 1, 'nav_menu_recently_edited', '18'),
(26, 1, 'managenav-menuscolumnshidden', 'a:3:{i:0;s:15:"title-attribute";i:1;s:3:"xfn";i:2;s:11:"description";}'),
(27, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:26:"add-post-type-testimonials";i:1;s:18:"add-post-type-logo";i:2;s:12:"add-post_tag";i:3;s:15:"add-product_tag";}'),
(28, 1, 'closedpostboxes_acf-field-group', 'a:0:{}'),
(29, 1, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:"slugdiv";}'),
(30, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:203:"acf-group_5c24fb9c5a068,acf-group_5c29f80547b5f,acf-group_5c23a718d91c9,acf-group_5c29e375c9d32,acf-group_5c29f955abde1,acf-group_5c23a77c971f1,revisionsdiv,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(31, 1, 'screen_layout_page', '2'),
(32, 1, 'closedpostboxes_product', 'a:0:{}'),
(33, 1, 'metaboxhidden_product', 'a:11:{i:0;s:23:"acf-group_5c2e1cd48316f";i:1;s:23:"acf-group_5c2cc82b0ca82";i:2;s:23:"acf-group_5c2cafd08a002";i:3;s:23:"acf-group_5c23a718d91c9";i:4;s:23:"acf-group_5c2cbd6d00ddc";i:5;s:23:"acf-group_5c29e375c9d32";i:6;s:23:"acf-group_5c24fb9c5a068";i:7;s:23:"acf-group_5c29f955abde1";i:8;s:23:"acf-group_5c29f80547b5f";i:9;s:23:"acf-group_5c23a77c971f1";i:10;s:7:"slugdiv";}'),
(34, 1, 'meta-box-order_toplevel_page_acf-options', 'a:2:{s:4:"side";s:9:"submitdiv";s:6:"normal";s:95:"acf-group_5c23a718d91c9,acf-group_5c23a77c971f1,acf-group_5c2cafd08a002,acf-group_5c2cbd6d00ddc";}'),
(35, 1, 'screen_layout_toplevel_page_acf-options', '2'),
(36, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(37, 1, 'closedpostboxes_toplevel_page_acf-options', 'a:0:{}'),
(38, 1, 'metaboxhidden_toplevel_page_acf-options', 'a:0:{}'),
(44, 1, 'dismissed_no_secure_connection_notice', '1'),
(46, 1, 'wpmdb_dismiss_muplugin_failed_update_1.2', '1'),
(47, 1, 'session_tokens', 'a:1:{s:64:"23c2f974e1ad24887eb15e4bdd74359ce6b4829f8f2f8e03334a39e9354ec8f9";a:4:{s:10:"expiration";i:1566142532;s:2:"ip";s:13:"178.216.16.10";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36";s:5:"login";i:1565969732;}}') ;

#
# End of data contents of table `wpth_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wpth_users`
#

DROP TABLE IF EXISTS `wpth_users`;


#
# Table structure of table `wpth_users`
#

CREATE TABLE `wpth_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_users`
#
INSERT INTO `wpth_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin1020', '$P$BwYhGl4yl/BlCtPHuY1AtEiZJA4Cfo1', 'admin1020', 'wp.test.mail.for.me@gmail.com', '', '2018-12-26 13:33:34', '', 0, 'admin1020') ;

#
# End of data contents of table `wpth_users`
# --------------------------------------------------------



#
# Delete any existing table `wpth_wc_download_log`
#

DROP TABLE IF EXISTS `wpth_wc_download_log`;


#
# Table structure of table `wpth_wc_download_log`
#

CREATE TABLE `wpth_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_wc_download_log`
#

#
# End of data contents of table `wpth_wc_download_log`
# --------------------------------------------------------



#
# Delete any existing table `wpth_wc_webhooks`
#

DROP TABLE IF EXISTS `wpth_wc_webhooks`;


#
# Table structure of table `wpth_wc_webhooks`
#

CREATE TABLE `wpth_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_wc_webhooks`
#

#
# End of data contents of table `wpth_wc_webhooks`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wpth_woocommerce_api_keys`;


#
# Table structure of table `wpth_woocommerce_api_keys`
#

CREATE TABLE `wpth_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_api_keys`
#

#
# End of data contents of table `wpth_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wpth_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wpth_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wpth_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_attribute_taxonomies`
#
INSERT INTO `wpth_woocommerce_attribute_taxonomies` ( `attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES
(1, 'color', 'Color', 'select', 'menu_order', 0),
(2, 'size', 'Size', 'select', 'menu_order', 0) ;

#
# End of data contents of table `wpth_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wpth_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wpth_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wpth_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `wpth_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_log`
#

DROP TABLE IF EXISTS `wpth_woocommerce_log`;


#
# Table structure of table `wpth_woocommerce_log`
#

CREATE TABLE `wpth_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_log`
#

#
# End of data contents of table `wpth_woocommerce_log`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wpth_woocommerce_order_itemmeta`;


#
# Table structure of table `wpth_woocommerce_order_itemmeta`
#

CREATE TABLE `wpth_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_order_itemmeta`
#

#
# End of data contents of table `wpth_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wpth_woocommerce_order_items`;


#
# Table structure of table `wpth_woocommerce_order_items`
#

CREATE TABLE `wpth_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_order_items`
#

#
# End of data contents of table `wpth_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `wpth_woocommerce_payment_tokenmeta`;


#
# Table structure of table `wpth_woocommerce_payment_tokenmeta`
#

CREATE TABLE `wpth_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_payment_tokenmeta`
#

#
# End of data contents of table `wpth_woocommerce_payment_tokenmeta`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `wpth_woocommerce_payment_tokens`;


#
# Table structure of table `wpth_woocommerce_payment_tokens`
#

CREATE TABLE `wpth_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_payment_tokens`
#

#
# End of data contents of table `wpth_woocommerce_payment_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wpth_woocommerce_sessions`;


#
# Table structure of table `wpth_woocommerce_sessions`
#

CREATE TABLE `wpth_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=282 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_sessions`
#
INSERT INTO `wpth_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(1, 'e97e8a82d2da9c094deed037fe60736e', 'a:14:{s:4:"cart";s:1301:"a:3:{s:32:"9778d5d219c5080b9a6a17bef029331c";a:11:{s:3:"key";s:32:"9778d5d219c5080b9a6a17bef029331c";s:10:"product_id";i:82;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:270;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:270;s:8:"line_tax";i:0;}s:32:"d67d8ab4f4c10bf22aa353e27879133c";a:11:{s:3:"key";s:32:"d67d8ab4f4c10bf22aa353e27879133c";s:10:"product_id";i:39;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:2;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:180;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:180;s:8:"line_tax";i:0;}s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:2;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:180;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:180;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"630";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"630";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"680";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:2597:"a:6:{s:32:"2838023a778dfaecdc212708f721b788";a:11:{s:3:"key";s:32:"2838023a778dfaecdc212708f721b788";s:10:"product_id";i:51;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:4;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:360;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:360;s:8:"line_tax";i:0;}s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";a:11:{s:3:"key";s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";s:10:"product_id";i:50;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:270;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:270;s:8:"line_tax";i:0;}s:32:"d67d8ab4f4c10bf22aa353e27879133c";a:11:{s:3:"key";s:32:"d67d8ab4f4c10bf22aa353e27879133c";s:10:"product_id";i:39;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:12;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:1080;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:1080;s:8:"line_tax";i:0;}s:32:"8e933e49567a998703409401bae55f7c";a:11:{s:3:"key";s:32:"8e933e49567a998703409401bae55f7c";s:10:"product_id";i:12;s:12:"variation_id";i:128;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"40x40";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"eb9915d1454d3d14b6311ddd4d055414";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:100;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:100;s:8:"line_tax";i:0;}s:32:"9778d5d219c5080b9a6a17bef029331c";a:11:{s:3:"key";s:32:"9778d5d219c5080b9a6a17bef029331c";s:10:"product_id";i:82;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:7;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:630;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:630;s:8:"line_tax";i:0;}}";s:22:"shipping_for_package_0";s:434:"a:2:{s:12:"package_hash";s:40:"wc_ship_2c2695af4c6e5d4340dbd0c94896f184";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:80:"Vaxholm White &times; 3, Vaxholm White &times; 2, Vaxholm White (test) &times; 2";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:21:"chosen_payment_method";s:0:"";s:22:"mailchimp_landing_site";s:26:"http://therapia.test/cart/";}', 1548490088),
(3, '1c548aa64e99da282f71ea17079d473d', 'a:13:{s:4:"cart";s:891:"a:2:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";a:11:{s:3:"key";s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";s:10:"product_id";i:50;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"180";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"180";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"230";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"TR";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"TR";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:409:"a:2:{s:12:"package_hash";s:40:"wc_ship_f26b11b014cf0d355489d1e1efbb5f39";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:55:"Vaxholm White (test) &times; 1, Vaxholm White &times; 1";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:0:"";}', 1549026531),
(28, 'ea703e58e4d99da2b8f607222c56f84b', 'a:8:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:66:"http://therapia.test/wp-content/uploads/2018/12/product-img-1.png;";}', 1548952486),
(29, 'bebfe1fb81e85460908ee0ec4055bd7f', 'a:12:{s:4:"cart";s:895:"a:2:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:2;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:180;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:180;s:8:"line_tax";i:0;}s:32:"d67d8ab4f4c10bf22aa353e27879133c";a:11:{s:3:"key";s:32:"d67d8ab4f4c10bf22aa353e27879133c";s:10:"product_id";i:39;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:270;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:270;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"450";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"450";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"500";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:814:"a:2:{s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";a:11:{s:3:"key";s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";s:10:"product_id";i:50;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"d67d8ab4f4c10bf22aa353e27879133c";a:11:{s:3:"key";s:32:"d67d8ab4f4c10bf22aa353e27879133c";s:10:"product_id";i:39;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:409:"a:2:{s:12:"package_hash";s:40:"wc_ship_eafe89ccdada907023df47de821dd768";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:55:"Vaxholm White (test) &times; 2, Vaxholm White &times; 3";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;}', 1549109632),
(35, 'ff9b8b1abce99b2d3a163c74952fc640', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1549188021),
(36, 'bd24757f8e610ff901113cc5a7b049e7', 'a:8:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:26:"http://therapia.test/shop/";}', 1549210818),
(37, '5ff2627429ca96c92f5ff4a016d7867b', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1549210818),
(38, '8c9bc967018f78a58687aef38d2cb88e', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1549446147),
(39, '72175d6eef8436944f4a7e57e71d9423', 'a:14:{s:4:"cart";s:1704:"a:4:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";a:11:{s:3:"key";s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";s:10:"product_id";i:50;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"d67d8ab4f4c10bf22aa353e27879133c";a:11:{s:3:"key";s:32:"d67d8ab4f4c10bf22aa353e27879133c";s:10:"product_id";i:39;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"2838023a778dfaecdc212708f721b788";a:11:{s:3:"key";s:32:"2838023a778dfaecdc212708f721b788";s:10:"product_id";i:51;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:13;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:1170;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:1170;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:397:"a:15:{s:8:"subtotal";s:4:"1440";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:4:"1440";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:4:"1490";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:68:"http://therapia.test/wp-content/uploads/2018/12/product-image-4.jpg;";s:22:"shipping_for_package_0";s:470:"a:2:{s:12:"package_hash";s:40:"wc_ship_0f55dcf040fe22904342527866992c09";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:115:"Vaxholm White (test) &times; 1, Vaxholm White &times; 1, Vaxholm White &times; 1, Vaxholm White (test 2) &times; 13";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:0:"";}', 1549787571),
(42, 'c6c49213d38365879ceff344c98d8b5c', 'a:12:{s:4:"cart";s:487:"a:1:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:392:"a:15:{s:8:"subtotal";s:2:"90";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:2:"90";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"140";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:717:"a:26:{s:2:"id";s:1:"1";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:33:"http://therapia.test/wp-login.php";s:22:"shipping_for_package_0";s:384:"a:2:{s:12:"package_hash";s:40:"wc_ship_bfd0bbcd2e23539f847a0a379c776313";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:30:"Vaxholm White (test) &times; 1";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";}', 1549450313),
(43, '644511d72b4a404dc021c9c0d17a9e55', 'a:13:{s:4:"cart";s:487:"a:1:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:392:"a:15:{s:8:"subtotal";s:2:"90";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:2:"90";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"140";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:10:"wc_notices";N;s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:384:"a:2:{s:12:"package_hash";s:40:"wc_ship_f4943730048684d19c070da2a862b95e";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:30:"Vaxholm White (test) &times; 1";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:21:"chosen_payment_method";s:0:"";}', 1549617704),
(44, 'b25533513a137f973293c7aa34d35a17', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1550219831),
(45, 'b0ab84af0246d0256b4137b3e466a846', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1550650321),
(46, '724b96242b43133cee0586560bcabd26', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1550650518),
(47, '1', 'a:1:{s:8:"customer";s:717:"a:26:{s:2:"id";s:1:"1";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1563265071),
(118, 'bc36d3724467ff4f9a180485326481d1', 'a:8:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:53:"http://therapia.test/?wc-ajax=get_refreshed_fragments";}', 1550658211),
(122, 'a7c13bc358e91e3395ef54852ce76588', 'a:8:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:72:"http://therapia.test/wp-content/uploads/2019/02/91Tw-ntzrAL._SX522_.jpg;";}', 1550670815),
(125, '96c08f99a062899b8d076b1d5aa07a41', 'a:14:{s:4:"cart";s:2641:"a:6:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";a:11:{s:3:"key";s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";s:10:"product_id";i:50;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:67;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:6030;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:6030;s:8:"line_tax";i:0;}s:32:"2838023a778dfaecdc212708f721b788";a:11:{s:3:"key";s:32:"2838023a778dfaecdc212708f721b788";s:10:"product_id";i:51;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:11;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:990;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:990;s:8:"line_tax";i:0;}s:32:"a99d1a2acdc4a76d1614f55522d24cab";a:11:{s:3:"key";s:32:"a99d1a2acdc4a76d1614f55522d24cab";s:10:"product_id";i:153;s:12:"variation_id";i:172;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:4:"grey";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:21;s:9:"data_hash";s:32:"66e2d6018deccd2a7d21095d00b8490d";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:2730;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:2730;s:8:"line_tax";i:0;}s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";a:11:{s:3:"key";s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";s:10:"product_id";i:137;s:12:"variation_id";i:139;s:9:"variation";a:1:{s:18:"attribute_pa_color";s:5:"black";}s:8:"quantity";i:3;s:9:"data_hash";s:32:"8ebe40e554c18ebfc44954a0df960f82";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:300;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:300;s:8:"line_tax";i:0;}s:32:"0f28b5d49b3020afeecd95b4009adf4c";a:11:{s:3:"key";s:32:"0f28b5d49b3020afeecd95b4009adf4c";s:10:"product_id";i:141;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:2;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:38;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:38;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:400:"a:15:{s:8:"subtotal";s:5:"10178";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:5:"10178";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:5:"10228";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:717:"a:26:{s:2:"id";s:1:"1";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:44:"http://therapia.test/wp-admin/admin-ajax.php";s:22:"shipping_for_package_0";s:572:"a:2:{s:12:"package_hash";s:40:"wc_ship_d782b96e45fb7fd04c9516d0e4e34c48";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:217:"Vaxholm White (test) &times; 1, Vaxholm White &times; 67, Vaxholm White (test 2) &times; 11, AlpenBock Girl\'s Puffed Jacket &times; 21, Perfect Insulated Cooler Backpack &times; 3, Magnetic Baby Safety Locks &times; 2";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:0:"";}', 1550840038),
(127, 'ba00804df367e81dfb2639e534ad313d', 'a:8:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:71:"http://therapia.test/wp-content/uploads/2019/02/71DezV4FUL._SX679_.jpg;";}', 1550675561),
(128, '7dc7af15d08247aaa36debf4535e403d', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1550822406),
(129, '5f478b42a4590cfdfa1966de7eaadb87', 'a:12:{s:4:"cart";s:895:"a:2:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:4;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:360;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:360;s:8:"line_tax";i:0;}s:32:"2838023a778dfaecdc212708f721b788";a:11:{s:3:"key";s:32:"2838023a778dfaecdc212708f721b788";s:10:"product_id";i:51;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:270;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:270;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"630";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"630";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"680";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:418:"a:2:{s:12:"package_hash";s:40:"wc_ship_4cb68202329c3c37c5a889a3d922e782";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:64:"Vaxholm White (test) &times; 4, Vaxholm White (test 2) &times; 3";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;}', 1550822406) ;
INSERT INTO `wpth_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(130, '5a0ccb580ca88b9990a714bcddd1923a', 'a:13:{s:4:"cart";s:490:"a:1:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:10;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:900;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:900;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"900";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"900";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"950";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:68:"http://therapia.test/wp-content/uploads/2018/12/product-image-4.jpg;";s:22:"shipping_for_package_0";s:385:"a:2:{s:12:"package_hash";s:40:"wc_ship_91ea4be787bc35610f00e6171f3b618d";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:31:"Vaxholm White (test) &times; 10";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;}', 1550823750),
(132, '8ce430a7a7c80b06bb54feafd09ce00e', 'a:8:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:72:"http://therapia.test/wp-content/uploads/2019/02/91Tw-ntzrAL._SX522_.jpg;";}', 1550846568),
(134, '6e1a5f2790f26c4b7a63d2c565941df9', 'a:13:{s:4:"cart";s:489:"a:1:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:3;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:270;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:270;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"270";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"270";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"320";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:53:"http://therapia.test/?wc-ajax=get_refreshed_fragments";s:22:"shipping_for_package_0";s:384:"a:2:{s:12:"package_hash";s:40:"wc_ship_39a1f32b5f0c312e5f7c9261aebaa13a";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:30:"Vaxholm White (test) &times; 3";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;}', 1550914713),
(138, '4848a3cec73bac8dc807aeef73ce550f', 'a:13:{s:4:"cart";s:412:"a:1:{s:32:"2838023a778dfaecdc212708f721b788";a:11:{s:3:"key";s:32:"2838023a778dfaecdc212708f721b788";s:10:"product_id";i:51;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:270;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:270;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"270";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"270";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"320";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:53:"http://therapia.test/?wc-ajax=get_refreshed_fragments";s:22:"shipping_for_package_0";s:386:"a:2:{s:12:"package_hash";s:40:"wc_ship_0fe23b2d85ae17a4088f38dad9b96a5e";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:32:"Vaxholm White (test 2) &times; 3";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;}', 1550914969),
(139, 'd70814d9645436f3c8b02ba230bfd7e4', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1551023491),
(140, '1b9d7c506e1ad915d9bd41a6299410ab', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1551258953),
(141, '21570134f139983fa787369d1400d824', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1551258953),
(143, '125a677de52dcf0f6496db0b492c701c', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1551264334),
(144, '6b15874311370ffd89aaa67bbd395e8e', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1551945632),
(145, '1578059239313e594b239c93659e24ba', 'a:8:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:68:"http://therapia.test/wp-content/uploads/2018/12/product-image-2.jpg;";}', 1551945632),
(148, 'fbdc70e05fcfcaa1257a2b13c58e5784', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1551946508),
(149, 'f82496afa156afc66d100b1c268a71d1', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1551967517),
(150, '695d1959ec2811981502b18a8e88b469', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1552473645),
(151, '53d810fca36ca999639b94b093a81677', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1552473645),
(152, 'ac3b4e77d55a58f2f0530d860a8684a9', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1552655229),
(153, '659573d7c3a44b2820177f1280fb1758', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1552655231),
(154, '1993a67f559043d090c48f9e48a462b6', 'a:13:{s:4:"cart";s:453:"a:1:{s:32:"b892179fa77be5379bf30b966ef1a661";a:11:{s:3:"key";s:32:"b892179fa77be5379bf30b966ef1a661";s:10:"product_id";i:147;s:12:"variation_id";i:151;s:9:"variation";a:1:{s:18:"attribute_pa_color";s:5:"black";}s:8:"quantity";i:6;s:9:"data_hash";s:32:"8ebe40e554c18ebfc44954a0df960f82";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:690;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:690;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"690";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"690";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"740";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:391:"a:2:{s:12:"package_hash";s:40:"wc_ship_36b05f7f4cbc14573970cdfcca8b79c8";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:37:"3D Building Block Preschool &times; 6";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:0:"";}', 1552655229),
(157, '94b217ecef79c351ef9c390549021aa5', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1552836242),
(158, '23413df1551bc4bbb1e85ee321a2f6f3', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1553424825),
(159, '4eaaa93cbcfc05028ba1d71fc9b31c5f', 'a:12:{s:4:"cart";s:2641:"a:6:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";a:11:{s:3:"key";s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";s:10:"product_id";i:50;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:67;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:6030;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:6030;s:8:"line_tax";i:0;}s:32:"2838023a778dfaecdc212708f721b788";a:11:{s:3:"key";s:32:"2838023a778dfaecdc212708f721b788";s:10:"product_id";i:51;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:11;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:990;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:990;s:8:"line_tax";i:0;}s:32:"a99d1a2acdc4a76d1614f55522d24cab";a:11:{s:3:"key";s:32:"a99d1a2acdc4a76d1614f55522d24cab";s:10:"product_id";i:153;s:12:"variation_id";i:172;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:4:"grey";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:21;s:9:"data_hash";s:32:"66e2d6018deccd2a7d21095d00b8490d";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:2730;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:2730;s:8:"line_tax";i:0;}s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";a:11:{s:3:"key";s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";s:10:"product_id";i:137;s:12:"variation_id";i:139;s:9:"variation";a:1:{s:18:"attribute_pa_color";s:5:"black";}s:8:"quantity";i:3;s:9:"data_hash";s:32:"8ebe40e554c18ebfc44954a0df960f82";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:300;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:300;s:8:"line_tax";i:0;}s:32:"0f28b5d49b3020afeecd95b4009adf4c";a:11:{s:3:"key";s:32:"0f28b5d49b3020afeecd95b4009adf4c";s:10:"product_id";i:141;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:2;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:38;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:38;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:400:"a:15:{s:8:"subtotal";s:5:"10178";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:5:"10178";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:5:"10228";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:717:"a:26:{s:2:"id";s:1:"1";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:44:"http://therapia.test/wp-admin/admin-ajax.php";s:22:"shipping_for_package_0";s:572:"a:2:{s:12:"package_hash";s:40:"wc_ship_d782b96e45fb7fd04c9516d0e4e34c48";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:217:"Vaxholm White (test) &times; 1, Vaxholm White &times; 67, Vaxholm White (test 2) &times; 11, AlpenBock Girl\'s Puffed Jacket &times; 21, Perfect Insulated Cooler Backpack &times; 3, Magnetic Baby Safety Locks &times; 2";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";}', 1553424825),
(160, '3547889a7445179e00a967c02adb9230', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1553676774),
(161, '22c45c9de8fefbb2fe07965d53e92506', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1553676774),
(167, '53c93512cf5196d64c14cbfcc416bdb7', 'a:12:{s:4:"cart";s:2641:"a:6:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";a:11:{s:3:"key";s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";s:10:"product_id";i:50;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:67;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:6030;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:6030;s:8:"line_tax";i:0;}s:32:"2838023a778dfaecdc212708f721b788";a:11:{s:3:"key";s:32:"2838023a778dfaecdc212708f721b788";s:10:"product_id";i:51;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:11;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:990;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:990;s:8:"line_tax";i:0;}s:32:"a99d1a2acdc4a76d1614f55522d24cab";a:11:{s:3:"key";s:32:"a99d1a2acdc4a76d1614f55522d24cab";s:10:"product_id";i:153;s:12:"variation_id";i:172;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:4:"grey";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:21;s:9:"data_hash";s:32:"66e2d6018deccd2a7d21095d00b8490d";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:2730;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:2730;s:8:"line_tax";i:0;}s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";a:11:{s:3:"key";s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";s:10:"product_id";i:137;s:12:"variation_id";i:139;s:9:"variation";a:1:{s:18:"attribute_pa_color";s:5:"black";}s:8:"quantity";i:3;s:9:"data_hash";s:32:"8ebe40e554c18ebfc44954a0df960f82";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:300;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:300;s:8:"line_tax";i:0;}s:32:"0f28b5d49b3020afeecd95b4009adf4c";a:11:{s:3:"key";s:32:"0f28b5d49b3020afeecd95b4009adf4c";s:10:"product_id";i:141;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:2;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:38;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:38;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:400:"a:15:{s:8:"subtotal";s:5:"10178";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:5:"10178";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:5:"10228";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:717:"a:26:{s:2:"id";s:1:"1";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"mailchimp_landing_site";s:44:"http://therapia.test/wp-admin/admin-ajax.php";s:22:"shipping_for_package_0";s:572:"a:2:{s:12:"package_hash";s:40:"wc_ship_55f3126117bdcbfc1d0def4325819bd6";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:217:"Vaxholm White (test) &times; 1, Vaxholm White &times; 67, Vaxholm White (test 2) &times; 11, AlpenBock Girl\'s Puffed Jacket &times; 21, Perfect Insulated Cooler Backpack &times; 3, Magnetic Baby Safety Locks &times; 2";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";}', 1553674306),
(169, '7f8a5a1c35ea7a03a62ceb7ea7fad5ac', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1553849006),
(171, '61389e72636be824fcda645f9c60ff1c', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"IL";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"IL";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1553869116),
(172, 'f2785a9c11fbd7f13588b0c5856a7d38', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1553933657),
(173, '0be2bf3f7dc37c41e39c000b95bc0f00', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554299081) ;
INSERT INTO `wpth_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(174, 'b435c5689f11b3a600de2daf7356d500', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554388352),
(175, 'f8352b3880e5ebc1d0d9fccc289c5317', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:691:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:2:"NY";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:2:"NY";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554388376),
(176, '6403e01ef1990ebdb9fa73fe8a54c67b', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554388395),
(177, '9718c83a204f63a4dd256359f3a8739a', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554409273),
(178, 'f9bbfe71cb09c7d92bc34337bb94ce37', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554562287),
(179, '6bb9dd382f0410dfb3084ee3e90d8092', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554562287),
(180, 'bdc8a37b84ff9391b5211e3c988e06ef', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:691:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:2:"NY";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:2:"NY";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554562298),
(181, '0679004b11e932e1196a92a01a84c24b', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554562303),
(182, '1e077945ad579a37235bcdf491c2d3e7', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554562511),
(183, 'ceb20497ec55b750e3c1a071a2f9eb58', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554563235),
(184, '06b165c1a837b98be2c7a099ebe2508d', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554635781),
(185, '83a5a4b7e023e591e9ea2d4e2b55201a', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554879025),
(186, '92a0cda44eb584e12e9594a8251d6eea', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554879340),
(187, '3651229e6982c14a47f53986b6e34087', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554879347),
(188, 'c677992d7a5788d05b960679489a647d', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"AU";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"AU";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554880632),
(189, '636fc493e5c7ecab9afa264ca835f0f9', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1554882486),
(190, 'fc43950969a89eaf94323e9da08d061e', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1555164091),
(191, '376f7ef21dd5eeb1dbbf877cadf39412', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1555055592),
(192, 'dfd4f535a4d5e4714a6f22ace3e82f78', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1555055697),
(193, '4b9f406ba1dc10df66c3d104f8087bcd', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1555057233),
(194, 'a2d4e0801ea13491a5a480a44433c3fb', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1555061975),
(195, '31018042bc96dc1624b185627dfc821b', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1555668225),
(196, 'b4d81d35c93cba83d737b57a1deef65e', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1555864700),
(197, '74e1ba579b09c176b19ad4a23114b659', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1556272408),
(198, '67ede186a11e6aca23efe9a1774ebdc7', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1556273024),
(199, '5c95cc4c4fe6e836419c94a078b49a4e', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1556274240),
(200, '7248c55e65996b6c01c6a7bd0bcc6b3e', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1556287937),
(201, '13fe8ede3c4997703e01f5052e74468e', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"PR";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"PR";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1556309724),
(202, '8600e5b483971914fcb7e0a6fc7ce3d1', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1556310263),
(203, 'da392dc73fad35e67d8b949db5e3fc11', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1556310263),
(204, 'c07a584434772bda6162f9fc1a4cbdf8', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1556786360),
(205, '48af4fad364c85385f68959ca59dabf9', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1556957255),
(206, '7886e3eebfc727acbdf775e422dd11f6', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:691:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:2:"NY";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:2:"NY";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1557049565),
(207, 'd14e92643eabffcf496261c03c8de737', 'a:12:{s:4:"cart";s:816:"a:2:{s:32:"0a09c8844ba8f0936c20bd791130d6b6";a:11:{s:3:"key";s:32:"0a09c8844ba8f0936c20bd791130d6b6";s:10:"product_id";i:144;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:65;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:65;s:8:"line_tax";i:0;}s:32:"0f28b5d49b3020afeecd95b4009adf4c";a:11:{s:3:"key";s:32:"0f28b5d49b3020afeecd95b4009adf4c";s:10:"product_id";i:141;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:19;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:19;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:392:"a:15:{s:8:"subtotal";s:2:"84";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:2:"84";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"134";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:420:"a:2:{s:12:"package_hash";s:40:"wc_ship_fe3a08f06212af7f7f559335664d70b6";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:66:"5 Blade Spiralizer &times; 1, Magnetic Baby Safety Locks &times; 1";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;}', 1557049573) ;
INSERT INTO `wpth_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(210, 'df7889eccd7d88ff90d5577c811e065b', 'a:13:{s:4:"cart";s:413:"a:1:{s:32:"7f1de29e6da19d22b51c68001e7e0e54";a:11:{s:3:"key";s:32:"7f1de29e6da19d22b51c68001e7e0e54";s:10:"product_id";i:135;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:100;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:100;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"100";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"100";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"150";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:414:"a:2:{s:12:"package_hash";s:40:"wc_ship_ea3049444621d9c047bcd27150c0e48f";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:60:"Premium Breathable Baby Pillow for Our Little Ones &times; 1";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:0:"";}', 1557468749),
(214, 'e0b15751ca6791b05053a60d73b79e84', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1557491214),
(215, '1884e72eddf61a93ffec1a5beee7cd74', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:691:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:2:"NY";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:2:"NY";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1557491232),
(216, 'efc3973613e46045c81f6df029613313', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1557491236),
(217, '987d9fbf7416472125ecedcfcf7e31ec', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1558073372),
(218, '8b3e5b9f9c47bbb7b80fa3e717bbb25e', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1558159354),
(219, 'd6baad3ce0b0ef2bfe254788a4e5d665', 'a:12:{s:4:"cart";s:413:"a:1:{s:32:"7f1de29e6da19d22b51c68001e7e0e54";a:11:{s:3:"key";s:32:"7f1de29e6da19d22b51c68001e7e0e54";s:10:"product_id";i:135;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:4;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:400;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:400;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"400";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"400";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"450";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:414:"a:2:{s:12:"package_hash";s:40:"wc_ship_bf643ba1d58157d09ee18b3f1473d227";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:60:"Premium Breathable Baby Pillow for Our Little Ones &times; 4";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;}', 1558594683),
(223, '5693392d8b9c0d9ecfc2ba1f0ebc20e5', 'a:13:{s:4:"cart";s:411:"a:1:{s:32:"0a09c8844ba8f0936c20bd791130d6b6";a:11:{s:3:"key";s:32:"0a09c8844ba8f0936c20bd791130d6b6";s:10:"product_id";i:144;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:65;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:65;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:392:"a:15:{s:8:"subtotal";s:2:"65";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:2:"65";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"115";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:382:"a:2:{s:12:"package_hash";s:40:"wc_ship_5ae8099a9c1d9127e72e90166e0d9c03";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:28:"5 Blade Spiralizer &times; 1";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:0:"";}', 1558595909),
(227, '227591362c83c63ce1600467380f4d83', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1558794980),
(228, '980fa30bfe7b1f743e7c30017db24f20', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1558795073),
(229, '929ac05550fb4ac8b3cb5601e1ce3890', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1558795073),
(230, '95d926054fb7f07ec6fbaca7c003baf6', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1558852440),
(231, '16d30a0fd2aa33ce0f2e93ede08fb9c1', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1558857624),
(232, '6e4499cf3671586db502d5d85e1fe2d7', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1559281814),
(233, '060b204100ba1ed2fb4379222e66747c', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1559160695),
(234, '1790e8bf1a1dc9b7b307c0f6e1fd511f', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1559160730),
(235, 'c44bf3b1d633bfcc903d0b3ad5733d14', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1559369643),
(236, 'e879a3eb9c987a466a57562c0bf5a477', 'a:13:{s:4:"cart";s:413:"a:1:{s:32:"0a09c8844ba8f0936c20bd791130d6b6";a:11:{s:3:"key";s:32:"0a09c8844ba8f0936c20bd791130d6b6";s:10:"product_id";i:144;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:195;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:195;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"195";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"195";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"245";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:382:"a:2:{s:12:"package_hash";s:40:"wc_ship_641faf15ce324760d56178d457919fbe";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:28:"5 Blade Spiralizer &times; 3";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:0:"";}', 1559801627) ;
INSERT INTO `wpth_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(237, '71ef664d263726cb7ed2c0c33f27ed12', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1559825464),
(240, '1d4524d93309fa625ddeadc96052edf0', 'a:12:{s:4:"cart";s:453:"a:1:{s:32:"b892179fa77be5379bf30b966ef1a661";a:11:{s:3:"key";s:32:"b892179fa77be5379bf30b966ef1a661";s:10:"product_id";i:147;s:12:"variation_id";i:151;s:9:"variation";a:1:{s:18:"attribute_pa_color";s:5:"black";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"8ebe40e554c18ebfc44954a0df960f82";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:115;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:115;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:394:"a:15:{s:8:"subtotal";s:3:"115";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"115";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"165";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:391:"a:2:{s:12:"package_hash";s:40:"wc_ship_99e99e32181e073b2d1083cdd40e7a21";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:37:"3D Building Block Preschool &times; 1";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;}', 1559891786),
(242, '2350a783da58cbbec30656b26ccf5b58', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1560273185),
(243, '3e70dc7010e3de8591cc7cc1b5fc675f', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1560288500),
(244, '6adc66a40b5b68c76218dd147582da33', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1560321222),
(245, '23ed54e2527372fdc5ec07c93f6978f8', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1560321237),
(246, '9a9c8cbbcf645930ae722e0598cc3e83', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1560321245),
(247, '72ecc45cd228da02f935b87658384b56', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1560852240),
(248, 'f28a076dceb8724ca4a43a0382008a7f', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561139462),
(249, '3bb5a841a6a206bc2c87eda3b3c9ffdb', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561531055),
(250, 'f74fc79c358c17b2c05cce2dd3cdabcb', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561531055),
(251, 'c3edbc6108486d7aeac89d1f20a8a298', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561548837),
(252, '2281fc1e3077904662d02975a6f1a0e1', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561548837),
(253, '690e80020a6ecc581e71e6b598b950e0', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:691:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:2:"NY";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:2:"NY";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561548894),
(254, 'f77087179d1e4edfc6fe11194c485ecb', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561549073),
(255, '4c7f637631ecd65365c29ae367c2f5d1', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561832793),
(256, 'ed887d7b9931b5ce710fc7c7c7936458', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561854559),
(257, '10559821212c7013a09df019865ef0ee', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1561854559),
(258, '0947e38b67ba498fcd72157e5ff3d972', 'a:13:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:489:"a:1:{s:32:"a99d1a2acdc4a76d1614f55522d24cab";a:11:{s:3:"key";s:32:"a99d1a2acdc4a76d1614f55522d24cab";s:10:"product_id";i:153;s:12:"variation_id";i:172;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:4:"grey";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"66e2d6018deccd2a7d21095d00b8490d";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:130;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:130;s:8:"line_tax";i:0;}}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:394:"a:2:{s:12:"package_hash";s:40:"wc_ship_33a1211e9faf49f78f73304f16338cfa";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:40:"AlpenBock Girl\'s Puffed Jacket &times; 1";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:0:"";}', 1563176384),
(259, '7b997e34440f52a40e83acd26cb56b6c', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"US";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1563200261),
(270, 'ac21e436995954e9a35493f333d29b05', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1563651144),
(271, '48a3f9303c29e960a4098c15c7ad927a', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1564958464),
(272, '6f48a0b4ec0f2a1a90b4f9f23367ffad', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1565159717),
(273, '1d7a9144bb8f59f96375095e85d364f4', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1565161855),
(274, 'e646bbf7b113a050a82dc036d654c7f0', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1565161855),
(275, '18617344b43eee85e1eccc49591e8b48', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1565247154),
(276, 'dfa8b1b695a0f5f4b410590a2f9ab392', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1565270302),
(277, '639c686dd2ab6d1b78e3a262395f1021', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1565638543),
(278, 'b26fc23a8c53b32f61ff5532099bc8ac', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:687:"a:26:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";}', 1566045058),
(279, '63ddb3d3eb21a1240be0880bc41b6637', 'a:11:{s:4:"cart";s:2641:"a:6:{s:32:"8f01326cb139578fe29a378c8f04855a";a:11:{s:3:"key";s:32:"8f01326cb139578fe29a378c8f04855a";s:10:"product_id";i:12;s:12:"variation_id";i:127;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:5:"black";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"177082e5b84331fa68ca635bcb4974df";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:90;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:90;s:8:"line_tax";i:0;}s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";a:11:{s:3:"key";s:32:"c0c7c76d30bd3dcaefc96f40275bdc0a";s:10:"product_id";i:50;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:67;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:6030;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:6030;s:8:"line_tax";i:0;}s:32:"2838023a778dfaecdc212708f721b788";a:11:{s:3:"key";s:32:"2838023a778dfaecdc212708f721b788";s:10:"product_id";i:51;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:11;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:990;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:990;s:8:"line_tax";i:0;}s:32:"a99d1a2acdc4a76d1614f55522d24cab";a:11:{s:3:"key";s:32:"a99d1a2acdc4a76d1614f55522d24cab";s:10:"product_id";i:153;s:12:"variation_id";i:172;s:9:"variation";a:2:{s:18:"attribute_pa_color";s:4:"grey";s:17:"attribute_pa_size";s:5:"30x30";}s:8:"quantity";i:21;s:9:"data_hash";s:32:"66e2d6018deccd2a7d21095d00b8490d";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:2730;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:2730;s:8:"line_tax";i:0;}s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";a:11:{s:3:"key";s:32:"fa2ffe7d23dc92e51312eecd171ddfaf";s:10:"product_id";i:137;s:12:"variation_id";i:139;s:9:"variation";a:1:{s:18:"attribute_pa_color";s:5:"black";}s:8:"quantity";i:3;s:9:"data_hash";s:32:"8ebe40e554c18ebfc44954a0df960f82";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:300;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:300;s:8:"line_tax";i:0;}s:32:"0f28b5d49b3020afeecd95b4009adf4c";a:11:{s:3:"key";s:32:"0f28b5d49b3020afeecd95b4009adf4c";s:10:"product_id";i:141;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:2;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:0:{}s:5:"total";a:0:{}}s:13:"line_subtotal";d:38;s:17:"line_subtotal_tax";i:0;s:10:"line_total";d:38;s:8:"line_tax";i:0;}}";s:11:"cart_totals";s:400:"a:15:{s:8:"subtotal";s:5:"10178";s:12:"subtotal_tax";d:0;s:14:"shipping_total";s:2:"50";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:5:"10178";s:17:"cart_contents_tax";d:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:5:"10228";s:9:"total_tax";d:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:717:"a:26:{s:2:"id";s:1:"1";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"UA";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"UA";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:29:"wp.test.mail.for.me@gmail.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";}";s:22:"shipping_for_package_0";s:572:"a:2:{s:12:"package_hash";s:40:"wc_ship_55f3126117bdcbfc1d0def4325819bd6";s:5:"rates";a:1:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":2:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:217:"Vaxholm White (test) &times; 1, Vaxholm White &times; 67, Vaxholm White (test 2) &times; 11, AlpenBock Girl\'s Puffed Jacket &times; 21, Perfect Insulated Cooler Backpack &times; 3, Magnetic Baby Safety Locks &times; 2";}}}}";s:25:"previous_shipping_methods";s:39:"a:1:{i:0;a:1:{i:0;s:11:"flat_rate:2";}}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:2";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:1;}";}', 1566142149) ;

#
# End of data contents of table `wpth_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `wpth_woocommerce_shipping_zone_locations`;


#
# Table structure of table `wpth_woocommerce_shipping_zone_locations`
#

CREATE TABLE `wpth_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_shipping_zone_locations`
#
INSERT INTO `wpth_woocommerce_shipping_zone_locations` ( `location_id`, `zone_id`, `location_code`, `location_type`) VALUES
(1, 1, 'US', 'country') ;

#
# End of data contents of table `wpth_woocommerce_shipping_zone_locations`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `wpth_woocommerce_shipping_zone_methods`;


#
# Table structure of table `wpth_woocommerce_shipping_zone_methods`
#

CREATE TABLE `wpth_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_shipping_zone_methods`
#
INSERT INTO `wpth_woocommerce_shipping_zone_methods` ( `zone_id`, `instance_id`, `method_id`, `method_order`, `is_enabled`) VALUES
(1, 1, 'flat_rate', 1, 1),
(0, 2, 'flat_rate', 1, 1) ;

#
# End of data contents of table `wpth_woocommerce_shipping_zone_methods`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `wpth_woocommerce_shipping_zones`;


#
# Table structure of table `wpth_woocommerce_shipping_zones`
#

CREATE TABLE `wpth_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_shipping_zones`
#
INSERT INTO `wpth_woocommerce_shipping_zones` ( `zone_id`, `zone_name`, `zone_order`) VALUES
(1, 'United States (US)', 0) ;

#
# End of data contents of table `wpth_woocommerce_shipping_zones`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wpth_woocommerce_tax_rate_locations`;


#
# Table structure of table `wpth_woocommerce_tax_rate_locations`
#

CREATE TABLE `wpth_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `wpth_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `wpth_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wpth_woocommerce_tax_rates`;


#
# Table structure of table `wpth_woocommerce_tax_rates`
#

CREATE TABLE `wpth_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wpth_woocommerce_tax_rates`
#

#
# End of data contents of table `wpth_woocommerce_tax_rates`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

ALTER TABLE `wpth_wc_download_log`
  ADD CONSTRAINT `fk_wpth_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wpth_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE;

